/*    */
package com.dnfm.game.support;

/*    */
/*    */

import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.support.DefaultConversionService;

/*    */
/*    */
/*    */
@Configuration
/*    */ public class SupportConfiration
        /*    */ {
    /*    */
    @Bean({"gameConversion"})
    /*    */ public ConversionService createConversionService() {
        /* 14 */
        return (ConversionService) new DefaultConversionService();
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\support\SupportConfiration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */