package com.dnfm.game.scene;

import com.dnfm.common.thread.NamedThreadFactory;
import com.dnfm.game.config.GameMap;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.scene.aoi.AOI;
import com.dnfm.game.scene.aoi.Scene;
import com.dnfm.logs.LoggerFunction;
import com.dnfm.mina.protobuf.Message;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 场景管理器单例类。
 * 负责管理游戏中的各个场景（AOI），并将场景相关的任务分发给工作线程池处理。
 */
public enum SceneManager {

    INSTANCE;

    private static final Logger logger = LoggerFunction.SCENE.getLogger();
    private static final int CORE_SIZE = 8; // 线程池大小
    private static final List<TaskWorker> workerPool = new ArrayList<>();
    private static final Map<Integer, AOI> scenes = new HashMap<>();
    private final AtomicInteger atomicInteger = new AtomicInteger(); // 用于生成场景ID

    /**
     * 私有构造函数，防止外部实例化。
     */
    SceneManager() {
    }

    /**
     * 初始化场景管理器，根据地图配置创建对应的AOI场景。
     *
     * @param maps 地图配置列表
     */
    public void initiate(List<GameMap> maps) {
        maps.forEach((gameMap) -> {
            AOI scene = new Scene();
            scene.setId(this.atomicInteger.getAndIncrement());
            scenes.put(gameMap.getId(), scene);
        });
    }

    /**
     * 添加一个场景。
     * 如果场景不存在，则创建一个新的场景并添加到缓存中。
     *
     * @param mapId 地图ID
     */
    private void addScene(int mapId) {
        AOI scene = new Scene();
        scene.setId(this.atomicInteger.getAndIncrement());
        scenes.put(mapId, scene);
    }

    /**
     * 获取指定地图ID对应的场景。
     * 如果场景不存在，则先创建一个。
     *
     * @param mapId 地图ID
     * @return 对应的场景对象
     */
    private AOI getScene(int mapId) {
        AOI scene = scenes.get(mapId);
        if (scene == null) {
            this.addScene(mapId);
            return scenes.get(mapId); // 重新获取刚创建的场景
        } else {
            return scene;
        }
    }

    /**
     * 让角色进入指定地图场景。
     *
     * @param mapId 地图ID
     * @param role  角色对象
     */
    public void enterMap(int mapId, Role role) {
        AOI scene = this.getScene(mapId);
        this.acceptTask(scene.getId(), () -> {
            scene.enter(role);
        });
    }

    /**
     * 让角色离开指定地图场景。
     *
     * @param mapId 地图ID
     * @param role  角色对象
     */
    public void leaveMap(int mapId, Role role) {
        AOI scene = this.getScene(mapId);
        this.acceptTask(scene.getId(), () -> {
            scene.leave(role);
        });
    }

    /**
     * 让角色在指定地图场景中移动。
     *
     * @param mapId 地图ID
     * @param role  角色对象
     */
    public void movePosition(int mapId, Role role) {
        AOI scene = this.getScene(mapId);
        this.acceptTask(scene.getId(), () -> {
            scene.move(role);
        });
    }

    /**
     * 向角色所在场景发送消息。
     *
     * @param role     角色对象
     * @param messages 要发送的消息数组
     */
    public void sendMessages(Role role, Message... messages) {
        AOI scene = this.getScene(role.getPos().getArea());
        this.acceptTask(scene.getId(), () -> {
            scene.sendMessages(role, messages);
        });
    }

    /**
     * 接受一个任务并将其分发给对应的工作线程。
     * 任务会被分发到基于场景ID取模的线程上执行。
     *
     * @param sceneId 场景ID
     * @param task    要执行的任务
     */
    public void acceptTask(int sceneId, Runnable task) {
        if (task != null) {
            int size = workerPool.size();
            int index = sceneId % size; // 简单的取模分发策略
            workerPool.get(index).addTask(task);
        }
    }

    /**
     * 获取指定地图场景中附近的其他角色列表。
     *
     * @param mapId 地图ID
     * @param role  参考角色对象
     * @return 附近的其他角色列表
     */
    public List<Role> getNearbyRoles(int mapId, Role role) {
        AOI scene = this.getScene(mapId);
        return scene.getNearbyRoles(role);
    }

    /**
     * 静态初始化块，创建并启动工作线程池。
     */
    static {
        for (int i = 1; i <= CORE_SIZE; ++i) { // 使用常量 CORE_SIZE
            TaskWorker worker = new TaskWorker(i);
            workerPool.add(worker);
            (new NamedThreadFactory("scene_" + i)).newThread(worker).start();
        }
    }

    /**
     * 任务工作线程内部类。
     * 每个工作线程维护一个任务队列，并循环执行队列中的任务。
     */
    static class TaskWorker implements Runnable {

        private final int id; // 工作线程ID
        private final BlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<>();

        /**
         * 构造函数。
         *
         * @param index 工作线程索引
         */
        TaskWorker(int index) {
            this.id = index;
        }

        /**
         * 向任务队列添加任务。
         *
         * @param task 要添加的任务
         */
        void addTask(Runnable task) {
            this.taskQueue.add(task);
        }

        /**
         * 工作线程的执行逻辑。
         * 从任务队列中取出任务并执行，处理执行过程中的异常。
         */
        @Override
        public void run() {
            while (true) {
                try {
                    Runnable task = this.taskQueue.take(); // 阻塞式获取任务
                    task.run();
                } catch (InterruptedException e) {
                    // 如果线程被中断，可以优雅地退出
                    Thread.currentThread().interrupt();
                    logger.warn("Scene worker {} interrupted, exiting.", this.id);
                    break;
                } catch (Exception e) {
                    logger.error("Scene task error on worker {}", this.id, e);
                }
            }
        }
    }
}