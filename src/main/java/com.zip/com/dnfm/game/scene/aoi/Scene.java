package com.dnfm.game.scene.aoi;

import com.dnfm.common.spring.SpringUtils;
import com.dnfm.game.fight.service.BroadcastService;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.RoleService;
import com.dnfm.logs.LoggerFunction;
import com.dnfm.mina.cache.DataCache;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.Message;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 场景实现类，基于 AOI 抽象基类。
 * 使用双向链表（按 X 和 Y 坐标排序）来管理场景中的角色，以实现高效的视野管理（AOI）。
 * 每个角色由一个 Node 表示，并维护两个按坐标排序的链表。
 */
public class Scene extends AOI {

    private static final Logger logger = LoggerFunction.SCENE.getLogger();
    private static final int DISTANCE = 900; // 视野距离阈值

    private final BroadcastService service = SpringUtils.getBroadcastService();
    private final RoleService roleService = SpringUtils.getRoleService();

    private final Node _head; // X 和 Y 链表的虚拟头节点
    private final Node _tail; // X 和 Y 链表的虚拟尾节点

    // 存储所有节点，key 为角色 UID
    private final Map<Long, Node> allNodes = new ConcurrentHashMap<>();

    /**
     * 构造函数，初始化场景的双向链表结构。
     */
    public Scene() {
        this._head = new Node(Long.MIN_VALUE, 0, 0);
        this._tail = new Node(Long.MAX_VALUE, 0, 0);
        // 初始化头尾节点的链接关系
        this._head.xNext = this._tail;
        this._head.yNext = this._tail;
        this._tail.xPrev = this._head;
        this._tail.yPrev = this._head;
    }

    /**
     * 主函数，用于测试（当前为空实现）。
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        Role r = null;
        List<Role> list = new ArrayList<>();
        System.out.println(list.size());
        list.add(r);
        System.out.println(list.size());
    }

    /**
     * 将角色节点添加到按坐标排序的双向链表中。
     *
     * @param node 要添加的角色节点
     */
    private void addActor(Node node) {
        this.allNodes.put(node.id, node); // 使用 Long.valueOf 可能是多余的，直接使用 node.id 即可

        int i = 0;
        Node cur = this._head.xNext;
        // 按 X 坐标插入到链表中
        while (cur != null) {
            if (i >= 50) {
                logger.error("x 没有人，别动了快歇歇吧 node: [{}]", node);
                break;
            }
            if (cur.x > node.x || cur == this._tail) {
                node.xNext = cur;
                node.xPrev = cur.xPrev;
                cur.xPrev.xNext = node;
                cur.xPrev = node;
                break;
            }
            cur = cur.xNext;
            i++;
        }

        i = 0;
        cur = this._head.yNext;
        // 按 Y 坐标插入到链表中
        while (cur != null) {
            if (i >= 50) {
                logger.error("y 没有人，别动了快歇歇吧 node: [{}]", node);
                break;
            }
            if (cur.y > node.y || cur == this._tail) {
                node.yNext = cur;
                node.yPrev = cur.yPrev;
                cur.yPrev.yNext = node;
                cur.yPrev = node;
                break;
            }
            cur = cur.yNext;
            i++;
        }
    }

    /**
     * 根据角色获取其对应的节点，如果不存在则创建一个。
     *
     * @param role 角色对象
     * @return 对应的角色节点
     */
    private Node getNodeByRole(Role role) {
        Node node = this.allNodes.get(role.getUid()); // 直接使用 get(uid) 即可
        if (node == null) {
            node = new Node(role.getUid(), role.getPos().getX(), role.getPos().getY());
            addActor(node);
        }
        return node;
    }

    /**
     * 将角色节点从按坐标排序的双向链表中移除。
     *
     * @param node 要移除的角色节点
     */
    private void leave(Node node) {
        if (node.xPrev != null) {
            node.xPrev.xNext = node.xNext;
        }
        if (node.xNext != null) {
            node.xNext.xPrev = node.xPrev;
        }
        if (node.yPrev != null) {
            node.yPrev.yNext = node.yNext;
        }
        if (node.yNext != null) {
            node.yNext.yPrev = node.yPrev;
        }
        // 清理节点的指针，防止内存泄漏或意外访问
        node.xPrev = null;
        node.xNext = null;
        node.yPrev = null;
        node.yNext = null;
    }

    /**
     * 获取指定节点视野范围内的其他角色 UID 集合。
     *
     * @param node 参考节点
     * @return 视野范围内的角色 UID 集合
     */
    private Set<Long> getVisualObjects(Node node) {
        Set<Long> visuals = new HashSet<>();
        if (node == null) {
            logger.error("node is null:[{}]", (new RuntimeException()).getMessage());
            return visuals;
        }

        int i = 0;
        Node cur = node.xNext; // 从当前节点向 X 轴正方向查找
        while (cur != this._tail) {
            if (i >= 50) {
                logger.error("x 没有人，别动了快歇歇吧");
                break;
            }
            if (cur == null) {
                break;
            }
            if (cur.x - node.x > DISTANCE) { // 超出 X 轴距离
                break;
            }
            int interval = node.y - cur.y; // 计算 Y 轴距离
            if (interval >= -DISTANCE && interval <= DISTANCE) {
                visuals.add(cur.id);
            }
            cur = cur.xNext;
            i++;
        }

        i = 0;
        cur = node.xPrev; // 从当前节点向 X 轴负方向查找
        while (cur != this._head) {
            if (i >= 50) {
                logger.error("y 没有人，别动了快歇歇吧");
                break;
            }
            if (cur == null) {
                break;
            }
            if (node.x - cur.x > DISTANCE) { // 超出 X 轴距离
                break;
            }
            int interval = node.y - cur.y; // 计算 Y 轴距离
            if (interval >= -DISTANCE && interval <= DISTANCE) {
                visuals.add(cur.id);
            }
            cur = cur.xPrev;
            i++;
        }
        return visuals;
    }

    /**
     * 角色进入场景。
     * 如果角色节点已存在，则直接返回；否则创建节点并添加到场景中。
     *
     * @param role 角色对象
     */
    @Override
    public void enter(Role role) {
        Node node = this.allNodes.get(role.getUid()); // 直接使用 get(uid) 即可
        if (node != null) {
            return; // 角色已存在，无需重复进入
        }
        getNodeByRole(role); // 创建并添加节点
    }

    /**
     * 角色离开场景。
     * 将角色节点从场景中移除。
     *
     * @param role 角色对象
     */
    @Override
    public void leave(Role role) {
        long uid = role.getUid();
        Node node = getNodeByRole(role); // 获取节点（如果不存在会创建，但 leave 逻辑会处理）
        leave(node); // 从链表中移除
        this.allNodes.remove(uid); // 从缓存中移除
    }

    /**
     * 角色在场景中移动。
     * 更新角色节点的坐标，并重新排序链表。
     *
     * @param role 角色对象
     */
    @Override
    public void move(Role role) {
        Node node = getNodeByRole(role);
        // 获取移动前的视野
        // Set<Long> oldSet = getVisualObjects(node); // 代码中获取了但未使用，可能用于后续的 enter/leave 逻辑

        leave(node); // 从旧位置移除
        node.x = role.getPos().getX(); // 更新坐标
        node.y = role.getPos().getY();
        addActor(node); // 添加到新位置
    }

    /**
     * 获取指定角色附近的其他角色列表。
     *
     * @param role 参考角色对象
     * @return 附近的其他角色列表
     */
    @Override
    public List<Role> getNearbyRoles(Role role) {
        Node node = getNodeByRole(role);
        Set<Long> uids = getVisualObjects(node);
        List<Role> resList = new ArrayList<>();
        for (Long uid : uids) {
            Role r = DataCache.ONLINE_ROLES.get(uid); // 直接从缓存获取
            if (r == null) {
                logger.error("角色不存在:{}", uid);
                continue;
            }
            resList.add(r);
        }
        return resList;
    }

    /**
     * 向角色附近的其他角色发送消息。
     *
     * @param role     发送消息的角色
     * @param messages 要发送的消息数组
     */
    @Override
    public void sendMessages(Role role, Message... messages) {
        Node node = getNodeByRole(role);
        Set<Long> ids = getVisualObjects(node);
        sendMessages(role, ids, messages);
    }

    /**
     * 向指定 ID 集合中的角色发送消息。
     *
     * @param role     发送消息的角色（用于判断场景）
     * @param ids      目标角色 ID 集合
     * @param messages 要发送的消息数组
     */
    private void sendMessages(Role role, Set<Long> ids, Message... messages) {
        MessagePusher.pushMessages(role, messages); // 先发给自己
        if (ids.isEmpty()) {
            return;
        }
        for (Long targetId : ids) { // 使用增强 for 循环替代 Iterator
            Role target = this.roleService.getOnlinePlayer(targetId);
            // 确保目标角色在线且在同一场景
            if (target != null && this.service.inSameScene(role, target)) {
                MessagePusher.pushMessages(target, messages);
            }
        }
    }

    /**
     * 向视野内的其他角色发送移动消息。
     * （当前方法体不完整，缺少实际发送逻辑）
     *
     * @param selfRole 发起移动的角色
     * @param moves    视野内的角色 ID 集合
     */
    private void sendMove(Role selfRole, Set<Long> moves) {
        Message movePacket = this.service.getMovePacket(selfRole);
        MessagePusher.pushMessage(selfRole, movePacket); // 先发给自己
        if (moves.isEmpty()) {
            return;
        }
        for (Long targetId : moves) { // 使用增强 for 循环替代 Iterator
            Role target = this.roleService.getOnlinePlayer(targetId);
            if (target == null || !this.service.inSameScene(selfRole, target)) {
                // 当前代码中即使条件不满足也继续循环，没有实际发送
                // 可能需要补充发送逻辑或日志
            }
            // 实际的发送逻辑应该在这里
            // if (target != null && this.service.inSameScene(selfRole, target)) {
            //     MessagePusher.pushMessage(target, movePacket);
            // }
        }
    }

    /**
     * 向视野内的其他角色发送外观更新消息。
     * （当前为空实现）
     *
     * @param selfRole 发起更新的角色
     * @param enters   视野内新进入的角色 ID 集合
     */
    private void sendAppear(Role selfRole, Set<Long> enters) {
        // TODO: 实现此方法
    }

    /**
     * 向视野内的其他角色发送消失消息。
     * （当前为空实现）
     *
     * @param selfRole 发起更新的角色
     * @param leaves   视野内离开的角色 ID 集合
     */
    private void sendDisappear(Role selfRole, Set<Long> leaves) {
        // TODO: 实现此方法
    }
}