package com.dnfm.game.scene.aoi;

import com.dnfm.game.role.model.Role;
import com.dnfm.mina.protobuf.Message;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * AOI (Area of Interest) 抽象基类。
 * 定义了场景中角色进入、离开、移动、消息发送和获取附近角色等核心行为。
 * 具体的 AOI 实现（如网格、四叉树等）需要继承此类并实现抽象方法。
 */
public abstract class AOI {

    @Getter
    @Setter
    private int id;

    /**
     * 角色进入场景。
     *
     * @param role 角色对象
     */
    public abstract void enter(Role role);

    /**
     * 角色离开场景。
     *
     * @param role 角色对象
     */
    public abstract void leave(Role role);

    /**
     * 角色在场景中移动。
     *
     * @param role 角色对象
     */
    public abstract void move(Role role);

    /**
     * 向角色发送消息。
     *
     * @param role     角色对象
     * @param messages 要发送的消息数组
     */
    public abstract void sendMessages(Role role, Message... messages);

    /**
     * 获取指定角色附近的其他角色列表。
     *
     * @param role 参考角色对象
     * @return 附近的其他角色列表
     */
    public abstract List<Role> getNearbyRoles(Role role);
}