/*    */
package com.dnfm.game.scene.aoi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Node
/*    */ {
/*    */   long id;
/*    */   int x;
/*    */   int y;
/*    */   com.dnfm.game.scene.aoi.Node xPrev;
/*    */   com.dnfm.game.scene.aoi.Node xNext;
/*    */   com.dnfm.game.scene.aoi.Node yPrev;
/*    */   com.dnfm.game.scene.aoi.Node yNext;
/*    */   
/*    */   Node(long id, int x, int y) {
/* 19 */     this.id = id;
/* 20 */     this.x = x;
/* 21 */     this.y = y;
/* 22 */     this.xPrev = this.xNext = null;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\scene\aoi\Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */