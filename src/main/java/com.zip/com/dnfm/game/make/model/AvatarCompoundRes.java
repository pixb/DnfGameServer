package com.dnfm.game.make.model;

public class AvatarCompoundRes {
  public int index;
  
  public int cnt;
}
