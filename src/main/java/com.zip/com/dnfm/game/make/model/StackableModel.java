package com.dnfm.game.make.model;

public class StackableModel {
  public int recipeindex;
  
  public int index;
  
  public int price;
  
  public int category;
}
