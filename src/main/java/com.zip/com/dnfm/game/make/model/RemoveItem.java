package com.dnfm.game.make.model;

public class RemoveItem {
  public int index;
  
  public int cnt;
}
