/*   */
package com.dnfm.game.make;

/*   */
/*   */ import java.util.HashMap;
/*   */ import java.util.Map;
/*   */ 
/*   */ public class MakeModel
/*   */ {
/* 8 */   public Map<Integer, Integer> needs = new HashMap<>();
/* 9 */   public int price = 0;
/*   */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\make\model\MakeModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */