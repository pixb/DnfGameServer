package com.dnfm.game.make;

public class RemoveItem {
  public int index;
  
  public int cnt;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\make\model\RemoveItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */