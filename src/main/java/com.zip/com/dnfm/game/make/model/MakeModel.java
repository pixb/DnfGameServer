package com.dnfm.game.make.model;


import java.util.HashMap;
import java.util.Map;

public class MakeModel {
  public Map<Integer, Integer> needs = new HashMap<>();
  
  public int price = 0;
}
