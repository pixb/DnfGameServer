/*    */
package com.dnfm.game.activity.model;
/*    */ 
/*    */ public class DugeonSet {
/*    */   private int expReward;
/*    */   private int taoReward;
/*    */   private int matiralReward;
/*    */   private int potReward;
/*    */   
/*    */   public int getExpReward() {
/* 10 */     return this.expReward;
/* 11 */   } public int getTaoReward() { return this.taoReward; }
/* 12 */   public int getMatiralReward() { return this.matiralReward; } public int getPotReward() {
/* 13 */     return this.potReward;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\activity\model\DugeonSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */