package com.dnfm.game.activity.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnore;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Dugeon {

    private long id;

    private long createTime;

    private long endTime;

    private List<Long> memberList;

    public Dugeon(long id, List<Long> memberList) {
        this.id = id;
        this.createTime = System.currentTimeMillis();
        this.endTime = this.createTime + 7200L;
        this.memberList = memberList;
    }

    @JsonIgnore
    public boolean isCreator(long uid) {
        return (memberList.get(0).longValue() == uid);
    }

    @JsonIgnore
    public boolean isOverTime() {
        return (System.currentTimeMillis() >= this.endTime);
    }
}