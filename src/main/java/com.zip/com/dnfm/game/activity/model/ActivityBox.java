package com.dnfm.game.activity.model;

public class ActivityBox {

    private long tylorBagExpireTime;

    public long getTylorBagExpireTime() {
        return this.tylorBagExpireTime;
    }

    public void setTylorBagExpireTime(long tylorBagExpireTime) {
        this.tylorBagExpireTime = tylorBagExpireTime;
    }

    @Override
    public String toString() {
        return "ActivityBox(tylorBagExpireTime=" + getTylorBagExpireTime() + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof ActivityBox)) return false;
        ActivityBox other = (ActivityBox) o;
        return other.canEqual(this) && (getTylorBagExpireTime() == other.getTylorBagExpireTime());
    }

    protected boolean canEqual(Object other) {
        return other instanceof ActivityBox;
    }
}