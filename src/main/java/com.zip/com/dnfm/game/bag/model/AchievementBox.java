/*    */
package com.dnfm.game.bag.model;

/*    */
/*    */

import com.dnfm.mina.protobuf.AchievementInfoPacketData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
import java.util.Objects;

/*    */
/*    */ public class AchievementBox {
    /*    */
    public String toString() {
        /*  9 */
        return "AchievementBox(list=" + getList() + ")";
    }

//    public int hashCode() {
//        int PRIME = 59;
//        int result = 1;
//        return result * 59 + ((this.list == null) ? 43 : this.hashCode());
//    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.bag.model.AchievementBox;
    }

    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof com.dnfm.game.bag.model.AchievementBox)) return false;
        com.dnfm.game.bag.model.AchievementBox other = (com.dnfm.game.bag.model.AchievementBox) o;
        if (!other.canEqual(this)) return false;
        return Objects.equals(this.list, other.list);
    }

    public void setList(List<AchievementInfoPacketData> list) {
        this.list = list;
    }

    /*    */
    /* 11 */   private List<AchievementInfoPacketData> list = new ArrayList<>();

    public List<AchievementInfoPacketData> getList() {
        return this.list;
    }
    /*    */
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\bag\model\AchievementBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */