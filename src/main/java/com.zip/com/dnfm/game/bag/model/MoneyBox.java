package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_MONEY_ITEM;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * 金钱盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
@Slf4j // 自动生成 log 日志对象
public class MoneyBox {

    // 货币映射表
    private Map<Integer, PT_MONEY_ITEM> currency = new HashMap<>();

    // 每日收益映射表
    private Map<Integer, PT_MONEY_ITEM> dailygain = new HashMap<>();

    /**
     * 为拍卖扣除泰拉。
     * @param cnt 要扣除的数量。
     */
    public void subTeraForAuction(int cnt) {
        PT_MONEY_ITEM ptMoneyItem = this.currency.get(2013000001); // 假设 PT_MONEY_ITEM 有 getter
        if (ptMoneyItem == null) {
            log.error("PT_MONEY_ITEM for index 2013000001 not found in currency map.");
            return; // 或者抛出异常
        }
        log.error("before-tera==" + ptMoneyItem.count); // 假设 PT_MONEY_ITEM 有 getter
        ptMoneyItem.count = ptMoneyItem.count - cnt; // 假设 PT_MONEY_ITEM 有 getter/setter
        log.error("after-tera==" + ptMoneyItem.count);
    }

    /**
     * 增加指定货币的数量。
     * 如果不存在，则创建新的。
     * @param index 货币索引。
     * @param cnt 要增加的数量。
     */
    public void addCnt(int index, int cnt) {
        PT_MONEY_ITEM item = this.currency.get(index);
        if (item == null) {
            item = new PT_MONEY_ITEM();
            item.index = index; // 假设 PT_MONEY_ITEM 有 setter
            item.count = cnt;
            this.currency.put(index, item);
        } else {
            item.count = item.count + cnt; // 假设 PT_MONEY_ITEM 有 getter/setter
            // 注意：put(index, item) 通常不需要，因为 item 是引用，修改后 map 中的值也已改变。
            // 但如果 PT_MONEY_ITEM 是不可变的，则需要重新 put。
            // this.currency.put(index, item);
        }
    }

    /**
     * 减少指定货币的数量。
     * @param index 货币索引。
     * @param cnt 要减少的数量。
     */
    public void subCnt(int index, int cnt) {
        PT_MONEY_ITEM item = this.currency.get(index);
        if (item != null) { // 添加 null 检查以避免 NPE
            item.count = item.count - cnt; // 假设 PT_MONEY_ITEM 有 getter/setter
            // this.currency.put(index, item); // 通常不需要
        }
    }

    /**
     * 放入货币项到货币映射表。
     * @param ptMoneyItem 要放入的货币项。
     */
    public void putCurrency(PT_MONEY_ITEM ptMoneyItem) {
        this.currency.put(ptMoneyItem.index, ptMoneyItem); // 假设 PT_MONEY_ITEM 有 getter
    }

    /**
     * 放入货币项到账户货币映射表（实际操作 currency map）。
     * @param ptMoneyItem 要放入的货币项。
     */
    public void putAccountCurrency(PT_MONEY_ITEM ptMoneyItem) {
        this.currency.put(ptMoneyItem.index, ptMoneyItem); // 假设 PT_MONEY_ITEM 有 getter
    }

    /**
     * 更新货币项（增加数量）。
     * 如果不存在，则创建新的。
     * @param ptMoneyItem 包含索引和数量变化的货币项。
     */
    public void updateCurrency(PT_MONEY_ITEM ptMoneyItem) {
        PT_MONEY_ITEM oldMoneyItem = this.currency.get(ptMoneyItem.index); // 假设 PT_MONEY_ITEM 有 getter
        if (oldMoneyItem == null) {
            this.currency.put(ptMoneyItem.index, ptMoneyItem);
        } else {
            oldMoneyItem.count = oldMoneyItem.count + ptMoneyItem.count; // 假设 PT_MONEY_ITEM 有 getter/setter
            // this.currency.put(ptMoneyItem.getIndex(), oldMoneyItem); // 通常不需要
        }
    }

    /**
     * 获取指定索引的货币项。
     * @param index 货币索引。
     * @return 对应的货币项，如果未找到则返回 null。
     */
    public PT_MONEY_ITEM getMoneyItem(int index) {
        return this.currency.get(index);
    }

    /**
     * 获取指定索引的账户货币项（实际从 currency map 获取）。
     * @param index 货币索引。
     * @return 对应的货币项，如果未找到则返回 null。
     */
    public PT_MONEY_ITEM getAccountMoneyItem(int index) {
        return this.currency.get(index);
    }

    /**
     * 获取货币数量（索引为 0 的货币）。
     * @return 货币数量，如果未找到则返回 0。
     */
    public int getMoneyCnt() {
        PT_MONEY_ITEM ptMoneyItem = this.getMoneyItem(0);
        return ptMoneyItem == null ? 0 : ptMoneyItem.count; // 假设 PT_MONEY_ITEM 有 getter
    }

    /**
     * 增加货币（索引为 0 的货币）。
     * @param count 要增加的数量。
     */
    public void addmoney(int count) {
        PT_MONEY_ITEM ptMoneyItem = this.currency.get(0);
        if (ptMoneyItem == null) {
            ptMoneyItem = new PT_MONEY_ITEM();
            ptMoneyItem.index = 0;
            ptMoneyItem.count = 0;
            this.currency.put(0, ptMoneyItem);
        }
        ptMoneyItem.count = ptMoneyItem.count + count; // 假设 PT_MONEY_ITEM 有 getter/setter
        // this.currency.put(0, ptMoneyItem); // 通常不需要
    }

    /**
     * 减少货币（索引为 0 的货币）。
     * @param count 要减少的数量。
     */
    public void submoney(int count) {
        PT_MONEY_ITEM ptMoneyItem = this.currency.get(0);
        if (ptMoneyItem != null && ptMoneyItem.count - count >= 0) { // 添加 null 检查和非负检查
            ptMoneyItem.count = ptMoneyItem.count - count; // 假设 PT_MONEY_ITEM 有 getter/setter
            // this.currency.put(0, ptMoneyItem); // 通常不需要
        }
    }

    /**
     * 获取复活次数（索引为 2013100902 的货币）。
     * @return 复活次数，如果未找到则返回 0。
     */
    public int getFuhuoCnt() {
        PT_MONEY_ITEM ptMoneyItem = this.currency.get(2013100902);
        return ptMoneyItem == null ? 0 : ptMoneyItem.count; // 假设 PT_MONEY_ITEM 有 getter
    }

    /**
     * 减少复活次数（索引为 2013100902 的货币）。
     */
    public void subFuhuoCnt() {
        PT_MONEY_ITEM ptMoneyItem = this.currency.get(2013100902);
        if (ptMoneyItem != null) {
            ptMoneyItem.count = ptMoneyItem.count - 1; // 假设 PT_MONEY_ITEM 有 getter/setter
            // this.currency.put(2013100902, ptMoneyItem); // 通常不需要
        }
    }
}