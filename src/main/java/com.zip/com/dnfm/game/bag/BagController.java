package com.dnfm.game.bag;

import com.alibaba.fastjson.JSON;
import com.dnfm.common.thread.IdGenerator;
import com.dnfm.common.utils.Util;
import com.dnfm.game.bag.model.AccShopInfoBox;
import com.dnfm.game.bag.model.AdStorageBox;
import com.dnfm.game.bag.model.CardBox;
import com.dnfm.game.bag.model.CharStorageBox;
import com.dnfm.game.bag.model.ConsumableBox;
import com.dnfm.game.bag.model.EmblemBox;
import com.dnfm.game.bag.model.MoneyBox;
import com.dnfm.game.bag.model.RePurStoItemBox;
import com.dnfm.game.bag.service.BagService;
import com.dnfm.game.config.ConsumeItem;
import com.dnfm.game.config.Skin;
import com.dnfm.game.config.ItemShop;
import com.dnfm.game.equip.EquipDataPool;
import com.dnfm.game.item.ItemDataPool;
import com.dnfm.game.item.model.GiftContent;
import com.dnfm.game.mail.model.MailItem;
import com.dnfm.game.role.model.Account;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.AccountService;
import com.dnfm.game.role.service.RoleService;
import com.dnfm.game.utils.DateUtils;
import com.dnfm.game.utils.TimeUtil;
import com.dnfm.mina.annotation.RequestMapping;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.DEF_ITEM_CONSUMABLE;
import com.dnfm.mina.protobuf.Message;
import com.dnfm.mina.protobuf.NOTIFY_ADVENTUREBOOK_UPDATE_CONDITION;
import com.dnfm.mina.protobuf.PT_ADVENTUREBOOK_OPEN_CONDITION;
import com.dnfm.mina.protobuf.PT_ARTIFACT;
import com.dnfm.mina.protobuf.PT_AVATAR_ITEM;
import com.dnfm.mina.protobuf.PT_CERA_SHOP_BUY;
import com.dnfm.mina.protobuf.PT_CERA_SHOP_INFO;
import com.dnfm.mina.protobuf.PT_CONTENTS_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_CREATURE;
import com.dnfm.mina.protobuf.PT_CURRENCY_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_EQUIP;
import com.dnfm.mina.protobuf.PT_EQUIPPED;
import com.dnfm.mina.protobuf.PT_ITEMS;
import com.dnfm.mina.protobuf.PT_ITEM_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_ITEM_USE_RESULT;
import com.dnfm.mina.protobuf.PT_MONEY_ITEM;
import com.dnfm.mina.protobuf.PT_REMOVEITEMS;
import com.dnfm.mina.protobuf.PT_REPURCHASE_EQUIP;
import com.dnfm.mina.protobuf.PT_REPURCHASE_STACKABLE;
import com.dnfm.mina.protobuf.PT_REPURCHASE_STORAGE_LIST;
import com.dnfm.mina.protobuf.PT_SHOP_BUY_COUNT;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import com.dnfm.mina.protobuf.REQ_ADVENTUREBOOK_UPDATE_CONDITION;
import com.dnfm.mina.protobuf.REQ_ADVENTURE_STORAGE_LIST;
import com.dnfm.mina.protobuf.REQ_CERA_SHOP_BUY;
import com.dnfm.mina.protobuf.REQ_CERA_SHOP_BUY_INFO;
import com.dnfm.mina.protobuf.REQ_CHAR_STORAGE_LIST;
import com.dnfm.mina.protobuf.REQ_INVEN_EXTEND;
import com.dnfm.mina.protobuf.REQ_ITEM_USE;
import com.dnfm.mina.protobuf.REQ_NPC_SHOP_ITEM_SELL;
import com.dnfm.mina.protobuf.REQ_REPURCHASE_ITEM;
import com.dnfm.mina.protobuf.REQ_REPURCHASE_ITEM_STORAGE_LIST;
import com.dnfm.mina.protobuf.REQ_SEND_INVEN;
import com.dnfm.mina.protobuf.REQ_SEND_STORAGE;
import com.dnfm.mina.protobuf.REQ_STORAGE_EXTEND;
import com.dnfm.mina.protobuf.RES_ADVENTUREBOOK_UPDATE_CONDITION;
import com.dnfm.mina.protobuf.RES_ADVENTURE_STORAGE_LIST;
import com.dnfm.mina.protobuf.RES_CERA_SHOP_BUY;
import com.dnfm.mina.protobuf.RES_CERA_SHOP_BUY_INFO;
import com.dnfm.mina.protobuf.RES_CHAR_STORAGE_LIST;
import com.dnfm.mina.protobuf.RES_INVEN_EXTEND;
import com.dnfm.mina.protobuf.RES_ITEM_USE;
import com.dnfm.mina.protobuf.RES_NPC_SHOP_ITEM_SELL;
import com.dnfm.mina.protobuf.RES_REPURCHASE_ITEM;
import com.dnfm.mina.protobuf.RES_REPURCHASE_ITEM_STORAGE_LIST;
import com.dnfm.mina.protobuf.RES_SEND_INVEN;
import com.dnfm.mina.protobuf.RES_SEND_STORAGE;
import com.dnfm.mina.protobuf.RES_STORAGE_EXTEND;
import com.dnfm.mina.protobuf.SendItem_GuidInfo;
import com.dnfm.mina.protobuf.SendItem_Info;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Slf4j
@Controller
public class BagController {

    @Autowired
    BagService bagService;

    @Autowired
    AccountService accountService;

    @Autowired
    RoleService roleService;

    @RequestMapping
    public void REQ_NPC_SHOP_ITEM_SELL(IoSession session, REQ_NPC_SHOP_ITEM_SELL req_npc_shop_item_sell) {
        Role role = SessionUtils.getRoleBySession(session);
        MoneyBox moneyBox = role.getMoneyBox();
        RePurStoItemBox rePurStoItemBox = role.getRePurStoItem();
        int type = req_npc_shop_item_sell.item.get(0).type.intValue();
        RES_NPC_SHOP_ITEM_SELL res_npc_shop_item_sell = new RES_NPC_SHOP_ITEM_SELL();
        res_npc_shop_item_sell.item = req_npc_shop_item_sell.item;
        int totalPrice = -1;
        if (req_npc_shop_item_sell.item.get(0).guids != null && req_npc_shop_item_sell.item.get(0).guids.size() > 0) {
            totalPrice = this.bagService.calcGuidsPrice(type, role, req_npc_shop_item_sell.item);
            if (totalPrice == -1) {
                BagController.log.error("UNREACH==REQ_NPC_SHOP_ITEM_SELL: calcGuidsPrice error==req==" + JSON.toJSONString(req_npc_shop_item_sell));
                return;
            }
            res_npc_shop_item_sell.info = new PT_CONTENTS_REWARD_INFO();
            res_npc_shop_item_sell.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
            res_npc_shop_item_sell.info.paymentcurrency.currency = new ArrayList();
            moneyBox.addmoney(totalPrice);
            PT_MONEY_ITEM ptMoneyItem = moneyBox.getMoneyItem(0);
            PT_MONEY_ITEM ptMoneyItemPay = new PT_MONEY_ITEM();
            ptMoneyItemPay.count = Integer.valueOf(totalPrice);
            res_npc_shop_item_sell.info.paymentcurrency.currency.add(ptMoneyItemPay);
            res_npc_shop_item_sell.info.currency = new PT_CURRENCY_REWARD_INFO();
            res_npc_shop_item_sell.info.currency.currency = new ArrayList();
            res_npc_shop_item_sell.info.currency.currency.add(ptMoneyItem);
        } else {
            totalPrice = this.bagService.calcStackablesPrice(role, req_npc_shop_item_sell.item);
            if (totalPrice == -1) {
                BagController.log.error("UNREACH==REQ_NPC_SHOP_ITEM_SELL: calcGuidsPrice error==req==" + JSON.toJSONString(req_npc_shop_item_sell));
                return;
            }
            res_npc_shop_item_sell.info = new PT_CONTENTS_REWARD_INFO();
            res_npc_shop_item_sell.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
            res_npc_shop_item_sell.info.paymentcurrency.currency = new ArrayList();
            moneyBox.addmoney(totalPrice);
            PT_MONEY_ITEM ptMoneyItem = moneyBox.getMoneyItem(0);
            PT_MONEY_ITEM ptMoneyItemPay = new PT_MONEY_ITEM();
            ptMoneyItemPay.count = Integer.valueOf(totalPrice);
            res_npc_shop_item_sell.info.paymentcurrency.currency.add(ptMoneyItemPay);
            res_npc_shop_item_sell.info.currency = new PT_CURRENCY_REWARD_INFO();
            res_npc_shop_item_sell.info.currency.currency = new ArrayList();
            res_npc_shop_item_sell.info.currency.currency.add(ptMoneyItem);
        }
        role.save();
        res_npc_shop_item_sell.transId = req_npc_shop_item_sell.transId;
        MessagePusher.pushMessage(session, res_npc_shop_item_sell);
    }

    @RequestMapping
    public void REQ_REPURCHASE_ITEM(IoSession session, REQ_REPURCHASE_ITEM req_repurchase_item) {
        RES_REPURCHASE_ITEM res_repurchase_item = new RES_REPURCHASE_ITEM();
        Role role = SessionUtils.getRoleBySession(session);
        boolean success = this.bagService.repurchaseItems(role, req_repurchase_item.storageguids);
        if (success) {
            res_repurchase_item.storageguids = req_repurchase_item.storageguids;
            role.save();
        } else {
            res_repurchase_item.error = Integer.valueOf(1);
        }
        res_repurchase_item.transId = req_repurchase_item.transId;
        MessagePusher.pushMessage(session, res_repurchase_item);
    }

    @RequestMapping
    public void ReqRepurchaseItemStorageList(IoSession session, REQ_REPURCHASE_ITEM_STORAGE_LIST reqRepurchaseItemStorageList) {
        Role role = SessionUtils.getRoleBySession(session);
        RES_REPURCHASE_ITEM_STORAGE_LIST resRepurchaseItemStorageList0 = new RES_REPURCHASE_ITEM_STORAGE_LIST();
        RePurStoItemBox rePurStoItemBox = role.getRePurStoItem();
        resRepurchaseItemStorageList0.storageitems = new PT_REPURCHASE_STORAGE_LIST();
        List<PT_REPURCHASE_EQUIP> equipitems = rePurStoItemBox.getEquipitems();
        List<PT_REPURCHASE_EQUIP> titleitems = rePurStoItemBox.getTitleitems();
        List<PT_REPURCHASE_STACKABLE> consumeitems = rePurStoItemBox.getConsumeitems();
        List<PT_REPURCHASE_STACKABLE> materialitems = rePurStoItemBox.getMaterialitems();
        List<PT_REPURCHASE_STACKABLE> carditems = rePurStoItemBox.getCarditems();
        List<PT_REPURCHASE_STACKABLE> emblemitems = rePurStoItemBox.getEmblemitems();
        if (!Util.isEmpty(equipitems))
            resRepurchaseItemStorageList0.storageitems.equipitems = equipitems;
        if (!Util.isEmpty(titleitems))
            resRepurchaseItemStorageList0.storageitems.titleitems = titleitems;
        if (!Util.isEmpty(consumeitems))
            resRepurchaseItemStorageList0.storageitems.consumeitems = consumeitems;
        if (!Util.isEmpty(materialitems))
            resRepurchaseItemStorageList0.storageitems.materialitems = materialitems;
        if (!Util.isEmpty(carditems))
            resRepurchaseItemStorageList0.storageitems.carditems = carditems;
        if (!Util.isEmpty(emblemitems))
            resRepurchaseItemStorageList0.storageitems.emblemitems = emblemitems;
        resRepurchaseItemStorageList0.transId = reqRepurchaseItemStorageList.transId;
        MessagePusher.pushMessage(session, resRepurchaseItemStorageList0);
    }

    @RequestMapping
    public void REQ_ADVENTUREBOOK_UPDATE_CONDITION(IoSession session, REQ_ADVENTUREBOOK_UPDATE_CONDITION req_adventurebook_update_condition) {
        String authKey = req_adventurebook_update_condition.authkey;
        List<Integer> list = req_adventurebook_update_condition.conditionindexes;
        RES_ADVENTUREBOOK_UPDATE_CONDITION res_adventurebook_update_condition = new RES_ADVENTUREBOOK_UPDATE_CONDITION();
        res_adventurebook_update_condition.transId = req_adventurebook_update_condition.transId;
        MessagePusher.pushMessage(session, res_adventurebook_update_condition);
        NOTIFY_ADVENTUREBOOK_UPDATE_CONDITION notify_adventurebook_update_condition = new NOTIFY_ADVENTUREBOOK_UPDATE_CONDITION();
        notify_adventurebook_update_condition.conditioninfos = new ArrayList();
        for (Integer i : list) {
            PT_ADVENTUREBOOK_OPEN_CONDITION pt_adventurebook_open_condition = new PT_ADVENTUREBOOK_OPEN_CONDITION();
            pt_adventurebook_open_condition.cindex = i;
            pt_adventurebook_open_condition.cstate = Integer.valueOf(1);
            notify_adventurebook_update_condition.conditioninfos.add(pt_adventurebook_open_condition);
        }
        MessagePusher.pushMessage(session, notify_adventurebook_update_condition);
    }

    @RequestMapping
    public void ReqSendStorage(IoSession session, REQ_SEND_STORAGE reqSendStorage) {
        RES_SEND_STORAGE resSendStorage = new RES_SEND_STORAGE();
        List<SendItem_GuidInfo> guids = reqSendStorage.guids;
        List<SendItem_Info> indexes = reqSendStorage.indexes;
        Role role = SessionUtils.getRoleBySession(session);
        if (reqSendStorage.type.intValue() == 1) {
            if (reqSendStorage.storage == null) {
                for (SendItem_GuidInfo guidInfo : guids) {
                    long guid = guidInfo.guid.longValue();
                    PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
                    if (ptEquip == null) {
                        ptEquip = role.getTitleBox().getTitle(guid);
                        if (ptEquip == null) {
                            PT_AVATAR_ITEM ptAvatarItem = role.getAvatarBox().getAvatar(guid);
                            if (ptAvatarItem == null)
                                continue;
                            role.getAvatarBox().remove(guid);
                            role.getCharStorageBox().getAvataritems().add(ptAvatarItem);
                            continue;
                        }
                        role.getTitleBox().removeTitle(guid);
                        role.getCharStorageBox().getTitleitems().add(ptEquip);
                        continue;
                    }
                    role.getEquipBox().removeEquip(guid);
                    role.getCharStorageBox().getEquipitems().add(ptEquip);
                }
            } else {
                Account account = SessionUtils.getAccountBySession(session);
                for (SendItem_GuidInfo guidInfo : guids) {
                    long guid = guidInfo.guid.longValue();
                    PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
                    if (ptEquip == null) {
                        ptEquip = role.getTitleBox().getTitle(guid);
                        if (ptEquip == null) {
                            PT_AVATAR_ITEM ptAvatarItem = role.getAvatarBox().getAvatar(guid);
                            if (ptAvatarItem == null)
                                continue;
                            role.getAvatarBox().remove(guid);
                            account.getAdStorageBox().getAvataritems().add(ptAvatarItem);
                            continue;
                        }
                        role.getTitleBox().removeTitle(guid);
                        account.getAdStorageBox().getTitleitems().add(ptEquip);
                        continue;
                    }
                    role.getEquipBox().removeEquip(guid);
                    account.getAdStorageBox().getEquipitems().add(ptEquip);
                }
            }
        } else if (reqSendStorage.type.intValue() == 2) {
            if (reqSendStorage.storage == null) {
                for (SendItem_Info indexs : indexes) {
                    if (role.getCharStorageBox().getMaterialitems().size() > 0) {
                        PT_STACKABLE ptStackable = role.getCharStorageBox().getMaterial(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            role.getCharStorageBox().getMaterialitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        role.getCharStorageBox().getMaterialitems().add(ptStackable);
                    }
                    role.getMaterialBox().updateMaterialSub(indexs.index.intValue(), indexs.count.intValue());
                }
            } else {
                Account account = SessionUtils.getAccountBySession(session);
                for (SendItem_Info indexs : indexes) {
                    if (account.getAdStorageBox().getMaterialitems().size() > 0) {
                        PT_STACKABLE ptStackable = account.getAdStorageBox().getMaterial(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            account.getAdStorageBox().getMaterialitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        account.getAdStorageBox().getMaterialitems().add(ptStackable);
                    }
                    role.getMaterialBox().updateMaterialSub(indexs.index.intValue(), indexs.count.intValue());
                }
                account.save();
            }
        } else if (reqSendStorage.type.intValue() == 4) {
            if (reqSendStorage.storage == null) {
                for (SendItem_Info indexs : indexes) {
                    if (role.getCharStorageBox().getEmblemitems().size() > 0) {
                        PT_STACKABLE ptStackable = role.getCharStorageBox().getEmblem(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            role.getCharStorageBox().getEmblemitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        role.getCharStorageBox().getEmblemitems().add(ptStackable);
                    }
                    role.getEmblemBox().updateEmblemSub(indexs.index.intValue(), indexs.count.intValue());
                }
            } else {
                Account account = SessionUtils.getAccountBySession(session);
                for (SendItem_Info indexs : indexes) {
                    if (account.getAdStorageBox().getEmblemitems().size() > 0) {
                        PT_STACKABLE ptStackable = account.getAdStorageBox().getEmblem(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            account.getAdStorageBox().getEmblemitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        account.getAdStorageBox().getEmblemitems().add(ptStackable);
                    }
                    role.getEmblemBox().updateEmblemSub(indexs.index.intValue(), indexs.count.intValue());
                }
                account.save();
            }
        } else if (reqSendStorage.type.intValue() == 5) {
            if (reqSendStorage.storage == null) {
                for (SendItem_Info indexs : indexes) {
                    if (role.getCharStorageBox().getCarditems().size() > 0) {
                        PT_STACKABLE ptStackable = role.getCharStorageBox().getCard(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            role.getCharStorageBox().getCarditems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        role.getCharStorageBox().getCarditems().add(ptStackable);
                    }
                    role.getCardBox().updateCardSub(indexs.index.intValue(), indexs.count.intValue());
                }
            } else {
                Account account = SessionUtils.getAccountBySession(session);
                for (SendItem_Info indexs : indexes) {
                    if (account.getAdStorageBox().getCarditems().size() > 0) {
                        PT_STACKABLE ptStackable = account.getAdStorageBox().getCard(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            account.getAdStorageBox().getCarditems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        account.getAdStorageBox().getCarditems().add(ptStackable);
                    }
                    role.getCardBox().updateCardSub(indexs.index.intValue(), indexs.count.intValue());
                }
                account.save();
            }
        } else if (reqSendStorage.type.intValue() == 10) {
            if (reqSendStorage.storage == null) {
                for (SendItem_Info indexs : indexes) {
                    if (role.getCharStorageBox().getConsumeitems().size() > 0) {
                        PT_STACKABLE ptStackable = role.getCharStorageBox().getConsume(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            role.getCharStorageBox().getConsumeitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        role.getCharStorageBox().getConsumeitems().add(ptStackable);
                    }
                    role.getConsumableBox().updateConsumeSub(indexs.index.intValue(), indexs.count.intValue());
                }
            } else {
                Account account = SessionUtils.getAccountBySession(session);
                for (SendItem_Info indexs : indexes) {
                    if (account.getAdStorageBox().getConsumeitems().size() > 0) {
                        PT_STACKABLE ptStackable = account.getAdStorageBox().getConsume(indexs.index.intValue());
                        if (ptStackable == null) {
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = indexs.index;
                            ptStackable.count = indexs.count;
                            account.getAdStorageBox().getConsumeitems().add(ptStackable);
                        } else {
                            PT_STACKABLE pT_STACKABLE = ptStackable;
                            pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() + indexs.count.intValue());
                        }
                    } else {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = indexs.index;
                        ptStackable.count = indexs.count;
                        account.getAdStorageBox().getConsumeitems().add(ptStackable);
                    }
                    role.getConsumableBox().updateConsumeSub(indexs.index.intValue(), indexs.count.intValue());
                }
                account.save();
            }
        }
        role.save();
        resSendStorage.transId = reqSendStorage.transId;
        MessagePusher.pushMessage(session, resSendStorage);
    }

    @RequestMapping
    public void REQ_SEND_INVEN(IoSession session, REQ_SEND_INVEN reqSendInven) {
        RES_SEND_INVEN resSendInven = new RES_SEND_INVEN();
        Role role = SessionUtils.getRoleBySession(session);
        if (reqSendInven.storage == null) {
            if (reqSendInven.equipitems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.equipitems) {
                    PT_EQUIP ptEquip = role.getCharStorageBox().getEquipItem(equip.guid.longValue());
                    role.getEquipBox().addEquip(ptEquip);
                    role.getCharStorageBox().removeEquipItem(equip.guid.longValue());
                }
            if (reqSendInven.consumeitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.consumeitems) {
                    role.getConsumableBox().updateConsumeAdd(equip.index.intValue(), equip.count.intValue());
                    role.getCharStorageBox().subConsumeitems(equip.index.intValue(), equip.count.intValue(), false);
                }
            if (reqSendInven.titleitems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.titleitems) {
                    PT_EQUIP ptEquip = role.getCharStorageBox().getTitileItem(equip.guid.longValue());
                    role.getTitleBox().addTitle(ptEquip);
                    role.getCharStorageBox().removeTitleItem(equip.guid.longValue());
                }
            if (reqSendInven.avataritems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.avataritems) {
                    PT_AVATAR_ITEM ptAvatarItem = role.getCharStorageBox().getAvatar(equip.guid.longValue());
                    role.getAvatarBox().addAvatar(ptAvatarItem);
                    role.getCharStorageBox().removeAvatar(equip.guid.longValue());
                }
            if (reqSendInven.materialitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.materialitems) {
                    role.getMaterialBox().updateMaterialAdd(equip.index.intValue(), equip.count.intValue());
                    role.getCharStorageBox().subMaterial(equip.index.intValue(), equip.count.intValue(), false);
                }
            if (reqSendInven.emblemitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.emblemitems) {
                    role.getEmblemBox().updateEmblemAdd(equip.index.intValue(), equip.count.intValue());
                    role.getCharStorageBox().subEmblemitems(equip.index.intValue(), equip.count.intValue());
                }
            if (reqSendInven.carditems.size() > 0)
                for (SendItem_Info equip : reqSendInven.carditems) {
                    role.getCardBox().updateCardAdd(equip.index.intValue(), equip.count.intValue());
                    role.getCharStorageBox().subCarditems(equip.index.intValue(), equip.count.intValue());
                }
            if (reqSendInven.sdavataritems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.sdavataritems) {
                    PT_AVATAR_ITEM ptAvatarItem = role.getCharStorageBox().getAvatar(equip.guid.longValue());
                    role.getAvatarBox().addAvatar(ptAvatarItem);
                    role.getCharStorageBox().removeAvatar(equip.guid.longValue());
                }
        } else {
            Account account = SessionUtils.getAccountBySession(session);
            if (reqSendInven.equipitems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.equipitems) {
                    PT_EQUIP ptEquip = role.getCharStorageBox().getEquipItem(equip.guid.longValue());
                    role.getEquipBox().addEquip(ptEquip);
                    account.getAdStorageBox().removeEquipItem(equip.guid.longValue());
                }
            if (reqSendInven.consumeitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.consumeitems) {
                    role.getConsumableBox().updateConsumeAdd(equip.index.intValue(), equip.count.intValue());
                    account.getAdStorageBox().subConsumeitems(equip.index.intValue(), equip.count.intValue(), false);
                }
            if (reqSendInven.titleitems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.titleitems) {
                    PT_EQUIP ptEquip = role.getCharStorageBox().getTitileItem(equip.guid.longValue());
                    role.getTitleBox().addTitle(ptEquip);
                    account.getAdStorageBox().removeTitleItem(equip.guid.longValue());
                }
            if (reqSendInven.avataritems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.avataritems) {
                    PT_AVATAR_ITEM ptAvatarItem = role.getCharStorageBox().getAvatar(equip.guid.longValue());
                    role.getAvatarBox().addAvatar(ptAvatarItem);
                    account.getAdStorageBox().removeAvatar(equip.guid.longValue());
                }
            if (reqSendInven.materialitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.materialitems) {
                    role.getMaterialBox().updateMaterialAdd(equip.index.intValue(), equip.count.intValue());
                    account.getAdStorageBox().subMaterial(equip.index.intValue(), equip.count.intValue(), false);
                }
            if (reqSendInven.emblemitems.size() > 0)
                for (SendItem_Info equip : reqSendInven.emblemitems) {
                    role.getEmblemBox().updateEmblemAdd(equip.index.intValue(), equip.count.intValue());
                    account.getAdStorageBox().subEmblemitems(equip.index.intValue(), equip.count.intValue());
                }
            if (reqSendInven.carditems.size() > 0)
                for (SendItem_Info equip : reqSendInven.carditems) {
                    role.getCardBox().updateCardAdd(equip.index.intValue(), equip.count.intValue());
                    account.getAdStorageBox().subCarditems(equip.index.intValue(), equip.count.intValue());
                }
            if (reqSendInven.sdavataritems.size() > 0)
                for (SendItem_GuidInfo equip : reqSendInven.sdavataritems) {
                    PT_AVATAR_ITEM ptAvatarItem = role.getCharStorageBox().getAvatar(equip.guid.longValue());
                    role.getAvatarBox().addAvatar(ptAvatarItem);
                    account.getAdStorageBox().removeAvatar(equip.guid.longValue());
                }
        }
        resSendInven.transId = reqSendInven.transId;
        MessagePusher.pushMessage(session, resSendInven);
    }

    @RequestMapping
    public void ReqCharStorageList(IoSession session, REQ_CHAR_STORAGE_LIST reqCharStorageList) {
        Role role = SessionUtils.getRoleBySession(session);
        RES_CHAR_STORAGE_LIST resCharStorageList = new RES_CHAR_STORAGE_LIST();
        CharStorageBox charStorageBox = role.getCharStorageBox();
        resCharStorageList.equipitems = new ArrayList();
        resCharStorageList.consumeitems = new ArrayList();
        resCharStorageList.titleitems = new ArrayList();
        resCharStorageList.flagitems = new ArrayList();
        resCharStorageList.materialitems = new ArrayList();
        resCharStorageList.emblemitems = new ArrayList();
        resCharStorageList.carditems = new ArrayList();
        resCharStorageList.avataritems = new ArrayList();
        resCharStorageList.cartifactitems = new ArrayList();
        resCharStorageList.epicpieceitems = new ArrayList();
        resCharStorageList.creatureitems = new ArrayList();
        int sindex = 0;
        if (charStorageBox.getEquipitems().size() > 0)
            for (PT_EQUIP equip : charStorageBox.getEquipitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.equipitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getConsumeitems().size() > 0)
            for (PT_STACKABLE equip : charStorageBox.getConsumeitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.consumeitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getTitleitems().size() > 0)
            for (PT_EQUIP equip : charStorageBox.getTitleitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.titleitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getFlagitems().size() > 0)
            for (PT_EQUIP equip : charStorageBox.getFlagitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.flagitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getMaterialitems().size() > 0)
            for (PT_STACKABLE equip : charStorageBox.getMaterialitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.materialitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getEmblemitems().size() > 0)
            for (PT_STACKABLE equip : charStorageBox.getEmblemitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.emblemitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getCarditems().size() > 0)
            for (PT_STACKABLE equip : charStorageBox.getCarditems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.carditems.add(equip);
                sindex++;
            }
        if (charStorageBox.getAvataritems().size() > 0)
            for (PT_AVATAR_ITEM equip : charStorageBox.getAvataritems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.avataritems.add(equip);
                sindex++;
            }
        if (charStorageBox.getCartifactitems().size() > 0)
            for (PT_ARTIFACT equip : charStorageBox.getCartifactitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.cartifactitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getEpicpieceitems().size() > 0)
            for (PT_STACKABLE equip : charStorageBox.getEpicpieceitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.epicpieceitems.add(equip);
                sindex++;
            }
        if (charStorageBox.getCreatureitems().size() > 0)
            for (PT_CREATURE equip : charStorageBox.getCreatureitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resCharStorageList.creatureitems.add(equip);
                sindex++;
            }
        resCharStorageList.line = Integer.valueOf(role.getCharStorageBox().getLine());
        resCharStorageList.transId = reqCharStorageList.transId;
        MessagePusher.pushMessage(session, resCharStorageList);
    }

    @RequestMapping
    public void ReqAdventureStorageList(IoSession session, REQ_ADVENTURE_STORAGE_LIST reqAdventureStorageList) {
        Account account = SessionUtils.getAccountBySession(session);
        RES_ADVENTURE_STORAGE_LIST resAdventureStorageList = new RES_ADVENTURE_STORAGE_LIST();
        AdStorageBox storageBox = account.getAdStorageBox();
        resAdventureStorageList.equipitems = new ArrayList();
        resAdventureStorageList.consumeitems = new ArrayList();
        resAdventureStorageList.titleitems = new ArrayList();
        resAdventureStorageList.flagitems = new ArrayList();
        resAdventureStorageList.materialitems = new ArrayList();
        resAdventureStorageList.emblemitems = new ArrayList();
        resAdventureStorageList.carditems = new ArrayList();
        resAdventureStorageList.avataritems = new ArrayList();
        resAdventureStorageList.cartifactitems = new ArrayList();
        resAdventureStorageList.epicpieceitems = new ArrayList();
        resAdventureStorageList.creatureitems = new ArrayList();
        int sindex = 0;
        if (storageBox.getEquipitems().size() > 0)
            for (PT_EQUIP equip : storageBox.getEquipitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.equipitems.add(equip);
                sindex++;
            }
        if (storageBox.getConsumeitems().size() > 0)
            for (PT_STACKABLE equip : storageBox.getConsumeitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.consumeitems.add(equip);
                sindex++;
            }
        if (storageBox.getTitleitems().size() > 0)
            for (PT_EQUIP equip : storageBox.getTitleitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.titleitems.add(equip);
                sindex++;
            }
        if (storageBox.getFlagitems().size() > 0)
            for (PT_EQUIP equip : storageBox.getFlagitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.flagitems.add(equip);
                sindex++;
            }
        if (storageBox.getMaterialitems().size() > 0)
            for (PT_STACKABLE equip : storageBox.getMaterialitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.materialitems.add(equip);
                sindex++;
            }
        if (storageBox.getEmblemitems().size() > 0)
            for (PT_STACKABLE equip : storageBox.getEmblemitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.emblemitems.add(equip);
                sindex++;
            }
        if (storageBox.getCarditems().size() > 0)
            for (PT_STACKABLE equip : storageBox.getCarditems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.carditems.add(equip);
                sindex++;
            }
        if (storageBox.getAvataritems().size() > 0)
            for (PT_AVATAR_ITEM equip : storageBox.getAvataritems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.avataritems.add(equip);
                sindex++;
            }
        if (storageBox.getCartifactitems().size() > 0)
            for (PT_ARTIFACT equip : storageBox.getCartifactitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.cartifactitems.add(equip);
                sindex++;
            }
        if (storageBox.getEpicpieceitems().size() > 0)
            for (PT_STACKABLE equip : storageBox.getEpicpieceitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.epicpieceitems.add(equip);
                sindex++;
            }
        if (storageBox.getCreatureitems().size() > 0)
            for (PT_CREATURE equip : storageBox.getCreatureitems()) {
                equip.sindex = Integer.valueOf(sindex);
                resAdventureStorageList.creatureitems.add(equip);
                sindex++;
            }
        resAdventureStorageList.line = Integer.valueOf(account.getAdStorageBox().getLine());
        resAdventureStorageList.transId = reqAdventureStorageList.transId;
        MessagePusher.pushMessage(session, resAdventureStorageList);
    }

    @RequestMapping
    public void REQ_STORAGE_EXTEND(IoSession session, REQ_STORAGE_EXTEND reqStorageExtend) {
        Account account = SessionUtils.getAccountBySession(session);
        Role role = SessionUtils.getRoleBySession(session);
        RES_STORAGE_EXTEND resStorageExtend = new RES_STORAGE_EXTEND();
        PT_MONEY_ITEM tylorItem = account.getMoneyBox().getTylor();
        int tylorCnt = tylorItem.count.intValue();
        int level = 0;
        if (reqStorageExtend.storage == null) {
            level = role.getCharStorageBox().getLine();
            int cost = getcost(0, level);
            if (tylorCnt >= cost) {
                tylorItem.count = Integer.valueOf(tylorCnt - cost);
                level++;
                role.getCharStorageBox().setLine(level);
                account.getMoneyBox().updateTylor(tylorItem);
            } else {
                BagController.log.error("ERROR====账户余额不足");
            }
            role.save();
        } else if (reqStorageExtend.storage.intValue() == 1) {
            level = account.getAdStorageBox().getLine();
            int cost = getcost(1, level);
            if (tylorCnt >= cost) {
                tylorItem.count = Integer.valueOf(tylorCnt - cost);
                level++;
                account.getMoneyBox().updateTylor(tylorItem);
                account.getAdStorageBox().setLine(level);
            } else {
                BagController.log.error("账户余额不足");
            }
        }
        resStorageExtend.line = Integer.valueOf(level);
        resStorageExtend.transId = reqStorageExtend.transId;
        account.save();
        MessagePusher.pushMessage(session, resStorageExtend);
    }

    @RequestMapping
    public void REQ_ITEM_USE(IoSession session, REQ_ITEM_USE req_item_use) {
        log.warn("===REQ_ITEM_USE===index:{}", req_item_use.index);
        Role role = SessionUtils.getRoleBySession(session);
        Account account = SessionUtils.getAccountBySession(session);
        int index = req_item_use.index.intValue();
        int type = 0;
        int count = req_item_use.count.intValue();
        boolean issuccess = true;
        if (req_item_use.type != null)
            type = req_item_use.type.intValue();
        RES_ITEM_USE res_item_use = new RES_ITEM_USE();
        res_item_use.index = Integer.valueOf(index);
        res_item_use.result = new PT_ITEM_USE_RESULT();
        res_item_use.removeitems = new PT_REMOVEITEMS();
        if (index == 2013106365) {
            res_item_use.info = new PT_CONTENTS_REWARD_INFO();
            res_item_use.info.items = new PT_ITEM_REWARD_INFO();
            res_item_use.info.items.inventory = new PT_ITEMS();
            res_item_use.info.items.inventory.consumeitems = new ArrayList();
            PT_STACKABLE ptStackable = new PT_STACKABLE();
            ptStackable.index = Integer.valueOf(1990000051);
            ptStackable.count = Integer.valueOf(1);
            ptStackable.acquisitiontime = Long.valueOf(TimeUtil.currS());
            res_item_use.info.items.inventory.consumeitems.add(ptStackable);
            this.roleService.addConsumable(role, ptStackable);
        } else if (index == 1990000051) {
            int growtype = Integer.parseInt(req_item_use.input);
            res_item_use.result.growth = Integer.valueOf(growtype);
            res_item_use.result.totalexp = Integer.valueOf(4414035);
            res_item_use.result.level = Integer.valueOf(28);
            res_item_use.result.changecount = Integer.valueOf(194530);
            res_item_use.result.adventureunionlevel = Integer.valueOf(1);
            res_item_use.result.adventureunionexp = Long.valueOf(1324L);
            this.roleService.lvTo28(session, role.getJob(), growtype);
        } else if (index == 2013106366) {
            res_item_use.info = new PT_CONTENTS_REWARD_INFO();
            res_item_use.info.items = new PT_ITEM_REWARD_INFO();
            res_item_use.info.items.inventory = new PT_ITEMS();
            res_item_use.info.items.inventory.consumeitems = new ArrayList();
            PT_STACKABLE ptStackable = new PT_STACKABLE();
            ptStackable.index = Integer.valueOf(1990000052);
            ptStackable.count = Integer.valueOf(1);
            ptStackable.acquisitiontime = Long.valueOf(TimeUtil.currS());
            res_item_use.info.items.inventory.consumeitems.add(ptStackable);
            this.roleService.addConsumable(role, ptStackable);
        } else if (index == 1990000052) {
            int growtype = Integer.parseInt(req_item_use.input);
            res_item_use.result.growth = Integer.valueOf(growtype);
            res_item_use.result.totalexp = Integer.valueOf(107836272);
            res_item_use.result.level = Integer.valueOf(55);
            if (role.getJob() == 0 && role.getGrowtype() == 1) {
                res_item_use.result.changecount = Integer.valueOf(327306);
            } else if (role.getJob() == 0 && role.getGrowtype() == 2) {
                res_item_use.result.changecount = Integer.valueOf(285257);
            } else if (role.getJob() == 0 && role.getGrowtype() == 3) {
                res_item_use.result.changecount = Integer.valueOf(487767);
            } else if (role.getJob() == 0 && role.getGrowtype() == 4) {
                res_item_use.result.changecount = Integer.valueOf(591467);
            } else if (role.getJob() == 1 && role.getGrowtype() == 1) {
                res_item_use.result.changecount = Integer.valueOf(208401);
            } else if (role.getJob() == 1 && role.getGrowtype() == 2) {
                res_item_use.result.changecount = Integer.valueOf(194531);
            } else if (role.getJob() == 2 && role.getGrowtype() == 1) {
                res_item_use.result.changecount = Integer.valueOf(183911);
            } else if (role.getJob() == 2 && role.getGrowtype() == 2) {
                res_item_use.result.changecount = Integer.valueOf(400494);
            } else if (role.getJob() == 2 && role.getGrowtype() == 3) {
                res_item_use.result.changecount = Integer.valueOf(156789);
            } else if (role.getJob() == 2 && role.getGrowtype() == 4) {
                res_item_use.result.changecount = Integer.valueOf(155619);
            } else if (role.getJob() == 3 && role.getGrowtype() == 1) {
                res_item_use.result.changecount = Integer.valueOf(154057);
            } else if (role.getJob() == 3 && role.getGrowtype() == 4) {
                res_item_use.result.changecount = Integer.valueOf(121658);
            } else if (role.getJob() == 14 && role.getGrowtype() == 1) {
                res_item_use.result.changecount = Integer.valueOf(307303);
            } else {
                res_item_use.result.changecount = Integer.valueOf(194531);
            }
            res_item_use.result.secondgrowtype = Integer.valueOf(1);
            role.setSecgrowtype(1);
            res_item_use.result.adventureunionlevel = Integer.valueOf(8);
            res_item_use.result.adventureunionexp = Long.valueOf(32344L);
            res_item_use.info = new PT_CONTENTS_REWARD_INFO();
            res_item_use.info.items = new PT_ITEM_REWARD_INFO();
            res_item_use.info.items.inventory = new PT_ITEMS();
            res_item_use.info.items.inventory.consumeitems = new ArrayList();
            res_item_use.info.items.inventory.materialitems = new ArrayList();
            ConsumableBox consumableBox = role.getConsumableBox();
            if (consumableBox == null)
                consumableBox = new ConsumableBox();
            PT_STACKABLE ptStackable8 = new PT_STACKABLE();
            ptStackable8.index = Integer.valueOf(2013106360);
            ptStackable8.count = Integer.valueOf(1);
            consumableBox.addConsumable(ptStackable8);
            res_item_use.info.items.inventory.consumeitems.add(ptStackable8);
            PT_STACKABLE ptStackable19 = new PT_STACKABLE();
            ptStackable19.index = Integer.valueOf(2013103646);
            ptStackable19.count = Integer.valueOf(1);
            ptStackable19.bind = Boolean.valueOf(true);
            consumableBox.addConsumable(ptStackable19);
            res_item_use.info.items.inventory.consumeitems.add(ptStackable19);
            CardBox cardBox = role.getCardBox();
            if (cardBox == null) {
                cardBox = new CardBox();
                role.setCardBox(cardBox);
            }
            EmblemBox emblemBox = role.getEmblemBox();
            if (emblemBox == null) {
                emblemBox = new EmblemBox();
                role.setEmblemBox(emblemBox);
            }
            role.setConsumableBox(consumableBox);
            this.roleService.lvTo55(session, role.getJob(), growtype);
        } else if (index != 2013106329) {
            if (index == 2013104235) {
                int option = EquipDataPool.changeEpic(req_item_use.guid.longValue(), role);
                res_item_use.guid = req_item_use.guid;
                res_item_use.result.option = Integer.valueOf(option);
                role.getMoneyBox().submoney(100000);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.currency = new PT_CURRENCY_REWARD_INFO();
                res_item_use.info.currency.currency = new ArrayList();
                PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem.count = (role.getMoneyBox().getMoneyItem(0)).count;
                res_item_use.info.currency.currency.add(ptMoneyItem);
            } else if (index == 2013106503 || index == 2013103646) {
                PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(req_item_use.guid.longValue());
                if (ptEquipped == null) {
                    PT_EQUIP ptEquip = role.getEquipBox().getEquip(req_item_use.guid.longValue());
                    ptEquip.setUpgrade(Integer.valueOf(12));
                    ptEquip.setUpgradepoint(Integer.valueOf(0));
                    role.getEquipBox().addEquip(ptEquip);
                } else {
                    ptEquipped.setUpgrade(Integer.valueOf(12));
                    ptEquipped.setUpgradepoint(Integer.valueOf(0));
                    role.getEquippedBox().updateEquip(ptEquipped);
                }
                res_item_use.result = new PT_ITEM_USE_RESULT();
                res_item_use.result.result = Boolean.valueOf(true);
                res_item_use.result.upgrade = Integer.valueOf(12);
                res_item_use.guid = req_item_use.guid;
            } else if (index == 2013105097 || index == 2013103769 || index == 2013103666 || index == 2013103633 || index == 2013103631) {
                PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(req_item_use.guid.longValue());
                int random = (int) (Math.random() * 100.0D);
                int rate = getReinforceRate(index);
                res_item_use.result = new PT_ITEM_USE_RESULT();
                if (ptEquipped == null) {
                    PT_EQUIP ptEquip = role.getEquipBox().getEquip(req_item_use.guid.longValue());
                    if (random < rate) {
                        ptEquip.setUpgrade(Integer.valueOf(12));
                        ptEquip.setUpgradepoint(Integer.valueOf(0));
                        role.getEquipBox().addEquip(ptEquip);
                        res_item_use.result.result = Boolean.valueOf(true);
                        res_item_use.result.upgrade = Integer.valueOf(12);
                    } else {
                        res_item_use.result.result = Boolean.valueOf(false);
                        res_item_use.result.upgrade = ptEquip.upgrade;
                    }
                } else if (random < rate) {
                    ptEquipped.setUpgrade(Integer.valueOf(12));
                    ptEquipped.setUpgradepoint(Integer.valueOf(0));
                    role.getEquippedBox().updateEquip(ptEquipped);
                    res_item_use.result.result = Boolean.valueOf(true);
                    res_item_use.result.upgrade = Integer.valueOf(12);
                } else {
                    res_item_use.result.result = Boolean.valueOf(false);
                    res_item_use.result.upgrade = ptEquipped.upgrade;
                }
                res_item_use.guid = req_item_use.guid;
            } else if (index == 2013106360) {
                PT_EQUIP ptequip = EquipDataPool.createEquip(req_item_use.selectitemindex.intValue());
                role.getEquipBox().addEquip(ptequip);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.equipitems = new ArrayList();
                res_item_use.info.items.inventory.equipitems.add(ptequip);
                res_item_use.result = new PT_ITEM_USE_RESULT();
            } else if (index == 2013101108 || index == 2013103608 || index == 2013106056) {
                count = 1000 * req_item_use.count.intValue();
                if (index == 2013106056)
                    count = 40000 * req_item_use.count.intValue();
                account.getMoneyBox().addTylor(count);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
                res_item_use.info.paymentcurrency.currency = new ArrayList();
                PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem.index = Integer.valueOf(2013000001);
                ptMoneyItem.count = Integer.valueOf(count);
                res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                res_item_use.result = new PT_ITEM_USE_RESULT();
            } else if (index == 2013106404 || index == 2013106405 || index == 2013106406 || index == 2013106407 || index == 2013106408 || index == 2013106409 || index == 2013106611 || index == 2013106597 || index == 2013103644 || index == 2013106158) {
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.consumeitems = new ArrayList();
                if (req_item_use.selectitemindex != null) {
                    DEF_ITEM_CONSUMABLE ptStackable = role.getConsumableBox().getConsumable(req_item_use.selectitemindex.intValue());
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = req_item_use.selectitemindex;
                    ptStackable1.count = req_item_use.count;
                    if (ptStackable == null) {
                        role.getConsumableBox().addConsumable(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + req_item_use.count.intValue());
                        role.getConsumableBox().addConsumable(ptStackable);
                    }
                    res_item_use.info.items.inventory.consumeitems.add(ptStackable1);
                } else {
                    List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                    for (GiftContent giftContent : giftContents) {
                        DEF_ITEM_CONSUMABLE ptStackable = role.getConsumableBox().getConsumable(giftContent.id);
                        PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                        ptStackable1.index = Integer.valueOf(giftContent.id);
                        ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        if (ptStackable == null) {
                            role.getConsumableBox().addConsumable(ptStackable1);
                        } else {
                            ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                            role.getConsumableBox().addConsumable(ptStackable);
                        }
                        res_item_use.info.items.inventory.consumeitems.add(ptStackable1);
                    }
                }
                res_item_use.result = new PT_ITEM_USE_RESULT();
            } else if (index == 2013106380 || index == 2013106381 || index == 2013106382 || index == 2013106383 || index == 2013106384 || index == 2013106385 || index == 2013106386 || index == 2013106387 || index == 2013106388 || index == 2013106389 || index == 2013106390 || index == 2013106391 || index == 2013106392 || index == 2013106393 || index == 2013106394 || index == 2013106395 || index == 2013106396 || index == 2013106397 || index == 2013106398 || index == 2013106399 || index == 2013106400 || index == 2013106401 || index == 2013106402 || index == 2013106403) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.avataritems = new ArrayList();
                for (GiftContent giftContent : giftContents) {
                    PT_AVATAR_ITEM ptAvatarItem = new PT_AVATAR_ITEM();
                    ptAvatarItem.index = Integer.valueOf(giftContent.id);
                    ptAvatarItem.guid = Long.valueOf(IdGenerator.getNextId());
                    role.getAvatarBox().addAvatar(ptAvatarItem);
                    res_item_use.info.items.inventory.avataritems.add(ptAvatarItem);
                }
                res_item_use.result = new PT_ITEM_USE_RESULT();
            } else if (index == 2013106374 || index == 2013106375 || index == 2013106376 || index == 2013106377 || index == 2013106378 || index == 2013106379) {
                // 2013106374 暑假套
                // 取得里内容
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                // 奖励品信息
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                // 奖励品明细信息
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                // item明细
                res_item_use.info.items.inventory = new PT_ITEMS();
                //堆叠信息
                res_item_use.info.items.inventory.consumeitems = new ArrayList();
                // 遍历内容取出信息
                for (GiftContent giftContent : giftContents) {
                    DEF_ITEM_CONSUMABLE ptStackable = role.getConsumableBox().getConsumable(giftContent.id);
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = Integer.valueOf(giftContent.id);
                    ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                    if (ptStackable == null) {
                        role.getConsumableBox().addConsumable(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                        role.getConsumableBox().addConsumable(ptStackable);
                    }
                    res_item_use.info.items.inventory.consumeitems.add(ptStackable1);
                }
                res_item_use.result = new PT_ITEM_USE_RESULT();
            } else if (index == 2013106026 || index == 2013106031 || index == 2013106027 || index == 2013101269 || index == 2013100888 || index == 2013104324 || index == 2013103867 || index == 2013100710 || index == 2013103578 || index == 2013103941) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.materialitems = new ArrayList();
                for (GiftContent giftContent : giftContents) {
                    if (giftContent.id == 2013000001) {
                        account.getMoneyBox().addTylor(giftContent.count);
                        res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                        res_item_use.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
                        res_item_use.info.paymentcurrency.currency = new ArrayList();
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.index = Integer.valueOf(2013000001);
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    PT_STACKABLE ptStackable = role.getMaterialBox().getMaterial(giftContent.id);
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = Integer.valueOf(giftContent.id);
                    ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                    if (ptStackable == null) {
                        role.getMaterialBox().addMaterial(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                        role.getMaterialBox().addMaterial(ptStackable);
                    }
                    res_item_use.info.items.inventory.materialitems.add(ptStackable1);
                }
            } else if (index == 2013106539 || index == 2013103863 || index == 2013106671) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.consumeitems = new ArrayList();
                res_item_use.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
                res_item_use.info.paymentcurrency.currency = new ArrayList();
                for (GiftContent giftContent : giftContents) {
                    if (giftContent.id == 2013000001) {
                        account.getMoneyBox().addTylor(giftContent.count * req_item_use.count.intValue());
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.index = Integer.valueOf(2013000001);
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    if (giftContent.id == 2013100902) {
                        role.getMoneyBox().addCnt(2013100902, giftContent.count * req_item_use.count.intValue());
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.index = Integer.valueOf(2013100902);
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    DEF_ITEM_CONSUMABLE ptStackable = role.getConsumableBox().getConsumable(giftContent.id);
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = Integer.valueOf(giftContent.id);
                    ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                    if (ptStackable == null) {
                        role.getConsumableBox().addConsumable(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                        role.getConsumableBox().addConsumable(ptStackable);
                    }
                    res_item_use.info.items.inventory.consumeitems.add(ptStackable1);
                }
            } else if (index == 2013101303 || index == 2013103516) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.carditems = new ArrayList();
                for (GiftContent giftContent : giftContents) {
                    PT_STACKABLE ptStackable = role.getCardBox().getCard(giftContent.id);
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = Integer.valueOf(giftContent.id);
                    ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                    if (ptStackable == null) {
                        role.getCardBox().addCard(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                        role.getCardBox().addCard(ptStackable);
                    }
                    res_item_use.info.items.inventory.carditems.add(ptStackable1);
                }
            } else if (index == 2013106410) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.consumeitems = new ArrayList();
                res_item_use.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
                res_item_use.info.paymentcurrency.currency = new ArrayList();
                for (GiftContent giftContent : giftContents) {
                    if (giftContent.id == 2013104144) {
                        account.getMoneyBox().addCnt(2013104144, giftContent.count);
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.index = Integer.valueOf(2013104144);
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    if (giftContent.id == 0) {
                        role.getMoneyBox().addmoney(giftContent.count * req_item_use.count.intValue());
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    if (giftContent.id == 2013100902) {
                        account.getMoneyBox().addCnt(2013100902, giftContent.count * req_item_use.count.intValue());
                        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                        ptMoneyItem.index = Integer.valueOf(2013100902);
                        ptMoneyItem.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
                        continue;
                    }
                    DEF_ITEM_CONSUMABLE ptStackable = role.getConsumableBox().getConsumable(giftContent.id);
                    PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                    ptStackable1.index = Integer.valueOf(giftContent.id);
                    ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                    if (ptStackable == null) {
                        role.getConsumableBox().addConsumable(ptStackable1);
                    } else {
                        ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                        role.getConsumableBox().addConsumable(ptStackable);
                    }
                    res_item_use.info.items.inventory.consumeitems.add(ptStackable1);
                }
            } else if (index == 2013106411) {
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.titleitems = new ArrayList();
                PT_EQUIP ptEquip = role.getTitleBox().createTitle(req_item_use.selectitemindex.intValue());
                res_item_use.info.items.inventory.titleitems.add(ptEquip);
            } else if (index == 2013106413 || index == 2013104644 || index == 2013104504) {
                // 2013106413 - 暑假套的灵气礼盒
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.avataritems = new ArrayList();
                PT_AVATAR_ITEM ptEquip = role.getAvatarBox().createAvatar(req_item_use.selectitemindex.intValue());
                res_item_use.info.items.inventory.avataritems.add(ptEquip);
            } else if (index == 2013104404) {
                count = 3300;
                account.getMoneyBox().addCera(count);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.paymentcurrency = new PT_CURRENCY_REWARD_INFO();
                res_item_use.info.paymentcurrency.currency = new ArrayList();
                PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem.index = Integer.valueOf(2);
                ptMoneyItem.count = Integer.valueOf(count);
                res_item_use.info.paymentcurrency.currency.add(ptMoneyItem);
            } else if (index == 2013103647) {
                String name = req_item_use.input;
                if (name.equals("张哥哥")) {
                    res_item_use.error = Integer.valueOf(11);
                    res_item_use.transId = req_item_use.transId;
                    MessagePusher.pushMessage(session, (Message) res_item_use);
                    return;
                }
                role.setName(name);
            }
            else if (index == 2013106021) {
                if (role.getFatigue() + 10 > 100) {
                    role.setFatigue(100);
                } else {
                    role.setFatigue(role.getFatigue() + 10);
                }
                res_item_use.result = new PT_ITEM_USE_RESULT();
                res_item_use.result.fatigue = Integer.valueOf(role.getFatigue());
            } else if (index == 2013104914 || index == 1990000505 || index == 2013104497 || index == 2013104496) {
                List<GiftContent> giftContents = ItemDataPool.getGiftList(index);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.emblemitems = new ArrayList();
                int random = (int)(Math.random() * giftContents.size());
                for (int i = 0; i < giftContents.size(); i++) {
                    GiftContent giftContent = giftContents.get(i);
                    if (i == random) {
                        PT_STACKABLE ptStackable = role.getCardBox().getCard(giftContent.id);
                        PT_STACKABLE ptStackable1 = new PT_STACKABLE();
                        ptStackable1.index = Integer.valueOf(giftContent.id);
                        ptStackable1.count = Integer.valueOf(giftContent.count * req_item_use.count.intValue());
                        if (ptStackable == null) {
                            role.getEmblemBox().addEmblem(ptStackable1);
                        } else {
                            ptStackable.count = Integer.valueOf(ptStackable.count.intValue() + giftContent.count * req_item_use.count.intValue());
                            role.getEmblemBox().addEmblem(ptStackable);
                        }
                        res_item_use.info.items.inventory.emblemitems.add(ptStackable1);
                    }
                }
            } else if (index == 2013106159 || index == 2013106199 || index == 2013106200 || index == 2013106201 || index == 2013106202 || index == 2013106205 || index == 2013106206 || index == 2013104180 || index == 2013106495 || index == 2013106502 || index == 2013106496 || index == 2013106496) {
                long guid = req_item_use.guid.longValue();
                PT_EQUIPPED equipped = role.getEquippedBox().getEquipped(guid);
                List<PT_STACKABLE> ptStackables = new ArrayList<>();
                PT_STACKABLE ptStackable = new PT_STACKABLE();
                ptStackable.index = Integer.valueOf(index);
                ptStackable.count = Integer.valueOf(1);
                ptStackables.add(ptStackable);
                PT_EQUIP title = role.getTitleBox().getTitle(guid);
                if (title == null) {
                    if (equipped == null) {
                        PT_EQUIP equip = role.getEquipBox().getEquip(guid);
                        equip.card = ptStackables;
                    } else {
                        equipped.card = ptStackables;
                    }
                } else {
                    title.card = ptStackables;
                }
                res_item_use.guid = req_item_use.guid;
                res_item_use.result.enchantindex = Integer.valueOf(index);
                if (index == 2013106201) {
                    res_item_use.result.enchant = Integer.valueOf(101004);
                } else if (index == 2013106159) {
                    res_item_use.result.enchant = Integer.valueOf(115004);
                } else if (index == 2013106199) {
                    res_item_use.result.enchant = Integer.valueOf(107003);
                } else if (index == 2013106200) {
                    res_item_use.result.enchant = Integer.valueOf(108003);
                } else if (index == 2013106202) {
                    res_item_use.result.enchant = Integer.valueOf(102004);
                } else if (index == 2013106205) {
                    res_item_use.result.enchant = Integer.valueOf(105002);
                } else if (index == 2013106206) {
                    res_item_use.result.enchant = Integer.valueOf(106002);
                } else if (index == 2013104180) {
                    res_item_use.result.enchant = Integer.valueOf(132001);
                } else if (index == 2013106495) {
                    res_item_use.result.enchant = Integer.valueOf(102005);
                } else if (index == 2013106502) {
                    res_item_use.result.enchant = Integer.valueOf(101005);
                } else if (index == 2013106496) {
                    res_item_use.result.enchant = Integer.valueOf(115005);
                }
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
            } else if (index == 2013106509) {
                PT_EQUIP ptequip = EquipDataPool.createEquip(req_item_use.selectitemindex.intValue());
                role.getEquipBox().addEquip(ptequip);
                res_item_use.info = new PT_CONTENTS_REWARD_INFO();
                res_item_use.info.items = new PT_ITEM_REWARD_INFO();
                res_item_use.info.items.inventory = new PT_ITEMS();
                res_item_use.info.items.inventory.equipitems = new ArrayList();
                res_item_use.info.items.inventory.equipitems.add(ptequip);
                res_item_use.result = new PT_ITEM_USE_RESULT();
            }
            else {
                issuccess = false;
                log.error("ERROR====物品没处理=={}", Integer.valueOf(index));
            }
        }
        if (issuccess) {
            int table = BagService.getTable(index);
            if (table != 0)
                if (table == 1) {
                    DEF_ITEM_CONSUMABLE consumable;
                    PT_STACKABLE ptStackable;
                    PT_STACKABLE ptStackable1;
                    switch (type) {
                        case 0:
                        case 17:
                        case 22:
                            consumable = role.getConsumableBox().getConsumable(index);
                            consumable.count = Integer.valueOf(consumable.count.intValue() - req_item_use.count.intValue());
                            if (consumable.count.intValue() == 0) {
                                role.getConsumableBox().removeConsumable(index);
                            } else {
                                role.getConsumableBox().addConsumable(consumable);
                            }
                            if (consumable.bind != null && consumable.bind.booleanValue()) {
                                res_item_use.removeitems.consumeitems = new ArrayList();
                                PT_STACKABLE pT_STACKABLE1 = new PT_STACKABLE();
                                pT_STACKABLE1.index = Integer.valueOf(index);
                                pT_STACKABLE1.bind = Boolean.valueOf(true);
                                pT_STACKABLE1.count = consumable.count;
                                res_item_use.removeitems.consumeitems.add(pT_STACKABLE1);
                                PT_STACKABLE pT_STACKABLE2 = new PT_STACKABLE();
                                pT_STACKABLE2.index = Integer.valueOf(index);
                                res_item_use.removeitems.consumeitems.add(pT_STACKABLE2);
                                break;
                            }
                            res_item_use.removeitems.consumeitems = new ArrayList();
                            ptStackable = new PT_STACKABLE();
                            ptStackable.index = Integer.valueOf(index);
                            ptStackable.bind = Boolean.valueOf(true);
                            res_item_use.removeitems.consumeitems.add(ptStackable);
                            ptStackable1 = new PT_STACKABLE();
                            ptStackable1.index = Integer.valueOf(index);
                            ptStackable1.count = consumable.count;
                            res_item_use.removeitems.consumeitems.add(ptStackable1);
                            break;
                    }
                }
        }
        res_item_use.sender = Long.valueOf(role.getUid());
        res_item_use.transId = req_item_use.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message) res_item_use);
    }


    @RequestMapping
    public void ReqCeraShopBuy(IoSession session, REQ_CERA_SHOP_BUY reqCeraShopBuy) {
        String openkey = reqCeraShopBuy.openkey;
        List<PT_CERA_SHOP_BUY> buy = reqCeraShopBuy.buy;
        Map<Integer, ItemShop> itemShopMap = ItemDataPool.itemShopMap;
        Role role = SessionUtils.getRoleBySession(session);
        Account account = SessionUtils.getAccountBySession(session);
        RES_CERA_SHOP_BUY resCeraShopBuy = new RES_CERA_SHOP_BUY();
        PT_CONTENTS_REWARD_INFO rewards = new PT_CONTENTS_REWARD_INFO();
        PT_ITEM_REWARD_INFO items = new PT_ITEM_REWARD_INFO();
        PT_ITEMS inventory = new PT_ITEMS();
        PT_CURRENCY_REWARD_INFO currency = new PT_CURRENCY_REWARD_INFO();
        PT_CURRENCY_REWARD_INFO paymentcurrency = new PT_CURRENCY_REWARD_INFO();
        List<PT_MONEY_ITEM> paycurrencylist = new ArrayList<>();
        List<PT_MONEY_ITEM> currencylist = new ArrayList<>();
        inventory.equipitems = new ArrayList();
        inventory.titleitems = new ArrayList();
        inventory.flagitems = new ArrayList();
        inventory.materialitems = new ArrayList();
        inventory.consumeitems = new ArrayList();
        inventory.emblemitems = new ArrayList();
        inventory.carditems = new ArrayList();
        inventory.epicpieceitems = new ArrayList();
        inventory.cartifactitems = new ArrayList();
        inventory.creatureitems = new ArrayList();
        inventory.avataritems = new ArrayList();
        inventory.damagefontitems = new ArrayList();
        inventory.chatframeitems = new ArrayList();
        inventory.characterframeitems = new ArrayList();
        inventory.crackitems = new ArrayList();
        inventory.crackequipitems = new ArrayList();
        inventory.sdavataritems = new ArrayList();
        inventory.timebox = new ArrayList();
        inventory.bookmarkitems = new ArrayList();
        inventory.scrollitems = new ArrayList();
        resCeraShopBuy.account = new PT_CERA_SHOP_INFO();
        resCeraShopBuy.character = new PT_CERA_SHOP_INFO();
        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
        int moneytype = 0;
        boolean isitem = false;
        for (PT_CERA_SHOP_BUY ptCeraShopBuy : buy) {
            int goodid = ptCeraShopBuy.goodsid.intValue();
            int count = ptCeraShopBuy.count.intValue();
            ItemShop itemShop = itemShopMap.get(Integer.valueOf(goodid));
            moneytype = itemShop.getMoneytype();
            int moneycount = itemShop.getMoneycount();
            String limittype = itemShop.getLimittype();
            if (goodid == 70000) {
                ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem = account.getMoneyBox().getAccountcurrency().get(Integer.valueOf(2));
                ptMoneyItem.count = Integer.valueOf(ptMoneyItem.count.intValue() - count);
                currencylist.add(ptMoneyItem);
                account.getMoneyBox().getAccountcurrency().put(Integer.valueOf(2), ptMoneyItem);
                account.getMoneyBox().addTylor(count * 10);
                PT_MONEY_ITEM ptMoneyItem2 = new PT_MONEY_ITEM();
                ptMoneyItem2.index = Integer.valueOf(2013000001);
                ptMoneyItem2.count = (account.getMoneyBox().getMoneyItem(2013000001)).count;
                currencylist.add(ptMoneyItem2);
                PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                ptMoneyItem3.index = Integer.valueOf(2013000001);
                ptMoneyItem3.count = Integer.valueOf(count * 10);
                paycurrencylist.add(ptMoneyItem3);
            } else if (goodid == 70001) {
                ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem = account.getMoneyBox().getAccountcurrency().get(Integer.valueOf(2013000001));
                ptMoneyItem.count = Integer.valueOf(ptMoneyItem.count.intValue() - count);
                currencylist.add(ptMoneyItem);
                account.getMoneyBox().getAccountcurrency().put(Integer.valueOf(2013000001), ptMoneyItem);
                role.getMoneyBox().addmoney(count * 100);
                PT_MONEY_ITEM ptMoneyItem2 = new PT_MONEY_ITEM();
                ptMoneyItem2.count = (role.getMoneyBox().getMoneyItem(0)).count;
                currencylist.add(ptMoneyItem2);
                PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                ptMoneyItem3.count = Integer.valueOf(count * 100);
                paycurrencylist.add(ptMoneyItem3);
            } else if (goodid == 70002) {
                ptMoneyItem = new PT_MONEY_ITEM();
                ptMoneyItem = account.getMoneyBox().getAccountcurrency().get(Integer.valueOf(2));
                ptMoneyItem.count = Integer.valueOf(ptMoneyItem.count.intValue() - count);
                currencylist.add(ptMoneyItem);
                account.getMoneyBox().getAccountcurrency().put(Integer.valueOf(2), ptMoneyItem);
                role.getMoneyBox().addmoney(count * 1000);
                PT_MONEY_ITEM ptMoneyItem2 = new PT_MONEY_ITEM();
                ptMoneyItem2.count = (role.getMoneyBox().getMoneyItem(0)).count;
                currencylist.add(ptMoneyItem2);
                PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                ptMoneyItem3.count = Integer.valueOf(count * 1000);
                paycurrencylist.add(ptMoneyItem3);
            } else if (goodid == 30015) {
                PT_MONEY_ITEM ptMoneyItem2 = role.getMoneyBox().getMoneyItem(2013100902);
                PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                ptMoneyItem3.index = Integer.valueOf(2013100902);
                ptMoneyItem3.count = Integer.valueOf(count);
                paycurrencylist.add(ptMoneyItem3);
                if (ptMoneyItem2 == null) {
                    ptMoneyItem2 = new PT_MONEY_ITEM();
                    ptMoneyItem2.index = Integer.valueOf(2013100902);
                    ptMoneyItem2.count = Integer.valueOf(0);
                } else {
                    currencylist.add(ptMoneyItem2);
                }
                role.getMoneyBox().addCnt(2013100902, count);
            } else if (goodid == 30017) {
                ptMoneyItem = account.getMoneyBox().getAccountcurrency().get(Integer.valueOf(2013000001));
                ptMoneyItem.count = Integer.valueOf(ptMoneyItem.count.intValue() - 1500 * count);
                currencylist.add(ptMoneyItem);
                account.getMoneyBox().getAccountcurrency().put(Integer.valueOf(2013000001), ptMoneyItem);
                currencylist.add(role.getMoneyBox().getMoneyItem(2013100902));
                PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                ptMoneyItem3.index = Integer.valueOf(2013100902);
                ptMoneyItem3.count = Integer.valueOf(count);
                paycurrencylist.add(ptMoneyItem3);
                role.getMoneyBox().addCnt(2013100902, count);
            } else if (goodid == 30053) {
                isitem = true;
                PT_STACKABLE ptStackable = new PT_STACKABLE();
                ptStackable.index = Integer.valueOf(2013101405);
                ptStackable.count = Integer.valueOf(count * 3);
                inventory.materialitems.add(ptStackable);
                PT_STACKABLE ptStackable1 = role.getMaterialBox().getMaterial(2013101405);
                if (ptStackable1 != null) {
                    ptStackable1.count = Integer.valueOf(ptStackable1.count.intValue() + count * 3);
                    role.getMaterialBox().addMaterial(ptStackable1);
                } else {
                    role.getMaterialBox().addMaterial(ptStackable);
                }
            } else {
                isitem = true;
                if (isAccountMoney(moneytype)) {
                    Map<Integer, PT_MONEY_ITEM> accountMoney = account.getMoneyBox().getAccountcurrency();
                    ptMoneyItem = accountMoney.get(Integer.valueOf(moneytype));
                    int money = ptMoneyItem.count.intValue();
                    if (money >= count * moneycount) {
                        money -= count * moneycount;
                        ptMoneyItem.count = Integer.valueOf(money);
                        accountMoney.put(Integer.valueOf(moneytype), ptMoneyItem);
                        account.getMoneyBox().setAccountcurrency(accountMoney);
                    } else {
                        BagController.log.error("ERROR====账户余额不足");
                    }
                } else {
                    Map<Integer, PT_MONEY_ITEM> roleMoney = role.getMoneyBox().getCurrency();
                    ptMoneyItem = roleMoney.get(Integer.valueOf(moneytype));
                    int money = ptMoneyItem.count.intValue();
                    if (money >= count * moneycount) {
                        money -= count * moneycount;
                        ptMoneyItem.count = Integer.valueOf(money);
                        roleMoney.put(Integer.valueOf(moneytype), ptMoneyItem);
                        role.getMoneyBox().setCurrency(roleMoney);
                    } else {
                        BagController.log.error("ERROR====角色余额不足");
                    }
                }
                int index = itemShop.getIndex();
                Map<Integer, ConsumeItem> consumeItemMap = ItemDataPool.consumeItemMap;
                ConsumeItem consumeItem = consumeItemMap.get(Integer.valueOf(index));
                if (consumeItemMap.get(Integer.valueOf(index)) != null) {
                    int newtype = consumeItemMap.get(Integer.valueOf(index)).getStackabletype();
                    BagController.log.error("goodsid == {}, index == {}, name == {}, newtype == {}", Integer.valueOf(goodid), Integer.valueOf(index), consumeItem.getItemname(), Integer.valueOf(newtype));
                    if ((((newtype == 0) ? 1 : 0) | ((newtype == 17) ? 1 : 0) | ((newtype == 22) ? 1 : 0)) != 0) {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = Integer.valueOf(index);
                        ptStackable.count = Integer.valueOf(count);
                        inventory.consumeitems.add(ptStackable);
                        DEF_ITEM_CONSUMABLE ptStackable1 = role.getConsumableBox().getConsumable(index);
                        if (newtype == 17) {
                            account.getActivityBox().setTylorBagExpireTime(DateUtils.getAfterDayEndDate(30).getTime());
                            String title = "泰拉充电包";
                            String msg = "泰拉充电包 每日邮件";
                            List<MailItem> mailItemList = new ArrayList<>();
                            MailItem mailItem = new MailItem();
                            mailItem.index = Integer.valueOf(2013000001);
                            mailItem.cnt = Integer.valueOf(2000);
                            mailItemList.add(mailItem);
                            account.getMailBox().addMail(title, msg, mailItemList);
                            BagController.log.error("泰拉充电包 邮件发送 {}", mailItem);
                        }
                        if (ptStackable1 != null) {
                            ptStackable1.count = Integer.valueOf(ptStackable1.count.intValue() + count);
                            role.getConsumableBox().addConsumable(ptStackable1);
                        } else {
                            role.getConsumableBox().addConsumable(ptStackable);
                        }
                    } else if ((((newtype == 1) ? 1 : 0) | ((newtype == 2) ? 1 : 0) | ((newtype == 19) ? 1 : 0) | ((newtype == 24) ? 1 : 0)) != 0) {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = Integer.valueOf(index);
                        ptStackable.count = Integer.valueOf(count);
                        inventory.materialitems.add(ptStackable);
                        PT_STACKABLE ptStackable1 = role.getMaterialBox().getMaterial(index);
                        if (ptStackable1 != null) {
                            ptStackable1.count = Integer.valueOf(ptStackable1.count.intValue() + count);
                            role.getMaterialBox().addMaterial(ptStackable1);
                        } else {
                            role.getMaterialBox().addMaterial(ptStackable);
                        }
                    } else if (newtype == 14) {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = Integer.valueOf(index);
                        ptStackable.count = Integer.valueOf(count);
                        inventory.emblemitems.add(ptStackable);
                        role.getEmblemBox().updateEmblem(ptStackable);
                    } else if (newtype == 2) {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = Integer.valueOf(index);
                        ptStackable.count = Integer.valueOf(count);
                        inventory.carditems.add(ptStackable);
                        role.getCardBox().updateCard(ptStackable);
                    } else if (newtype == 18) {
                        PT_STACKABLE ptStackable = new PT_STACKABLE();
                        ptStackable.index = Integer.valueOf(index);
                        ptStackable.count = Integer.valueOf(count);
                        inventory.epicpieceitems.add(ptStackable);
                        account.getEpicPieceBox().updateEpicPiece(ptStackable);
                    } else if (newtype == 21) {
                        if (goodid != 70001 && goodid != 70002 && goodid != 70003 && goodid != 30015 && goodid != 30017) {
                            account.getMoneyBox().addCnt(index, count);
                            PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                            ptMoneyItem3.count = Integer.valueOf(count);
                            paycurrencylist.add(ptMoneyItem3);
                        }
                    } else if (newtype == 20 &&
                            goodid != 70001 && goodid != 70002 && goodid != 70003 && goodid != 30015 && goodid != 30017) {
                        role.getMoneyBox().addCnt(index, count);
                        PT_MONEY_ITEM ptMoneyItem3 = new PT_MONEY_ITEM();
                        ptMoneyItem3.count = Integer.valueOf(count);
                        paycurrencylist.add(ptMoneyItem3);
                    }
                } else if (EquipDataPool.index2Equip.get(Integer.valueOf(index)) != null) {
                    int newtype = EquipDataPool.index2Equip.get(Integer.valueOf(index)).getEquiptype();
                    for (int i = 0; i < count; i++) {
                        if (newtype == 0 || newtype == 1 || newtype == 2 || newtype == 3 || newtype == 4 || newtype == 5 || newtype == 6 || newtype == 7 || newtype == 8 || newtype == 9 || newtype == 10) {
                            PT_AVATAR_ITEM ptAvatarItem = new PT_AVATAR_ITEM();
                            ptAvatarItem.index = Integer.valueOf(index);
                            ptAvatarItem.guid = Long.valueOf(IdGenerator.getNextId());
                            inventory.avataritems.add(ptAvatarItem);
                            role.getAvatarBox().addAvatar(ptAvatarItem);
                        } else if (newtype == 12) {
                            PT_EQUIP pt_equip = new PT_EQUIP();
                            pt_equip.index = Integer.valueOf(index);
                            pt_equip.guid = Long.valueOf(IdGenerator.getNextId());
                            pt_equip.quality = Integer.valueOf(100);
                            inventory.titleitems.add(pt_equip);
                            role.getTitleBox().addTitle(pt_equip);
                        } else if (newtype == 11 || newtype == 13 || newtype == 14 || newtype == 15 || newtype == 16 || newtype == 17 || newtype == 18 || newtype == 19 || newtype == 20) {
                            PT_EQUIP pt_equip = EquipDataPool.createEquip(index);
                            inventory.equipitems.add(pt_equip);
                            role.getEquipBox().addEquip(pt_equip);
                        }
                    }
                } else {
                    Map<Integer, Skin> equipItemMap = ItemDataPool.skinItemMap;
                    if (equipItemMap.get(Integer.valueOf(index)) != null) ;
                }
            }
            PT_SHOP_BUY_COUNT pt_shop_buy_count = new PT_SHOP_BUY_COUNT();
            pt_shop_buy_count.goodsid = Integer.valueOf(goodid);
            pt_shop_buy_count.count = Integer.valueOf(count);
            pt_shop_buy_count.lastbuytime = Long.valueOf(TimeUtil.currS());
            if ("character".equals(limittype)) {
                role.getRoleShopInfoBox().addBuy(pt_shop_buy_count);
                continue;
            }
            account.getAccShopInfoBox().addBuy(pt_shop_buy_count);
        }
        paymentcurrency.currency = paycurrencylist;
        items.inventory = inventory;
        currency.currency = currencylist;
        if (isitem) {
            rewards.items = items;
            if (isAccountMoney(moneytype)) ;
            currencylist.add(ptMoneyItem);
        } else {
            rewards.paymentcurrency = paymentcurrency;
        }
        rewards.currency = currency;
        resCeraShopBuy.buy = reqCeraShopBuy.buy;
        resCeraShopBuy.rewards = rewards;
        resCeraShopBuy.transId = reqCeraShopBuy.transId;
        role.save();
        account.save();
        MessagePusher.pushMessage(session, resCeraShopBuy);
    }

    public boolean isAccountMoney(int index) {
        switch (index) {
            case 0:
                return false;
            case 2:
                return true;
            case 2013100902:
                return false;
            case 2013100897:
                return false;
            case 2013102100:
                return false;
            case 2013102101:
                return false;
            case 2013101309:
                return false;
            case 2013104686:
                return false;
            case 2013000002:
                return false;
            case 1990000084:
                return false;
            case 2013101454:
                return false;
            case 2013000001:
                return true;
            case 2013105779:
                return true;
            case 2013104144:
                return true;
            case 2013101484:
                return true;
            case 2013104267:
                return true;
            case 2013102924:
                return true;
            case 2013106097:
                return true;
            case 2013103791:
                return true;
            case 2013106215:
                return true;
        }
        return false;
    }

    @RequestMapping
    public void REQ_INVEN_EXTEND(IoSession session, REQ_INVEN_EXTEND reqInvenExtend) {
        Role role = SessionUtils.getRoleBySession(session);
        Account account = SessionUtils.getAccountBySession(session);
        RES_INVEN_EXTEND resInvenExtend = new RES_INVEN_EXTEND();
        int tylorcost = 0;
        int count = role.getEquipBox().getMaxcount() + 5;
        if (reqInvenExtend.type == null) {
            role.getEquipBox().setMaxcount(count);
            role.getMaterialBox().setMaxcount(count);
            role.getCardBox().setMaxcount(count);
            role.getConsumableBox().setMaxcount(count);
            role.getEmblemBox().setMaxcount(count);
            tylorcost = getExtendCost(count);
            account.getMoneyBox().subCnt(2013000001, tylorcost);
        }
        List<PT_MONEY_ITEM> paycurrencylist = new ArrayList<>();
        PT_MONEY_ITEM ptMoneyItem = new PT_MONEY_ITEM();
        ptMoneyItem.index = Integer.valueOf(2013000001);
        ptMoneyItem.count = (account.getMoneyBox().getMoneyItem(2013000001)).count;
        paycurrencylist.add(ptMoneyItem);
        resInvenExtend.count = Integer.valueOf(count);
        resInvenExtend.accountcurrency = paycurrencylist;
        resInvenExtend.transId = reqInvenExtend.transId;
        MessagePusher.pushMessage(session, resInvenExtend);
    }

    public int getExtendCost(int count) {
        int cost = 800;
        if (count == 50) {
            cost = 1600;
        } else if (count == 55) {
            cost = 3200;
        } else if (count == 60) {
            cost = 6400;
        } else if (count == 65) {
            cost = 12800;
        } else if (count == 70) {
            cost = 25600;
        } else if (count == 75 || count == 80) {
            cost = 50000;
        } else if (count == 85 || count == 90) {
            cost = 80000;
        }
        return cost;
    }

    @RequestMapping
    public void ReqCeraShopBuyInfo(IoSession session, REQ_CERA_SHOP_BUY_INFO reqCeraShopBuyInfo) {
        RES_CERA_SHOP_BUY_INFO res_cera_shop_buy_info = new RES_CERA_SHOP_BUY_INFO();
        Account account = SessionUtils.getAccountBySession(session);
        Role role = SessionUtils.getRoleBySession(session);
        PT_CERA_SHOP_INFO accptCeraShopInfo = new PT_CERA_SHOP_INFO();
        PT_CERA_SHOP_INFO roleptCeraShopInfo = new PT_CERA_SHOP_INFO();
        if (account.getAccShopInfoBox() == null)
            account.setAccShopInfoBox(new AccShopInfoBox());
        if (account.getAccShopInfoBox().getBuy() != null)
            accptCeraShopInfo.buy = account.getAccShopInfoBox().getBuy();
        if (role.getRoleShopInfoBox().getBuy() != null)
            roleptCeraShopInfo.buy = role.getRoleShopInfoBox().getBuy();
        res_cera_shop_buy_info.account = accptCeraShopInfo;
        res_cera_shop_buy_info.character = roleptCeraShopInfo;
        res_cera_shop_buy_info.transId = reqCeraShopBuyInfo.transId;
        MessagePusher.pushMessage(session, res_cera_shop_buy_info);
    }

    public int getcost(int type, int level) {
        int cost = 200;
        if (level < 10) {
            cost = 200 * level;
        } else if (10 <= level && level < 15) {
            cost = 50000;
        } else if (15 <= level && level < 20) {
            cost = 80000;
        } else if (20 <= level && level < 30) {
            cost = 100000;
        } else if (30 <= level && level < 40) {
            cost = 150000;
        }
        if (type == 1)
            cost *= 10;
        return cost;
    }

    public int getReinforceRate(int index) {
        switch (index) {
            case 2013105097:
                return 70;
            case 2013103769:
                return 10;
            case 2013103666:
                return 50;
            case 2013103633:
                return 90;
            case 2013103631:
                return 30;
        }
        return 50;
    }
}
