package com.dnfm.game.bag.model;

import com.dnfm.game.config.CharacterScoreConfig;
import com.dnfm.game.config.DnfSystemConfig;
import com.dnfm.game.config.Equip;
import com.dnfm.game.config.UpgradeScoreConfig;
import com.dnfm.game.equip.EquipDataPool;
import com.dnfm.game.role.model.Role;
import com.dnfm.mina.protobuf.PT_ARTIFACT;
import com.dnfm.mina.protobuf.PT_AVATAR_ITEM;
import com.dnfm.mina.protobuf.PT_CREATURE;
import com.dnfm.mina.protobuf.PT_EMBLEM;
import com.dnfm.mina.protobuf.PT_EQUIP;
import com.dnfm.mina.protobuf.PT_EQUIPPED;
import com.dnfm.mina.protobuf.PT_SKIN_ITEM;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 装备盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
public class EquippedBox {

    // 装备列表映射 (guid -> PT_EQUIPPED)
    private Map<Long, PT_EQUIPPED> equiplistMap = new HashMap<>();

    // 生物列表映射 (guid -> PT_CREATURE)
    private Map<Long, PT_CREATURE> creaturelistMap = new HashMap<>();

    // 头像列表映射 (guid -> PT_AVATAR_ITEM)
    private Map<Long, PT_AVATAR_ITEM> avatarlistMap = new HashMap<>();

    // 神器列表映射 (guid -> PT_ARTIFACT)
    private Map<Long, PT_ARTIFACT> cartifactlistMap = new HashMap<>();

    // 装备皮肤列表映射 (guid -> PT_EQUIPPED)
    private Map<Long, PT_EQUIPPED> equipskinlistMap = new HashMap<>();

    // 头像皮肤列表映射 (guid -> PT_AVATAR_ITEM)
    private Map<Long, PT_AVATAR_ITEM> avatarskinlistMap = new HashMap<>();

    // 皮肤列表映射 (guid -> PT_SKIN_ITEM)
    private Map<Long, PT_SKIN_ITEM> skinlistMap = new HashMap<>();

    // SD 头像列表映射 (guid -> PT_AVATAR_ITEM)
    private Map<Long, PT_AVATAR_ITEM> sdavatarlistMap = new HashMap<>();

    // --- 装备相关方法 ---

    /**
     * 根据槽位获取装备。
     * @param slot 槽位 ID。
     * @return 对应的装备，如果未找到则返回 null。
     */
    public PT_EQUIPPED getEquippedBySlot(int slot) {
        for (PT_EQUIPPED equip : this.equiplistMap.values()) {
            if (equip.slot.intValue() == slot) { // 假设 PT_EQUIPPED 有 getter
                return equip;
            }
        }
        return null;
    }

    /**
     * 添加装备。
     * @param equip 要添加的装备。
     */
    public void addEquip(PT_EQUIPPED equip) {
        this.equiplistMap.put(equip.getGuid(), equip); // 假设 PT_EQUIPPED 有 getter
    }

    /**
     * 从 PT_EQUIP 创建并添加装备。
     * @param equip 来源的 PT_EQUIP 对象。
     */
    public void addEquipped(PT_EQUIP equip) {
        PT_EQUIPPED equipped = new PT_EQUIPPED();
        equipped.setScore(equip.score); // 假设 PT_EQUIPPED 和 PT_EQUIP 有 getter/setter
        equipped.setEquiptype(equip.equiptype);
        equipped.minlevel = equip.minlevel;
        equipped.setGuid(equip.getGuid());
        equipped.setIndex(equip.index);
        equipped.setQuality(equip.getQuality());
        equipped.setEndurance(equip.getEndurance());
        equipped.setSlot(equip.slot);
        if (equip.getUpgrade() != null) {
            equipped.setUpgrade(equip.getUpgrade());
        }
        if (equip.getUpgradepoint() != null) {
            equipped.setUpgradepoint(equip.getUpgradepoint());
        }
        if (equip.getRappearance() != null) {
            equipped.setRappearance(equip.getRappearance());
        }
        if (equip.getRoption() != null) {
            equipped.setRoption(equip.getRoption());
        }
        if (equip.getRnoption() != null) {
            equipped.setRoption(equip.getRnoption()); // 注意：rnoption 赋值给 roption
        }
        if (equip.getCard() != null) {
            equipped.setCard(equip.getCard());
        }
        if (equip.getEmblem() != null) {
            equipped.setEmblem(equip.getEmblem());
        }
        this.equiplistMap.put(equipped.getGuid(), equipped);
    }

    /**
     * 更新装备。
     * @param equip 要更新的装备。
     */
    public void updateEquip(PT_EQUIPPED equip) {
        this.equiplistMap.put(equip.getGuid(), equip);
    }

    /**
     * 移除装备。
     * @param equip 要移除的装备。
     */
    public void removeEquip(PT_EQUIPPED equip) {
        this.equiplistMap.remove(equip.getGuid());
    }

    /**
     * 移除所有指定槽位范围内的装备 (13-20)。
     */
    public void removeAllEquip() {
        List<PT_EQUIPPED> deleteEquip = new ArrayList<>();
        for (PT_EQUIPPED ptEquipped : this.equiplistMap.values()) {
            int slot = ptEquipped.slot.intValue();
            if (slot >= 13 && slot <= 20) { // 更清晰的条件判断
                deleteEquip.add(ptEquipped);
            }
        }
        for (PT_EQUIPPED ptEquipped : deleteEquip) {
            this.equiplistMap.remove(ptEquipped.getGuid());
        }
    }

    /**
     * 根据 GUID 获取装备。
     * @param guid 装备 GUID。
     * @return 对应的装备，如果未找到则返回 null。
     */
    public PT_EQUIPPED getEquipped(long guid) {
        return this.equiplistMap.get(Long.valueOf(guid));
    }

    /**
     * 根据索引获取装备。
     * @param index 装备索引。
     * @return 对应的装备，如果未找到则返回 null。
     */
    public PT_EQUIPPED getEquipped2(int index) {
        for (PT_EQUIPPED pe : this.equiplistMap.values()) {
            if (pe.index.intValue() == index) {
                return pe;
            }
        }
        return null;
    }

    /**
     * 给装备添加徽章。
     * @param equ 要添加徽章的装备。
     * @param emb 要添加的徽章。
     * @return 修改后的装备对象。
     */
    public PT_EQUIPPED addEmblem(PT_EQUIPPED equ, PT_EMBLEM emb) {
        for (int i = 0; i < equ.getEmblem().size(); i++) {
            if (equ.getEmblem().get(i).index == emb.index) { // 假设 PT_EMBLEM 有 getter
                PT_EMBLEM existingEmblem = equ.getEmblem().get(i);
                existingEmblem.count = existingEmblem.count + 1; // 假设 PT_EMBLEM 有 getter/setter
                return equ;
            }
        }
        equ.getEmblem().add(emb);
        return equ;
    }

    /**
     * 从装备中移除指定槽位的徽章。
     * @param equ 要移除徽章的装备。
     * @param slot 徽章槽位。
     * @return 移除的徽章索引，如果未找到则返回 -1。
     */
    public int removeEmblem(PT_EQUIPPED equ, int slot) {
        int removeIndex = -1;
        for (int i = 0; i < equ.getEmblem().size(); i++) {
            PT_EMBLEM emblem = equ.getEmblem().get(i);
            if (slot == emblem.slot.intValue()) { // 假设 PT_EMBLEM 有 getter
                removeIndex = i;
                break;
            }
        }
        return removeIndex;
    }

    /**
     * 从 PT_EQUIP 对象中移除指定槽位的徽章。
     * @param equ 要移除徽章的 PT_EQUIP 对象。
     * @param slot 徽章槽位。
     * @return 移除的徽章索引，如果未找到则返回 -1。
     */
    public int removeEmblem2(PT_EQUIP equ, int slot) {
        int removeIndex = -1;
        for (int i = 0; i < equ.getEmblem().size(); i++) {
            PT_EMBLEM emblem = equ.getEmblem().get(i);
            if (slot == emblem.slot.intValue()) { // 假设 PT_EMBLEM 有 getter
                removeIndex = i;
                break;
            }
        }
        return removeIndex;
    }

    /**
     * 获取装备列表。
     * @return 装备列表。
     */
    public List<PT_EQUIPPED> getEquiplist() {
        return new ArrayList<>(this.equiplistMap.values());
    }

    public List<PT_EQUIP> getEquipList(Role role) {
        com.dnfm.game.bag.model.EquippedBox equipBox = role.getEquippedBox();
        List<PT_EQUIP> equips = new ArrayList<>();
        for (PT_EQUIPPED pe : equipBox.getEquiplist()) {
            PT_EQUIP pt_equipped = new PT_EQUIP();
            pt_equipped.score = pe.score;
            pt_equipped.equiptype = pe.equiptype;
            pt_equipped.minlevel = pe.minlevel;
            pt_equipped.index = pe.index;
            pt_equipped.guid = pe.guid;
            pt_equipped.quality = pe.quality;
            pt_equipped.endurance = pe.endurance;
            pt_equipped.slot = pe.slot;
            if (pe.upgrade != null)
                pt_equipped.upgrade = pe.upgrade;
            if (pe.upgradepoint != null)
                pt_equipped.upgradepoint = pe.upgradepoint;
            if (pe.rappearance != null)
                pt_equipped.rappearance = pe.rappearance;
            if (pe.roption != null)
                pt_equipped.roption = pe.roption;
            if (pe.rnoption != null)
                pt_equipped.roption = pe.roption;
            if (pe.card != null)
                pt_equipped.card = pe.card;
            if (pe.emblem != null)
                pt_equipped.emblem = pe.emblem;
            equips.add(pt_equipped);
        }
        return equips;
    }

    /**
     * 获取装备列表（转换为 PT_EQUIP 格式）。
     * @return 装备列表 (PT_EQUIP 格式)。
     */
    public List<PT_EQUIP> getEquippedlist() {
        List<PT_EQUIP> equips = new ArrayList<>();
        for (PT_EQUIPPED ptEquipped : this.equiplistMap.values()) {
            equips.add(EquipDataPool.changeEquip(ptEquipped)); // 假设 EquipDataPool.changeEquip 存在
        }
        return equips;
    }

    // --- 角色装备评分相关方法 ---

    /**
     * 计算角色总装备评分。
     * @param role 角色对象。
     * @return 总装备评分。
     */
    public int getRoleEquipScore(Role role) {
        int allScore = 229 + role.getLevel() * 73; // 直接计算基础评分
        for (PT_EQUIPPED ptEquipped : role.getEquippedBox().getEquiplist()) {
            allScore += getEquipScore(role, ptEquipped);
        }
        return allScore;
    }

    /**
     * 计算单件装备评分。
     * @param role 角色对象。
     * @param roleEquip 装备对象。
     * @return 单件装备评分。
     */
    public int getEquipScore(Role role, PT_EQUIPPED roleEquip) {
        int defScore = 0;
        int supScore = 0;
        Equip equip = EquipDataPool.getEquip(roleEquip.index.intValue());
        defScore = equip.getScore();
        defScore += (int) Math.floor((roleEquip.getQuality().intValue() - 50) * 0.15 * equip.getScore() / 100.0);

        if (roleEquip.getUpgrade().intValue() > 0) {
            UpgradeScoreConfig upgradeScoreConfig = DnfSystemConfig.getUpgradeScoreConfig(roleEquip.getUpgrade().intValue());
            CharacterScoreConfig characterScoreConfig = DnfSystemConfig.getCharacterScoreConfig(Integer.valueOf(role.getJob()), equip.getGroupname());
            double pct = 1.0; // 默认值
            switch (role.getGrowtype()) {
                case 1:
                    pct = characterScoreConfig.getVal1();
                    break;
                case 2:
                    pct = characterScoreConfig.getVal2();
                    break;
                case 3:
                    pct = characterScoreConfig.getVal3();
                    break;
                case 4:
                    pct = characterScoreConfig.getVal4();
                    break;
                // default case already set pct = 1.0
            }
            supScore += (int) Math.floor(equip.getScore() * pct * upgradeScoreConfig.getVal2() * 0.01 + upgradeScoreConfig.getVal1());
        }

        if (roleEquip.getRoption() != null && roleEquip.getRoption().size() > 0) {
            for (int i = 0; i < roleEquip.getRoption().size(); i++) {
                int m1 = (int) Math.floor(DnfSystemConfig.getMagicSpell(equip.getRarity()) * (2 + equip.getMinlevel() * 10 / 20));
                supScore += m1;
            }
        }

        if (roleEquip.getCard() != null && roleEquip.getCard().size() > 0) {
            int scoreCard = 0;
            for (PT_STACKABLE stackable : roleEquip.getCard()) {
                Equip equipCard = EquipDataPool.getEquip(stackable.index.intValue());
                scoreCard += (equipCard != null) ? equipCard.getScore() : 133;
            }
            supScore += scoreCard;
        }

        if (roleEquip.getEmblem() != null && roleEquip.getEmblem().size() > 0) {
            int scoreEmblem = 0;
            for (PT_EMBLEM emblem : roleEquip.getEmblem()) {
                Equip equipEmblem = EquipDataPool.getEquip(emblem.index.intValue());
                scoreEmblem += equipEmblem.getScore(); // 假设 PT_EMBLEM 对应的 Equip 有 score
            }
            supScore += scoreEmblem;
        }

        return defScore + supScore;
    }

    // --- 其他列表相关方法 (Avatar, Creature, etc.) ---

    /**
     * 根据槽位获取头像。
     * @param slot 槽位 ID。
     * @return 对应的头像，如果未找到则返回 null。
     */
    public PT_AVATAR_ITEM getAvatarBySlot(int slot) {
        for (PT_AVATAR_ITEM avatar : this.avatarlistMap.values()) {
            if (avatar.slot == slot) { // 假设 PT_AVATAR_ITEM 有 slot 属性或 getter
                return avatar;
            }
        }
        return null;
    }

    /**
     * 根据槽位获取头像皮肤。
     * @param slot 槽位 ID。
     * @return 对应的头像皮肤，如果未找到则返回 null。
     */
    public PT_AVATAR_ITEM getAvatarSkinBySlot(int slot) {
        for (PT_AVATAR_ITEM avatar : this.avatarskinlistMap.values()) {
            if (avatar.slot == slot) { // 假设 PT_AVATAR_ITEM 有 slot 属性或 getter
                return avatar;
            }
        }
        return null;
    }

    // ... (其他 add/remove/get 方法类似，主要变化是属性访问方式和 Lombok 生成的 getter/setter)

    public void addCreature(PT_CREATURE creature) {
        this.creaturelistMap.put(creature.guid, creature); // 假设 PT_CREATURE 有 getter
    }

    public void addAvatar(PT_AVATAR_ITEM avatar) {
        this.avatarlistMap.put(avatar.guid, avatar);
    }

    public void removeAvatar(PT_AVATAR_ITEM avatar) {
        this.avatarlistMap.remove(avatar.guid);
    }

    public void removeAvatar(long guid) {
        this.avatarlistMap.remove(Long.valueOf(guid));
    }

    public void addCartifact(PT_ARTIFACT cartifact) {
        this.cartifactlistMap.put(cartifact.guid, cartifact);
    }

    public void addEquipskin(PT_EQUIPPED equipskin) {
        this.equipskinlistMap.put(equipskin.getGuid(), equipskin);
    }

    public void addAvatarskin(PT_AVATAR_ITEM avatarskin) {
        this.avatarskinlistMap.put(avatarskin.guid, avatarskin);
    }

    public void removeSdavatar(PT_AVATAR_ITEM avatar) {
        this.avatarskinlistMap.remove(avatar.guid); // 注意：方法名是 removeSdavatar，但操作的是 avatarskinlistMap
    }

    public void removeAvatarskin(long guid) {
        this.avatarskinlistMap.remove(Long.valueOf(guid));
    }

    public void addSkin(PT_SKIN_ITEM skin) {
        this.skinlistMap.put(skin.guid, skin);
    }

    public void addSdavatar(PT_AVATAR_ITEM sdavatar) {
        this.sdavatarlistMap.put(sdavatar.guid, sdavatar);
    }

    public List<PT_CREATURE> getCreaturelist() {
        return new ArrayList<>(this.creaturelistMap.values());
    }

    public List<PT_AVATAR_ITEM> getAvatarlist() {
        return new ArrayList<>(this.avatarlistMap.values());
    }

    public List<PT_ARTIFACT> getCartifactlist() {
        return new ArrayList<>(this.cartifactlistMap.values());
    }

    public List<PT_EQUIPPED> getEquipskinlist() {
        return new ArrayList<>(this.equipskinlistMap.values());
    }

    public List<PT_AVATAR_ITEM> getAvatarskinlist() {
        return new ArrayList<>(this.avatarskinlistMap.values());
    }

    public List<PT_SKIN_ITEM> getSkinlist() {
        return new ArrayList<>(this.skinlistMap.values());
    }

    public List<PT_AVATAR_ITEM> getSdavatarlist() {
        return new ArrayList<>(this.sdavatarlistMap.values());
    }
}