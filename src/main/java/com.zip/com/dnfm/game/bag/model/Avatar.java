/*   */
package com.dnfm.game.bag.model;

/*   */ public class Avatar {
    private int index;
    /*   */   private long guid;

    /*   */
    /* 5 */
    public void setIndex(int index) {
        this.index = index;
    }

    public void setGuid(long guid) {
        this.guid = guid;
    }

    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof com.dnfm.game.bag.model.Avatar)) return false;
        com.dnfm.game.bag.model.Avatar other = (com.dnfm.game.bag.model.Avatar) o;
        return !other.canEqual(this) ? false : ((getIndex() != other.getIndex()) ? false : (!(getGuid() != other.getGuid())));
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.bag.model.Avatar;
    }

    public String toString() {
        return "Avatar(index=" + getIndex() + ", guid=" + getGuid() + ")";
    }

    /*   */
    /* 7 */
    public int getIndex() {
        return this.index;
    }

    public long getGuid() {
        /* 8 */
        return this.guid;
        /*   */
    }
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\bag\model\Avatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */