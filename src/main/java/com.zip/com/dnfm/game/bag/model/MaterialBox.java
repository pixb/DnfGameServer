package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_STACKABLE;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 材料盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
@Slf4j // 自动生成 log 日志对象
public class MaterialBox {

    private int maxcount = 40;
    private Map<Integer, PT_STACKABLE> materialsMap = new HashMap<>();

    /**
     * 根据索引获取材料。
     * @param index 材料索引。
     * @return 对应的材料，如果未找到则返回 null。
     */
    public PT_STACKABLE getMaterial(int index) {
        return this.materialsMap.get(index); // 假设 PT_STACKABLE 有 getter
    }

    /**
     * 更新材料数量（增加）。
     * 如果不存在，则创建新的。
     * @param material 包含索引和数量变化的 PT_STACKABLE 对象。
     */
    public void updateMaterial(PT_STACKABLE material) {
        PT_STACKABLE oldMaterial = this.materialsMap.get(material.getIndex()); // 假设 PT_STACKABLE 有 getter
        if (oldMaterial == null) {
            this.materialsMap.put(material.getIndex(), material);
        } else {
            oldMaterial.setCount(oldMaterial.getCount() + material.getCount()); // 假设 PT_STACKABLE 有 getter/setter
        }
    }

    /**
     * 更新材料数量（减少）。
     * @param index 材料索引。
     * @param count 要减少的数量。
     * @return 实际减少的数量。
     */
    public int updateMaterialSub(int index, int count) {
        PT_STACKABLE material = this.materialsMap.get(index);
        if (material == null) {
            log.error("UNREACH==updateMaterialSub==不应该执行到这里");
            return -1;
        } else {
            int delta = material.getCount() - count;
            if (delta == 0) {
                this.materialsMap.remove(index);
                return count;
            } else if (delta > 0) {
                material.setCount(delta);
                return count;
            } else {
                int res = material.getCount();
                this.materialsMap.remove(index);
                return res;
            }
        }
    }

    /**
     * 更新材料数量（增加）。
     * 如果不存在，则创建新的。
     * @param index 材料索引。
     * @param count 要增加的数量。
     */
    public void updateMaterialAdd(int index, int count) {
        PT_STACKABLE material = this.materialsMap.get(index);
        if (material == null) {
            material = new PT_STACKABLE();
            material.setIndex(index);
            material.setCount(count);
            this.materialsMap.put(index, material);
        } else {
            material.setCount(material.getCount() + count);
        }
    }

    /**
     * 根据索引移除材料。
     * @param index 材料索引。
     */
    public void removeMaterial(int index) {
        this.materialsMap.remove(index);
    }

    /**
     * 添加材料到盒子中。
     * 如果数量为 0，则移除该材料。
     * @param material 要添加的材料。
     */
    public void addMaterial(PT_STACKABLE material) {
        int key = material.getIndex(); // 假设 PT_STACKABLE 有 getter
        if (material.getCount() == 0) {
            if (this.materialsMap.containsKey(key)) {
                this.materialsMap.remove(key);
            }
        } else {
            this.materialsMap.put(key, material);
        }
    }

    /**
     * 获取材料列表。
     * @return 材料列表。
     */
    public List<PT_STACKABLE> getMaterials() {
        return new ArrayList<>(this.materialsMap.values());
    }

    /**
     * 更新指定材料的数量。
     * @param index 材料索引。
     * @param cnt 新的数量。
     */
    public void updateCnt(int index, int cnt) {
        this.materialsMap.get(index).setCount(cnt); // 假设 PT_STACKABLE 有 setter
    }

    /**
     * 增加指定材料的数量。
     * 如果不存在，则创建新的。
     * @param index 材料索引。
     * @param count 要增加的数量。
     * @param acqTime 获取时间（此方法中未使用，但保留参数）。
     */
    public void addCnt(int index, int count, long acqTime) {
        PT_STACKABLE ptStackable = this.materialsMap.get(index);
        if (ptStackable == null) {
            ptStackable = new PT_STACKABLE();
            ptStackable.setCount(0);
            ptStackable.setIndex(index);
        }

        ptStackable.setCount(ptStackable.getCount() + count);
        int key = ptStackable.getIndex(); // 假设 PT_STACKABLE 有 getter
        this.materialsMap.put(key, ptStackable);
    }

    /**
     * 减少指定材料的数量。
     * @param index 材料索引。
     * @param count 要减少的数量。
     */
    public void subCnt(int index, int count) {
        PT_STACKABLE ptStackable = this.materialsMap.get(index);
        ptStackable.setCount(ptStackable.getCount() - count); // 假设 PT_STACKABLE 有 setter
        this.materialsMap.put(ptStackable.getIndex(), ptStackable); // 假设 PT_STACKABLE 有 getter
    }

    /**
     * 获取指定材料的数量。
     * @param index 材料索引。
     * @return 材料数量，如果未找到则返回 -1。
     */
    public int getCnt(int index) {
        return this.materialsMap.containsKey(index) ? this.materialsMap.get(index).getCount() : -1; // 假设 PT_STACKABLE 有 getter
    }

    /**
     * 获取材料列表（与 getMaterials 方法相同）。
     * @return 材料列表。
     */
    public List<PT_STACKABLE> getMaterial() {
        return new ArrayList<>(this.materialsMap.values());
    }
}