package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_ARTIFACT;
import com.dnfm.mina.protobuf.PT_AVATAR_ITEM;
import com.dnfm.mina.protobuf.PT_CREATURE;
import com.dnfm.mina.protobuf.PT_EQUIP;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import java.util.ArrayList;
import java.util.List;

public class CharStorageBox {
    public void setLine(int line) {
        this.line = line;
    }

    public void setStoragegold(int storagegold) {
        this.storagegold = storagegold;
    }

    public void setStoragetera(int storagetera) {
        this.storagetera = storagetera;
    }

    public void setEquipitems(List<PT_EQUIP> equipitems) {
        this.equipitems = equipitems;
    }

    public void setTitleitems(List<PT_EQUIP> titleitems) {
        this.titleitems = titleitems;
    }

    public void setFlagitems(List<PT_EQUIP> flagitems) {
        this.flagitems = flagitems;
    }

    public void setMaterialitems(List<PT_STACKABLE> materialitems) {
        this.materialitems = materialitems;
    }

    public void setConsumeitems(List<PT_STACKABLE> consumeitems) {
        this.consumeitems = consumeitems;
    }

    public void setCarditems(List<PT_STACKABLE> carditems) {
        this.carditems = carditems;
    }

    public void setEmblemitems(List<PT_STACKABLE> emblemitems) {
        this.emblemitems = emblemitems;
    }

    public void setEpicpieceitems(List<PT_STACKABLE> epicpieceitems) {
        this.epicpieceitems = epicpieceitems;
    }

    public void setCartifactitems(List<PT_ARTIFACT> cartifactitems) {
        this.cartifactitems = cartifactitems;
    }

    public void setCreatureitems(List<PT_CREATURE> creatureitems) {
        this.creatureitems = creatureitems;
    }

    public void setAvataritems(List<PT_AVATAR_ITEM> avataritems) {
        this.avataritems = avataritems;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof CharStorageBox))
            return false;
        CharStorageBox other = (CharStorageBox)o;
        if (!other.canEqual(this))
            return false;
        if (getLine() != other.getLine())
            return false;
        if (getStoragegold() != other.getStoragegold())
            return false;
        if (getStoragetera() != other.getStoragetera())
            return false;
        if ((this.equipitems == null) ? (other.equipitems != null) : !this.equipitems.equals(other.equipitems))
            return false;
        if ((this.titleitems == null) ? (other.titleitems != null) : !this.titleitems.equals(other.titleitems))
            return false;
        if ((this.flagitems == null) ? (other.flagitems != null) : !this.flagitems.equals(other.flagitems))
            return false;
        if ((this.materialitems == null) ? (other.materialitems != null) : !this.materialitems.equals(other.materialitems))
            return false;
        if ((this.consumeitems == null) ? (other.consumeitems != null) : !this.consumeitems.equals(other.consumeitems))
            return false;
        if ((this.carditems == null) ? (other.carditems != null) : !this.carditems.equals(other.carditems))
            return false;
        if ((this.emblemitems == null) ? (other.emblemitems != null) : !this.emblemitems.equals(other.emblemitems))
            return false;
        if ((this.epicpieceitems == null) ? (other.epicpieceitems != null) : !this.epicpieceitems.equals(other.epicpieceitems))
            return false;
        if ((this.cartifactitems == null) ? (other.cartifactitems != null) : !this.cartifactitems.equals(other.cartifactitems))
            return false;
        if ((this.creatureitems == null) ? (other.creatureitems != null) : !this.creatureitems.equals(other.creatureitems))
            return false;
        return !((this.avataritems == null) ? (other.avataritems != null) : !this.avataritems.equals(other.avataritems));
    }

    protected boolean canEqual(Object other) {
        return other instanceof CharStorageBox;
    }

    public String toString() {
        return "CharStorageBox(line=" + getLine() + ", storagegold=" + getStoragegold() + ", storagetera=" + getStoragetera() + ", equipitems=" + getEquipitems() + ", titleitems=" + getTitleitems() + ", flagitems=" + getFlagitems() + ", materialitems=" + getMaterialitems() + ", consumeitems=" + getConsumeitems() + ", carditems=" + getCarditems() + ", emblemitems=" + getEmblemitems() + ", epicpieceitems=" + getEpicpieceitems() + ", cartifactitems=" + getCartifactitems() + ", creatureitems=" + getCreatureitems() + ", avataritems=" + getAvataritems() + ")";
    }

    private int line = 1;

    private int storagegold;

    private int storagetera;

    public int getLine() {
        return this.line;
    }

    public int getStoragegold() {
        return this.storagegold;
    }

    public int getStoragetera() {
        return this.storagetera;
    }

    private List<PT_EQUIP> equipitems = new ArrayList<>();

    public List<PT_EQUIP> getEquipitems() {
        return this.equipitems;
    }

    private List<PT_EQUIP> titleitems = new ArrayList<>();

    public List<PT_EQUIP> getTitleitems() {
        return this.titleitems;
    }

    private List<PT_EQUIP> flagitems = new ArrayList<>();

    public List<PT_EQUIP> getFlagitems() {
        return this.flagitems;
    }

    private List<PT_STACKABLE> materialitems = new ArrayList<>();

    public List<PT_STACKABLE> getMaterialitems() {
        return this.materialitems;
    }

    private List<PT_STACKABLE> consumeitems = new ArrayList<>();

    public List<PT_STACKABLE> getConsumeitems() {
        return this.consumeitems;
    }

    private List<PT_STACKABLE> carditems = new ArrayList<>();

    public List<PT_STACKABLE> getCarditems() {
        return this.carditems;
    }

    private List<PT_STACKABLE> emblemitems = new ArrayList<>();

    public List<PT_STACKABLE> getEmblemitems() {
        return this.emblemitems;
    }

    private List<PT_STACKABLE> epicpieceitems = new ArrayList<>();

    public List<PT_STACKABLE> getEpicpieceitems() {
        return this.epicpieceitems;
    }

    private List<PT_ARTIFACT> cartifactitems = new ArrayList<>();

    public List<PT_ARTIFACT> getCartifactitems() {
        return this.cartifactitems;
    }

    private List<PT_CREATURE> creatureitems = new ArrayList<>();

    public List<PT_CREATURE> getCreatureitems() {
        return this.creatureitems;
    }

    private List<PT_AVATAR_ITEM> avataritems = new ArrayList<>();

    public List<PT_AVATAR_ITEM> getAvataritems() {
        return this.avataritems;
    }

    public PT_EQUIP getEquipItem(long guid) {
        for (PT_EQUIP item : this.equipitems) {
            if (item.getGuid().longValue() == guid)
                return item;
        }
        return null;
    }

    public PT_EQUIP getTitileItem(long guid) {
        for (PT_EQUIP item : this.titleitems) {
            if (item.getGuid().longValue() == guid)
                return item;
        }
        return null;
    }

    public PT_AVATAR_ITEM getAvatar(long guid) {
        for (PT_AVATAR_ITEM item : this.avataritems) {
            if (item.guid.longValue() == guid)
                return item;
        }
        return null;
    }

    public PT_STACKABLE getConsume(int index) {
        for (PT_STACKABLE item : this.consumeitems) {
            if (item.index.intValue() == index)
                return item;
        }
        return null;
    }

    public PT_STACKABLE getMaterial(int index) {
        for (PT_STACKABLE item : this.materialitems) {
            if (item.index.intValue() == index)
                return item;
        }
        return null;
    }

    public PT_STACKABLE getCard(int index) {
        for (PT_STACKABLE item : this.carditems) {
            if (item.index.intValue() == index)
                return item;
        }
        return null;
    }

    public PT_STACKABLE getEmblem(int index) {
        for (PT_STACKABLE item : this.emblemitems) {
            if (item.index.intValue() == index)
                return item;
        }
        return null;
    }

    public PT_EQUIP getFlagItem(long guid) {
        for (PT_EQUIP item : this.flagitems) {
            if (item.getGuid().longValue() == guid)
                return item;
        }
        return null;
    }

    public void removeEquipItem(long guid) {
        PT_EQUIP ptEquip = new PT_EQUIP();
        for (PT_EQUIP item : this.equipitems) {
            if (item.getGuid().longValue() == guid)
                ptEquip = item;
        }
        this.equipitems.remove(ptEquip);
    }

    public void removeTitleItem(long guid) {
        PT_EQUIP ptEquip = new PT_EQUIP();
        for (PT_EQUIP item : this.titleitems) {
            if (item.getGuid().longValue() == guid)
                ptEquip = item;
        }
        this.titleitems.remove(ptEquip);
    }

    public void removeFlagItem(long guid) {
        PT_EQUIP ptEquip = new PT_EQUIP();
        for (PT_EQUIP item : this.flagitems) {
            if (item.getGuid().longValue() == guid)
                ptEquip = item;
        }
        this.flagitems.remove(ptEquip);
    }

    public void removeAvatar(long guid) {
        PT_AVATAR_ITEM ptAvatarItem = new PT_AVATAR_ITEM();
        for (PT_AVATAR_ITEM item : this.avataritems) {
            if (item.guid.longValue() == guid)
                ptAvatarItem = item;
        }
        this.avataritems.remove(ptAvatarItem);
    }

    public void removeArtifact(long guid) {
        PT_ARTIFACT ptArtifact = new PT_ARTIFACT();
        for (PT_ARTIFACT item : this.cartifactitems) {
            if (item.guid.longValue() == guid)
                ptArtifact = item;
        }
        this.avataritems.remove(ptArtifact);
    }

    public void subMaterial(int index, int count, boolean bind) {
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        int nowcount = 1;
        for (PT_STACKABLE item : this.materialitems) {
            if (item.getIndex().intValue() == index) {
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                if (item.count.intValue() == 0) {
                    nowcount = 0;
                    ptStackable = item;
                }
            }
        }
        if (nowcount == 0)
            this.materialitems.remove(ptStackable);
    }

    public void subConsumeitems(int index, int count, boolean bind) {
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        int nowcount = 1;
        for (PT_STACKABLE item : this.consumeitems) {
            if (item.getIndex().intValue() == index) {
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                if (item.count.intValue() == 0) {
                    nowcount = 0;
                    ptStackable = item;
                }
            }
        }
        if (nowcount == 0)
            this.consumeitems.remove(ptStackable);
    }

    public void subCarditems(int index, int count) {
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        int nowcount = 1;
        for (PT_STACKABLE item : this.carditems) {
            if (item.getIndex().intValue() == index) {
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                if (item.count.intValue() == 0) {
                    nowcount = 0;
                    ptStackable = item;
                }
            }
        }
        if (nowcount == 0)
            this.carditems.remove(ptStackable);
    }

    public void subEmblemitems(int index, int count) {
        for (PT_STACKABLE item : this.carditems) {
            if (item.getIndex().intValue() == index) {
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
            }
        }
    }

    public void subEpicpiece(int index, int count) {
        for (PT_STACKABLE item : this.epicpieceitems) {
            if (item.getIndex().intValue() == index) {
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
            }
        }
    }
}
