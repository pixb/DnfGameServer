/*     */
package com.dnfm.game.bag.model;

/*     */
/*     */

import com.dnfm.mina.protobuf.*;
/*     */

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*     */
/*     */ public class AdStorageBox {
    /*     */   private int line;

    /*     */
    /*   9 */
    public void setLine(int line) {
        this.line = line;
    }

    private int storagegold;
    private int storagetera;

    public void setStoragegold(int storagegold) {
        this.storagegold = storagegold;
    }

    public void setStoragetera(int storagetera) {
        this.storagetera = storagetera;
    }

    public void setEquipitems(List<PT_EQUIP> equipitems) {
        this.equipitems = equipitems;
    }

    public void setTitleitems(List<PT_EQUIP> titleitems) {
        this.titleitems = titleitems;
    }

    public void setFlagitems(List<PT_EQUIP> flagitems) {
        this.flagitems = flagitems;
    }

    public void setMaterialitems(List<PT_STACKABLE> materialitems) {
        this.materialitems = materialitems;
    }

    public void setConsumeitems(List<PT_STACKABLE> consumeitems) {
        this.consumeitems = consumeitems;
    }

    public void setCarditems(List<PT_STACKABLE> carditems) {
        this.carditems = carditems;
    }

    public void setEmblemitems(List<PT_STACKABLE> emblemitems) {
        this.emblemitems = emblemitems;
    }

    public void setEpicpieceitems(List<PT_STACKABLE> epicpieceitems) {
        this.epicpieceitems = epicpieceitems;
    }

    public void setCartifactitems(List<PT_ARTIFACT> cartifactitems) {
        this.cartifactitems = cartifactitems;
    }

    public void setCreatureitems(List<PT_CREATURE> creatureitems) {
        this.creatureitems = creatureitems;
    }

    public void setAvataritems(List<PT_AVATAR_ITEM> avataritems) {
        this.avataritems = avataritems;
    }

    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof com.dnfm.game.bag.model.AdStorageBox)) return false;
        com.dnfm.game.bag.model.AdStorageBox other = (com.dnfm.game.bag.model.AdStorageBox) o;
        if (!other.canEqual(this)) return false;
        if (getLine() != other.getLine()) return false;
        if (getStoragegold() != other.getStoragegold()) return false;
        if (getStoragetera() != other.getStoragetera()) return false;
        if (!Objects.equals(this.equipitems, other.equipitems))
            return false;
        if (!Objects.equals(this.titleitems, other.titleitems))
            return false;
        if (!Objects.equals(this.flagitems, other.flagitems))
            return false;
        if (!Objects.equals(this.materialitems, other.materialitems))
            return false;
        if (!Objects.equals(this.consumeitems, other.consumeitems))
            return false;
        if (!Objects.equals(this.carditems, other.carditems))
            return false;
        if (!Objects.equals(this.emblemitems, other.emblemitems))
            return false;
        if (!Objects.equals(this.epicpieceitems, other.epicpieceitems))
            return false;
        if (!Objects.equals(this.cartifactitems, other.cartifactitems))
            return false;
        if (!Objects.equals(this.creatureitems, other.creatureitems))
            return false;
        return Objects.equals(this.avataritems, other.avataritems);
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.bag.model.AdStorageBox;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + getLine();
        result = result * 59 + getStoragegold();
        result = result * 59 + getStoragetera();
        result = result * 59 + ((equipitems == null) ? 43 : equipitems.hashCode());
        result = result * 59 + ((titleitems == null) ? 43 : titleitems.hashCode());
        result = result * 59 + ((flagitems == null) ? 43 : flagitems.hashCode());
        result = result * 59 + ((materialitems == null) ? 43 : materialitems.hashCode());
        result = result * 59 + ((consumeitems == null) ? 43 : consumeitems.hashCode());
        result = result * 59 + ((carditems == null) ? 43 : carditems.hashCode());
        result = result * 59 + ((emblemitems == null) ? 43 : emblemitems.hashCode());
        result = result * 59 + ((epicpieceitems == null) ? 43 : epicpieceitems.hashCode());
        result = result * 59 + ((cartifactitems == null) ? 43 : cartifactitems.hashCode());
        result = result * 59 + ((creatureitems == null) ? 43 : creatureitems.hashCode());
        return result * 59 + ((avataritems == null) ? 43 : avataritems.hashCode());
    }

    public String toString() {
        return "AdStorageBox(line=" + getLine() + ", storagegold=" + getStoragegold() + ", storagetera=" + getStoragetera() + ", equipitems=" + getEquipitems() + ", titleitems=" + getTitleitems() + ", flagitems=" + getFlagitems() + ", materialitems=" + getMaterialitems() + ", consumeitems=" + getConsumeitems() + ", carditems=" + getCarditems() + ", emblemitems=" + getEmblemitems() + ", epicpieceitems=" + getEpicpieceitems() + ", cartifactitems=" + getCartifactitems() + ", creatureitems=" + getCreatureitems() + ", avataritems=" + getAvataritems() + ")";
    }

    /*     */
    /*  11 */
    public int getLine() {
        return this.line;
    }

    /*  12 */
    public int getStoragegold() {
        return this.storagegold;
    }

    public int getStoragetera() {
        /*  13 */
        return this.storagetera;
        /*     */
    }

    /*  15 */   private List<PT_EQUIP> equipitems = new ArrayList<>();

    public List<PT_EQUIP> getEquipitems() {
        return this.equipitems;
    }

    /*     */
    /*  17 */   private List<PT_EQUIP> titleitems = new ArrayList<>();

    public List<PT_EQUIP> getTitleitems() {
        return this.titleitems;
    }

    /*     */
    /*  19 */   private List<PT_EQUIP> flagitems = new ArrayList<>();

    public List<PT_EQUIP> getFlagitems() {
        return this.flagitems;
    }

    /*     */
    /*  21 */   private List<PT_STACKABLE> materialitems = new ArrayList<>();

    public List<PT_STACKABLE> getMaterialitems() {
        return this.materialitems;
    }

    /*     */
    /*  23 */   private List<PT_STACKABLE> consumeitems = new ArrayList<>();

    public List<PT_STACKABLE> getConsumeitems() {
        return this.consumeitems;
    }

    /*     */
    /*  25 */   private List<PT_STACKABLE> carditems = new ArrayList<>();

    public List<PT_STACKABLE> getCarditems() {
        return this.carditems;
    }

    /*     */
    /*  27 */   private List<PT_STACKABLE> emblemitems = new ArrayList<>();

    public List<PT_STACKABLE> getEmblemitems() {
        return this.emblemitems;
    }

    /*     */
    /*  29 */   private List<PT_STACKABLE> epicpieceitems = new ArrayList<>();

    public List<PT_STACKABLE> getEpicpieceitems() {
        return this.epicpieceitems;
    }

    /*     */
    /*  31 */   private List<PT_ARTIFACT> cartifactitems = new ArrayList<>();

    public List<PT_ARTIFACT> getCartifactitems() {
        return this.cartifactitems;
    }

    /*     */
    /*  33 */   private List<PT_CREATURE> creatureitems = new ArrayList<>();

    public List<PT_CREATURE> getCreatureitems() {
        return this.creatureitems;
    }

    /*     */
    /*  35 */   private List<PT_AVATAR_ITEM> avataritems = new ArrayList<>();

    public List<PT_AVATAR_ITEM> getAvataritems() {
        return this.avataritems;
    }

    /*     */
    /*     */
    /*     */
    public PT_EQUIP getEquipItem(long guid) {
        /*  39 */
        for (PT_EQUIP item : this.equipitems) {
            /*  40 */
            if (item.getGuid().longValue() == guid) {
                /*  41 */
                return item;
                /*     */
            }
            /*     */
        }
        /*  44 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_EQUIP getTitileItem(long guid) {
        /*  48 */
        for (PT_EQUIP item : this.titleitems) {
            /*  49 */
            if (item.getGuid().longValue() == guid) {
                /*  50 */
                return item;
                /*     */
            }
            /*     */
        }
        /*  53 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_AVATAR_ITEM getAvatar(long guid) {
        /*  57 */
        for (PT_AVATAR_ITEM item : this.avataritems) {
            /*  58 */
            if (item.guid.longValue() == guid) {
                /*  59 */
                return item;
                /*     */
            }
            /*     */
        }
        /*  62 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_EQUIP getFlagItem(long guid) {
        /*  66 */
        for (PT_EQUIP item : this.flagitems) {
            /*  67 */
            if (item.getGuid().longValue() == guid) {
                /*  68 */
                return item;
                /*     */
            }
            /*     */
        }
        /*  71 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public void removeEquipItem(long guid) {
        /*  75 */
        PT_EQUIP ptEquip = new PT_EQUIP();
        /*  76 */
        for (PT_EQUIP item : this.equipitems) {
            /*  77 */
            if (item.getGuid().longValue() == guid) {
                /*  78 */
                ptEquip = item;
                /*     */
            }
            /*     */
        }
        /*  81 */
        this.equipitems.remove(ptEquip);
        /*     */
    }

    /*     */
    /*     */
    public void removeTitleItem(long guid) {
        /*  85 */
        PT_EQUIP ptEquip = new PT_EQUIP();
        /*  86 */
        for (PT_EQUIP item : this.titleitems) {
            /*  87 */
            if (item.getGuid().longValue() == guid) {
                /*  88 */
                ptEquip = item;
                /*     */
            }
            /*     */
        }
        /*  91 */
        this.titleitems.remove(ptEquip);
        /*     */
    }

    /*     */
    /*     */
    public void removeFlagItem(long guid) {
        /*  95 */
        PT_EQUIP ptEquip = new PT_EQUIP();
        /*  96 */
        for (PT_EQUIP item : this.flagitems) {
            /*  97 */
            if (item.getGuid().longValue() == guid) {
                /*  98 */
                ptEquip = item;
                /*     */
            }
            /*     */
        }
        /* 101 */
        this.flagitems.remove(ptEquip);
        /*     */
    }

    /*     */
    /*     */
    public void removeAvatar(long guid) {
        /* 105 */
        PT_AVATAR_ITEM ptAvatarItem = new PT_AVATAR_ITEM();
        /* 106 */
        for (PT_AVATAR_ITEM item : this.avataritems) {
            /* 107 */
            if (item.guid.longValue() == guid) {
                /* 108 */
                ptAvatarItem = item;
                /*     */
            }
            /*     */
        }
        /* 111 */
        this.avataritems.remove(ptAvatarItem);
        /*     */
    }

    /*     */
    /*     */
    public void removeArtifact(long guid) {
        /* 115 */
        PT_ARTIFACT ptArtifact = new PT_ARTIFACT();
        /* 116 */
        for (PT_ARTIFACT item : this.cartifactitems) {
            /* 117 */
            if (item.guid.longValue() == guid) {
                /* 118 */
                ptArtifact = item;
                /*     */
            }
            /*     */
        }
        /* 121 */
        this.avataritems.remove(ptArtifact);
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public void subMaterial(int index, int count, boolean bind) {
        /* 126 */
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        /* 127 */
        int nowcount = 1;
        /* 128 */
        for (PT_STACKABLE item : this.materialitems) {
            /* 129 */
            if (item.getIndex().intValue() == index) {
                /* 130 */
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                /* 131 */
                if (item.count.intValue() == 0) {
                    /* 132 */
                    nowcount = 0;
                    /* 133 */
                    ptStackable = item;
                    /*     */
                }
                /*     */
            }
            /*     */
        }
        /* 137 */
        if (nowcount == 0) {
            /* 138 */
            this.materialitems.remove(ptStackable);
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    public void subConsumeitems(int index, int count, boolean bind) {
        /* 143 */
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        /* 144 */
        int nowcount = 1;
        /* 145 */
        for (PT_STACKABLE item : this.consumeitems) {
            /* 146 */
            if (item.getIndex().intValue() == index) {
                /* 147 */
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                /* 148 */
                if (item.count.intValue() == 0) {
                    /* 149 */
                    nowcount = 0;
                    /* 150 */
                    ptStackable = item;
                    /*     */
                }
                /*     */
            }
            /*     */
        }
        /* 154 */
        if (nowcount == 0) {
            /* 155 */
            this.consumeitems.remove(ptStackable);
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public void subCarditems(int index, int count) {
        /* 161 */
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        /* 162 */
        int nowcount = 1;
        /* 163 */
        for (PT_STACKABLE item : this.carditems) {
            /* 164 */
            if (item.getIndex().intValue() == index) {
                /* 165 */
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                /* 166 */
                if (item.count.intValue() == 0) {
                    /* 167 */
                    nowcount = 0;
                    /* 168 */
                    ptStackable = item;
                    /*     */
                }
                /*     */
            }
            /*     */
        }
        /* 172 */
        if (nowcount == 0) {
            /* 173 */
            this.carditems.remove(ptStackable);
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    public void subEmblemitems(int index, int count) {
        /* 178 */
        for (PT_STACKABLE item : this.carditems) {
            /* 179 */
            if (item.getIndex().intValue() == index) {
                /* 180 */
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                /*     */
            }
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public void subEpicpiece(int index, int count) {
        /* 187 */
        for (PT_STACKABLE item : this.epicpieceitems) {
            /* 188 */
            if (item.getIndex().intValue() == index) {
                /* 189 */
                PT_STACKABLE pT_STACKABLE = item;
                pT_STACKABLE.count = Integer.valueOf(pT_STACKABLE.count.intValue() - count);
                /*     */
            }
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    public PT_STACKABLE getConsume(int index) {
        /* 195 */
        for (PT_STACKABLE item : this.consumeitems) {
            /* 196 */
            if (item.index == index) {
                /* 197 */
                return item;
                /*     */
            }
            /*     */
        }
        /* 200 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_STACKABLE getMaterial(int index) {
        /* 204 */
        for (PT_STACKABLE item : this.materialitems) {
            /* 205 */
            if (item.index == index) {
                /* 206 */
                return item;
                /*     */
            }
            /*     */
        }
        /* 209 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_STACKABLE getCard(int index) {
        /* 213 */
        for (PT_STACKABLE item : this.carditems) {
            /* 214 */
            if (item.index == index) {
                /* 215 */
                return item;
                /*     */
            }
            /*     */
        }
        /* 218 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    public PT_STACKABLE getEmblem(int index) {
        /* 222 */
        for (PT_STACKABLE item : this.emblemitems) {
            /* 223 */
            if (item.index == index) {
                /* 224 */
                return item;
                /*     */
            }
            /*     */
        }
        /* 227 */
        return null;
        /*     */
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\bag\model\AdStorageBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */