package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_SYSTEM_BUFF_APPENDAGE;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 系统增益盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
public class SysBuffBox {

    // 时间戳
    private long time;

    // 增益映射表
    private Map<Integer, PT_SYSTEM_BUFF_APPENDAGE> appendagesMap = new HashMap<>();

    /**
     * 获取增益列表。
     * @return 增益列表。
     */
    public List<PT_SYSTEM_BUFF_APPENDAGE> getAppendages() {
        return new ArrayList<>(this.appendagesMap.values());
    }

    /**
     * 添加增益。
     * @param ptSystemBuffAppendage 要添加的增益。
     */
    public void addAppendages(PT_SYSTEM_BUFF_APPENDAGE ptSystemBuffAppendage) {
        this.appendagesMap.put(ptSystemBuffAppendage.index, ptSystemBuffAppendage); // 假设 PT_SYSTEM_BUFF_APPENDAGE 有 getter
    }

    /**
     * 创建增益对象。
     * @param index 增益索引。
     * @param time 结束时间。
     * @param values 值列表。
     * @return 创建的增益对象。
     */
    public PT_SYSTEM_BUFF_APPENDAGE createAppendage(int index, long time, List<Integer> values) {
        PT_SYSTEM_BUFF_APPENDAGE ptSystemBuffAppendage = new PT_SYSTEM_BUFF_APPENDAGE();
        ptSystemBuffAppendage.index = index; // 假设 PT_SYSTEM_BUFF_APPENDAGE 有 setter
        if (time != 0L) {
            ptSystemBuffAppendage.endtime = time; // 假设 PT_SYSTEM_BUFF_APPENDAGE 有 setter
        }
        ptSystemBuffAppendage.values = values; // 假设 PT_SYSTEM_BUFF_APPENDAGE 有 setter
        return ptSystemBuffAppendage;
    }

    /**
     * 移除增益。
     * @param index 增益索引。
     */
    public void removeAppendages(int index) {
        this.appendagesMap.remove(index);
    }
}