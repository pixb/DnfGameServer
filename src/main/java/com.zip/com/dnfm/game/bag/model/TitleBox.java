package com.dnfm.game.bag.model;

import com.dnfm.common.thread.IdGenerator;
import com.dnfm.game.config.Equip;
import com.dnfm.game.equip.EquipDataPool;
import com.dnfm.mina.protobuf.PT_EQUIP;
import com.dnfm.mina.protobuf.PT_EQUIPPED;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 称号盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
public class TitleBox {

    // 最大数量
    private int maxcount = 40;

    // 称号映射表 (guid -> PT_EQUIP)
    private Map<Long, PT_EQUIP> titleMap = new HashMap<>();

    /**
     * 添加称号。
     * @param title 要添加的称号。
     */
    public void addTitle(PT_EQUIP title) {
        this.titleMap.put(title.getGuid(), title); // 假设 PT_EQUIP 有 getter
    }

    /**
     * 获取称号列表。
     * @return 称号列表。
     */
    public List<PT_EQUIP> getTitleList() {
        return new ArrayList<>(this.titleMap.values());
    }

    /**
     * 根据 GUID 移除称号。
     * @param guid 称号 GUID。
     */
    public void removeTitle(long guid) {
        this.titleMap.remove(guid);
    }

    /**
     * 将 PT_EQUIPPED 转换为 PT_EQUIP 格式的称号。
     * @param ptEquip 来源的 PT_EQUIPPED 对象。
     * @return 转换后的 PT_EQUIP 对象。
     */
    public PT_EQUIP changeTitle(PT_EQUIPPED ptEquip) {
        PT_EQUIP title = new PT_EQUIP();
        title.score = ptEquip.getScore(); // 假设 PT_EQUIP 和 PT_EQUIPPED 有 getter/setter
        title.setIndex(ptEquip.getIndex());
        title.setGuid(ptEquip.getGuid());
        title.setQuality(ptEquip.getQuality());
        return title;
    }

    /**
     * 根据 GUID 获取称号。
     * @param guid 称号 GUID。
     * @return 对应的称号，如果未找到则返回 null。
     */
    public PT_EQUIP getTitle(long guid) {
        return this.titleMap.get(guid);
    }

    /**
     * 添加称号（根据索引创建）。
     * @param index 称号索引。
     * @return 创建的称号对象。
     */
    public PT_EQUIP addTitle(int index) {
        Equip equip = (Equip) EquipDataPool.index2Equip.get(index);
        if (equip == null) {
            // 可以选择抛出异常或返回 null
            // throw new IllegalArgumentException("Equip with index " + index + " not found in EquipDataPool");
            return null;
        }
        PT_EQUIP title = new PT_EQUIP();
        title.score = equip.getScore(); // 假设 PT_EQUIP 和 Equip 有 getter/setter
        title.setIndex(index);
        title.setGuid(IdGenerator.getNextId());
        title.setQuality(100);
        this.titleMap.put(title.getGuid(), title);
        return title;
    }

    /**
     * 创建称号（根据索引创建）。
     * @param index 称号索引。
     * @return 创建的称号对象。
     */
    public PT_EQUIP createTitle(int index) {
        Equip equip = (Equip) EquipDataPool.index2Equip.get(index);
        if (equip == null) {
            // 可以选择抛出异常或返回 null
            // throw new IllegalArgumentException("Equip with index " + index + " not found in EquipDataPool");
            return null;
        }
        PT_EQUIP ptEquip = new PT_EQUIP();
        ptEquip.score = equip.getScore(); // 假设 PT_EQUIP 和 Equip 有 getter/setter
        ptEquip.setIndex(index);
        ptEquip.setGuid(IdGenerator.getNextId());
        ptEquip.setQuality(100);
        this.titleMap.put(ptEquip.getGuid(), ptEquip);
        return ptEquip;
    }

    /**
     * 获取称号列表（与 getTitleList 方法相同）。
     * @return 称号列表。
     */
    public List<PT_EQUIP> getTitles() {
        return new ArrayList<>(this.titleMap.values());
    }

    /**
     * 根据 GUID 移除称号。
     * @param guid 称号 GUID。
     */
    public void remove(long guid) {
        this.titleMap.remove(guid);
    }
}