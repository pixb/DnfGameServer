// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.game.bag.model;

import com.dnfm.common.thread.IdGenerator;
import com.dnfm.game.config.Equip;
import com.dnfm.game.equip.EquipDataPool;
import com.dnfm.logs.LoggerUtils;
import com.dnfm.mina.protobuf.PT_AVATAR_ITEM;
import com.dnfm.mina.protobuf.PT_EQUIPPED;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 头像盒
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
@Slf4j // 自动生成 log 日志对象
public class AvatarBox {

    private int maxcount = 40;
    private Map<Long, PT_AVATAR_ITEM> avatarMap = new HashMap<>();

    public void addAvatar(PT_AVATAR_ITEM avatar) {
        LoggerUtils.debug("===addAvatar===index===" + avatar);
        if (this.avatarMap == null) {
            this.avatarMap = new HashMap<>();
        }
        long key = avatar.guid; // 假设 PT_AVATAR_ITEM 有 getter
        this.avatarMap.put(key, avatar);
    }

    public PT_AVATAR_ITEM addAvatar(int index) {
        LoggerUtils.debug("===addAvatar===index===" + index);
        Equip equip = (Equip) EquipDataPool.index2Equip.get(index);
        if (equip == null) {
            log.warn("Equip with index {} not found in EquipDataPool", index);
            return null; // 或者抛出异常
        }
        PT_AVATAR_ITEM avatar = new PT_AVATAR_ITEM();
        avatar.setScore(equip.getScore()); // 假设 PT_AVATAR_ITEM 和 Equip 有 getter/setter
        avatar.index = index;
        avatar.guid = IdGenerator.getNextId();
        this.avatarMap.put(avatar.guid, avatar);
        return avatar;
    }

    /**
     * @param index 装备索引
     * @return 创建的头像项
     */
    public PT_AVATAR_ITEM createAvatar(int index) {
        // index查到装备
        LoggerUtils.debug("===createAvatar===index===" + index);
        Equip equip = (Equip) EquipDataPool.index2Equip.get(index);
        if (equip == null) {
            log.warn("Equip with index {} not found in EquipDataPool during createAvatar", index);
            return null; // 或者抛出异常
        }
        PT_AVATAR_ITEM avatar = new PT_AVATAR_ITEM();
        avatar.setScore(equip.getScore());
        avatar.index = index;
        avatar.guid = IdGenerator.getNextId();
        this.avatarMap.put(avatar.guid, avatar);
        return avatar;
    }

    public PT_AVATAR_ITEM changeAvatar(PT_EQUIPPED ptEquip) {
        if (ptEquip == null) {
            log.warn("PT_EQUIPPED is null, cannot changeAvatar");
            return null;
        }
        PT_AVATAR_ITEM avatar = new PT_AVATAR_ITEM();
        avatar.setScore(ptEquip.getScore()); // 假设 PT_EQUIPPED 有 getter
        avatar.index = ptEquip.getIndex();
        avatar.guid = ptEquip.getGuid();
        return avatar;
    }

    public List<PT_AVATAR_ITEM> getAvatars() {
        if (this.avatarMap == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(this.avatarMap.values());
    }

    public PT_AVATAR_ITEM getAvatar(long guid) {
        if (this.avatarMap == null) {
            return null;
        }
        return this.avatarMap.get(guid);
    }

    public void remove(long guid) {
        if (this.avatarMap != null) {
            this.avatarMap.remove(guid);
        }
    }
}