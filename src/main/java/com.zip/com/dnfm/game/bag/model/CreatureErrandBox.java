package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_CREATURE_ERRAND;

public class CreatureErrandBox {
  public String toString() {
    return "CreatureErrandBox(errandinfo=" + getErrandinfo() + ")";
  }
  
  public int hashCode() {
    int PRIME = 59;
    int result = 1;
    return result * 59 + ((errandinfo == null) ? 43 : errandinfo.hashCode());
  }
  
  protected boolean canEqual(Object other) {
    return other instanceof CreatureErrandBox;
  }
  
  public boolean equals(Object o) {
    if (o == this)
      return true; 
    if (!(o instanceof CreatureErrandBox))
      return false; 
    CreatureErrandBox other = (CreatureErrandBox)o;
    if (!other.canEqual(this))
      return false; 
    Object this$errandinfo = getErrandinfo(), other$errandinfo = other.getErrandinfo();
    return !((this$errandinfo == null) ? (other$errandinfo != null) : !this$errandinfo.equals(other$errandinfo));
  }
  
  public void setErrandinfo(PT_CREATURE_ERRAND errandinfo) {
    this.errandinfo = errandinfo;
  }
  
  private PT_CREATURE_ERRAND errandinfo = new PT_CREATURE_ERRAND();
  
  public PT_CREATURE_ERRAND getErrandinfo() {
    return this.errandinfo;
  }
}
