package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_ADVENTUREBOOK_INFO;
import com.dnfm.mina.protobuf.PT_ADVENTUREBOOK_OPEN_CONDITION;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.List;

/**
 * 冒险书盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
@AllArgsConstructor // 生成包含所有字段的构造函数
public class AdvBookBox {

    // 冒险书列表
    private List<PT_ADVENTUREBOOK_INFO> adventurebooks;

    // 开启条件列表
    private List<PT_ADVENTUREBOOK_OPEN_CONDITION> openconditions;
}