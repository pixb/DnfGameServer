package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.DEF_ITEM_CONSUMABLE;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 消耗品盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
@Slf4j // 自动生成 log 日志对象
public class ConsumableBox {

    private int maxcount = 40;
    private Map<Integer, DEF_ITEM_CONSUMABLE> consumableMap = new HashMap<>();

    /**
     * 添加消耗品到盒子中。
     * 如果数量为 0，则移除该消耗品。
     * @param consumable 要添加的消耗品。
     */
    public void addConsumable(DEF_ITEM_CONSUMABLE consumable) {
        if (consumable.count == 0) { // 假设 DEF_ITEM_CONSUMABLE 有 getter
            this.consumableMap.remove(consumable.index);
        } else {
            this.consumableMap.put(consumable.index, consumable);
        }
    }

    /**
     * 根据索引移除消耗品。
     * @param index 要移除的消耗品索引。
     */
    public void removeConsumable(int index) {
        this.consumableMap.remove(index);
    }

    /**
     * 添加来自 PT_STACKABLE 的消耗品。
     * 如果数量为 0，则移除该消耗品。
     * @param consumable 来源的 PT_STACKABLE 对象。
     */
    public void addConsumable(PT_STACKABLE consumable) {
        if (consumable.getCount() == 0) { // 假设 PT_STACKABLE 有 getter
            this.consumableMap.remove(consumable.getIndex());
        } else {
            DEF_ITEM_CONSUMABLE defItemConsumable = new DEF_ITEM_CONSUMABLE();
            defItemConsumable.index = consumable.getIndex(); // 假设 DEF_ITEM_CONSUMABLE 有 setter
            defItemConsumable.count = consumable.getCount();
            this.consumableMap.put(consumable.getIndex(), defItemConsumable);
        }
    }

    /**
     * 更新消耗品数量（增加）。
     * 如果不存在，则创建新的。
     * @param consume 包含索引和数量变化的 PT_STACKABLE 对象。
     */
    public void updateConsume(PT_STACKABLE consume) {
        DEF_ITEM_CONSUMABLE oldConsume = this.consumableMap.get(consume.getIndex());
        if (oldConsume == null) {
            DEF_ITEM_CONSUMABLE newConsume = new DEF_ITEM_CONSUMABLE();
            newConsume.index = consume.getIndex();
            newConsume.count = consume.getCount();
            this.consumableMap.put(consume.getIndex(), newConsume);
        } else {
            oldConsume.count = oldConsume.count + consume.getCount();
        }
    }

    /**
     * 更新消耗品数量（减少）。
     * 如果数量小于等于 0，则移除该消耗品。
     * @param index 消耗品索引。
     * @param count 要减少的数量。
     */
    public void updateConsumeSub(int index, int count) {
        DEF_ITEM_CONSUMABLE consume = this.consumableMap.get(index);
        if (consume == null) {
            log.error("UNREACH==updateConsumeSub==不应该执行到这里");
            // 可以选择抛出异常或返回
            // throw new IllegalArgumentException("Consumable with index " + index + " not found for subtraction.");
            return;
        } else {
            consume.count = consume.count - count;
        }

        if (consume.count <= 0) {
            this.consumableMap.remove(index);
        }
    }

    /**
     * 更新消耗品数量（增加）。
     * 如果不存在，则创建新的。
     * @param index 消耗品索引。
     * @param count 要增加的数量。
     */
    public void updateConsumeAdd(int index, int count) {
        DEF_ITEM_CONSUMABLE consume = this.consumableMap.get(index);
        if (consume == null) {
            consume = new DEF_ITEM_CONSUMABLE();
            consume.index = index;
            consume.count = count;
            this.consumableMap.put(index, consume);
        } else {
            consume.count = consume.count + count;
        }
    }

    /**
     * 获取消耗品列表。
     * @return 消耗品列表。
     */
    public List<DEF_ITEM_CONSUMABLE> getConsumeList() {
        return new ArrayList<>(this.consumableMap.values());
    }

    /**
     * 根据索引获取消耗品。
     * @param index 消耗品索引。
     * @return 对应的消耗品，如果未找到则返回 null。
     */
    public DEF_ITEM_CONSUMABLE getConsumable(int index) {
        return this.consumableMap.get(index);
    }
}