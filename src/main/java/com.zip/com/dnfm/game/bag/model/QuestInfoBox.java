package com.dnfm.game.bag.model;

import com.dnfm.mina.cache.DataCache;
import com.dnfm.mina.protobuf.PT_QUEST_INFO;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 任务信息盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
public class QuestInfoBox {

    // 任务状态
    private int queststate = 0;

    // 任务列表
    private List<PT_QUEST_INFO> quest = new ArrayList<>();

    // 任务 ID 到任务信息的映射
    private Map<Integer, PT_QUEST_INFO> id2QuestMap = new HashMap<>();

    // 任务 ID 到任务索引的映射
    private Map<Integer, Integer> id2IndexMap = new HashMap<>();

    // 任务索引到任务 ID 的映射
    private Map<Integer, Integer> index2IdMap = new HashMap<>();

    /**
     * 添加任务信息。
     * @param quest 要添加的任务信息。
     */
    public void addQuest(PT_QUEST_INFO quest) {
        if (this.quest == null) {
            this.quest = new ArrayList<>();
        }
        this.quest.add(quest);
        Integer id = (Integer) DataCache.QUEST_INDEX2ID_MAP.get(quest.qindex); // 假设 PT_QUEST_INFO 有 getter
        if (id != null) {
            this.index2IdMap.put(quest.qindex, id); // 假设 PT_QUEST_INFO 有 getter
        }
        this.id2QuestMap.put(id, quest);
        this.id2IndexMap.put(id, quest.qindex); // 假设 PT_QUEST_INFO 有 getter
    }

    /**
     * 添加任务信息（重载方法，指定索引、状态和是否为主线）。
     * @param index 任务索引。
     * @param state 任务状态。
     * @param ismine 是否为主线任务。
     */
    public void addQuest(int index, int state, boolean ismine) {
        PT_QUEST_INFO ptQuestInfo = new PT_QUEST_INFO();
        ptQuestInfo.qindex = index; // 假设 PT_QUEST_INFO 有 setter
        if (state != 0) {
            ptQuestInfo.state = state; // 假设 PT_QUEST_INFO 有 setter
        }
        if (ismine) {
            ptQuestInfo.isminequest = true; // 假设 PT_QUEST_INFO 有 setter
        }
        this.quest.add(ptQuestInfo);
        Integer id = (Integer) DataCache.QUEST_INDEX2ID_MAP.get(index);
        if (id != null) {
            this.index2IdMap.put(index, id);
        }
        this.id2QuestMap.put(id, ptQuestInfo);
        this.id2IndexMap.put(id, index);
    }

    /**
     * 添加任务信息（重载方法，指定索引和状态）。
     * @param index 任务索引。
     * @param state 任务状态。
     */
    public void addQuest(int index, int state) {
        PT_QUEST_INFO ptQuestInfo = new PT_QUEST_INFO();
        ptQuestInfo.qindex = index; // 假设 PT_QUEST_INFO 有 setter
        if (state != 0) {
            ptQuestInfo.state = state; // 假设 PT_QUEST_INFO 有 setter
        }
        ptQuestInfo.isminequest = true; // 假设 PT_QUEST_INFO 有 setter
        this.quest.add(ptQuestInfo);
        Integer id = (Integer) DataCache.QUEST_INDEX2ID_MAP.get(index);
        if (id != null) {
            this.index2IdMap.put(index, id);
        }
        this.id2QuestMap.put(id, ptQuestInfo);
        this.id2IndexMap.put(id, index);
    }

    /**
     * 添加任务信息（重载方法，指定索引、状态和计数）。
     * @param index 任务索引。
     * @param state 任务状态。
     * @param cnt 任务计数。
     */
    public void addQuest(int index, int state, int cnt) {
        PT_QUEST_INFO ptQuestInfo = new PT_QUEST_INFO();
        ptQuestInfo.qindex = index; // 假设 PT_QUEST_INFO 有 setter
        if (state != 0) {
            ptQuestInfo.state = state; // 假设 PT_QUEST_INFO 有 setter
        }
        ptQuestInfo.count = cnt; // 假设 PT_QUEST_INFO 有 setter
        ptQuestInfo.isminequest = true; // 假设 PT_QUEST_INFO 有 setter
        this.quest.add(ptQuestInfo);
        Integer id = (Integer) DataCache.QUEST_INDEX2ID_MAP.get(index);
        if (id != null) {
            this.index2IdMap.put(index, id);
        }
        this.id2QuestMap.put(id, ptQuestInfo);
        this.id2IndexMap.put(id, index);
    }

    /**
     * 添加任务信息（重载方法，仅指定索引）。
     * @param index 任务索引。
     */
    public void addQuest(int index) {
        PT_QUEST_INFO ptQuestInfo = new PT_QUEST_INFO();
        ptQuestInfo.qindex = index; // 假设 PT_QUEST_INFO 有 setter
        ptQuestInfo.isminequest = true; // 假设 PT_QUEST_INFO 有 setter
        this.quest.add(ptQuestInfo);
        Integer id = (Integer) DataCache.QUEST_INDEX2ID_MAP.get(index);
        if (id != null) {
            this.index2IdMap.put(index, id);
        }
        this.id2QuestMap.put(id, ptQuestInfo);
        this.id2IndexMap.put(id, index);
    }

    /**
     * 根据任务 ID 移除任务。
     * @param id 任务 ID。
     */
    public void removeQuestById(int id) {
        PT_QUEST_INFO ptQuestInfo = this.id2QuestMap.get(id);
        removeQuest(ptQuestInfo, id);
    }

    /**
     * 内部方法，移除任务。
     * @param ptQuestInfo 要移除的任务信息。
     * @param id 任务 ID。
     */
    private void removeQuest(PT_QUEST_INFO ptQuestInfo, int id) {
        if (ptQuestInfo != null) { // 添加 null 检查
            this.quest.remove(ptQuestInfo);
            this.id2QuestMap.remove(id);
            this.id2IndexMap.remove(id);
            this.index2IdMap.remove(ptQuestInfo.qindex); // 假设 PT_QUEST_INFO 有 getter
        }
    }

    /**
     * 更新任务状态。
     * @param qindex 任务索引。
     * @param state 新的任务状态。
     */
    public void updateQuestState(int qindex, int state) {
        for (int i = 0; i < this.quest.size(); i++) {
            if (this.quest.get(i).qindex == qindex) { // 假设 PT_QUEST_INFO 有 getter
                this.quest.get(i).state = state; // 假设 PT_QUEST_INFO 有 setter
                break;
            }
        }
    }
}