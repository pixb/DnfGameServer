package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_STACKABLE;
import java.util.ArrayList;
import java.util.List;

public class CrackBox {
  private int maxcount;
  
  public void setMaxcount(int maxcount) {
    this.maxcount = maxcount;
  }
  
  public void setCracks(List<PT_STACKABLE> cracks) {
    this.cracks = cracks;
  }
  
  public boolean equals(Object o) {
    if (o == this)
      return true; 
    if (!(o instanceof CrackBox))
      return false; 
    CrackBox other = (CrackBox)o;
    if (!other.canEqual(this))
      return false; 
    if (getMaxcount() != other.getMaxcount())
      return false; 
    return !((this.cracks == null) ? (other.cracks != null) : !this.cracks.equals(other.cracks));
  }
  
  protected boolean canEqual(Object other) {
    return other instanceof CrackBox;
  }
  
  public int hashCode() {
    int PRIME = 59;
    int result = 1;
    result = result * 59 + getMaxcount();
    return result * 59 + ((cracks == null) ? 43 : cracks.hashCode());
  }
  
  public String toString() {
    return "CrackBox(maxcount=" + getMaxcount() + ", cracks=" + getCracks() + ")";
  }
  
  public int getMaxcount() {
    return this.maxcount;
  }
  
  private List<PT_STACKABLE> cracks = new ArrayList<>();
  
  public List<PT_STACKABLE> getCracks() {
    return this.cracks;
  }
  
  public void addCrack(PT_STACKABLE crack) {
    this.cracks.add(crack);
  }
}
