/*    */
package com.dnfm.game.bag.model;

/*    */
/*    */

import com.dnfm.mina.protobuf.PT_SHOP_BUY_COUNT;
/*    */ import com.dnfm.mina.protobuf.PT_SHOP_GROUP_RESET;
/*    */ import com.dnfm.mina.protobuf.PT_SHOP_TAB_RESET;

import java.util.ArrayList;
import java.util.List;

/*    */
/*    */ public class AccShopInfoBox {
    /*    */   public List<PT_SHOP_TAB_RESET> reset;

    /*    */
    /* 10 */
    public void setReset(List<PT_SHOP_TAB_RESET> reset) {
        this.reset = reset;
    }

    public List<PT_SHOP_GROUP_RESET> group;
    private List<PT_SHOP_BUY_COUNT> buy;

    public void setGroup(List<PT_SHOP_GROUP_RESET> group) {
        this.group = group;
    }

    public void setBuy(List<PT_SHOP_BUY_COUNT> buy) {
        this.buy = buy;
    }

    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof AccShopInfoBox)) return false;
        AccShopInfoBox other = (AccShopInfoBox) o;
        if (!other.canEqual(this)) return false;
        if ((this.reset == null) ? (other.reset != null) : !this.reset.equals(other.reset)) return false;
        if ((this.group == null) ? (other.group != null) : !this.group.equals(other.group)) return false;
        return !((this.buy == null) ? (other.buy != null) : !this.buy.equals(other.buy));
    }

    protected boolean canEqual(Object other) {
        return other instanceof AccShopInfoBox;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + ((reset == null) ? 43 : getReset().hashCode());
        result = result * 59 + ((group == null) ? 43 : group.hashCode());
        return result * 59 + ((buy == null) ? 43 : buy.hashCode());
    }

    public String toString() {
        return "AccShopInfoBox(reset=" + getReset() + ", group=" + getGroup() + ", buy=" + getBuy() + ")";
    }

    /*    */
    /* 12 */
    public List<PT_SHOP_TAB_RESET> getReset() {
        return this.reset;
    }

    /* 13 */
    public List<PT_SHOP_GROUP_RESET> getGroup() {
        return this.group;
    }

    public List<PT_SHOP_BUY_COUNT> getBuy() {
        /* 14 */
        return this.buy;
        /*    */
    }

    /*    */
    public void addBuy(PT_SHOP_BUY_COUNT ptShopBuyCount) {
        /* 17 */
        if (this.buy == null) {
            /* 18 */
            this.buy = new ArrayList<>();
            /*    */
        }
        /* 20 */
        this.buy.add(ptShopBuyCount);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\bag\model\AccShopInfoBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */