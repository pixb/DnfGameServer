/*    */
package com.dnfm.game.bag.model;

/*    */
/*    */ import com.dnfm.mina.protobuf.PT_CHARGUID_ENTRANCE_ITEM;
/*    */ import com.dnfm.mina.protobuf.PT_CHARGUID_FATIGUE;
/*    */ import com.dnfm.mina.protobuf.PT_CHARGUID_TICKET;
/*    */ import com.dnfm.mina.protobuf.PT_SUBDUE_INFO;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AdvUnionSubInfoBox
/*    */ {
/* 11 */   public List<PT_SUBDUE_INFO> list = null;
/*    */   
/* 13 */   public List<PT_CHARGUID_FATIGUE> fatigues = null;
/*    */   
/* 15 */   public List<PT_CHARGUID_TICKET> tickets = null;
/*    */   
/* 17 */   public List<PT_CHARGUID_ENTRANCE_ITEM> entranceitems = null;
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\bag\model\AdvUnionSubInfoBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */