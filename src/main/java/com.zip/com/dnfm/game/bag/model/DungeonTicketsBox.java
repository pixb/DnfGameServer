package com.dnfm.game.bag.model;

import com.dnfm.mina.protobuf.PT_GAUGE;
import com.dnfm.mina.protobuf.PT_TICKET;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 地下城门票盒子模型类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@NoArgsConstructor // 生成无参构造函数
public class DungeonTicketsBox {

    // 地狱模式计量条
    private int hellGauge = 0;

    // 门票映射表
    private Map<String, PT_TICKET> ticketMap = new HashMap<>();

    // 门票列表 (可能由 ticketMap 生成)
    private List<PT_TICKET> ticket;

    // 贪婪罐子
    private int jarofgreed;

    // 彩票免费次数
    private int lotteryfreecount;

    // 接收好友次数
    private int recvfriendcount;

    // 发送好友次数
    private int sendfriendcount;

    // 接收平台好友次数
    private int recvplatformfriendcount;

    // 发送平台好友次数
    private int sendplatformfriendcount;

    // 公会红包接收次数
    private int guildredpacketrecvcount;

    // 公会红包发送次数
    private int guildredpacketsendcount;

    // 战斗联赛奖励限制
    private int battleleaguerewardlimit;

    // 清扫地下城列表
    private List<Integer> clearsweepdungeonlist;

    // 计量条列表
    private List<PT_GAUGE> gauges;

    // 战斗联赛公会奖励限制
    private int battleleagueguildrewardlimit;

    // 宾果门票数量
    private int bingoticketcount;

    /**
     * 消耗指定类型的每日门票。
     * @param dungeonType 地下城类型。
     */
    public void subDailyTicket(String dungeonType) {
        PT_TICKET ptTicket = this.ticketMap.get(dungeonType);
        if (ptTicket != null && ptTicket.dailyticket != null && ptTicket.dailyticket > 0) {
            ptTicket.dailyticket = ptTicket.dailyticket - 1;
        }
    }

    /**
     * 获取门票列表 (从 ticketMap 生成)。
     * @return 门票列表。
     */
    public List<PT_TICKET> getTicketList() {
        return new ArrayList<>(this.ticketMap.values());
    }
}