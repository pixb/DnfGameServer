package com.dnfm.game.identity;

import lombok.Getter;

@Getter
public enum IdentityType {
    ROLE_EQUIP(1),
    BOOK(2),
    TASK(3),
    SUPER_BOSS(4, false),
    ROLE(5);

    private final int type;
    private final boolean save;

    IdentityType(int type) {
        this.type = type;
        this.save = true;
    }

    IdentityType(int type, boolean save) {
        this.type = type;
        this.save = save;
    }
}