package com.dnfm.game.role.serializer;


import com.dnfm.game.role.model.Account;
import com.dnfm.game.role.serializer.IAccountPropSerializer;

public class MailBoxSerializer implements IAccountPropSerializer {
  public void serialize(Account account) {}
  
  public void deserialize(Account account) {}
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\serializer\MailBoxSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */