package com.dnfm.game.role.model;

import java.io.Serializable;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Default;
import org.nutz.dao.entity.annotation.Name;
import org.nutz.dao.entity.annotation.Table;

@Table("t_account")
public class AccountLogin implements Serializable {
    @Name
    @Comment("openId")
    private String id;

    @Column
    private String userID;

    @Column
    private String passwd;

    @Column
    private boolean isStop;

    @Column
    private short privilege;

    public void setId(String id) {
        this.id = id;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public void setPrivilege(short privilege) {
        this.privilege = privilege;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setChannelNo(String channelNo) {
        this.channelNo = channelNo;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof com.dnfm.game.role.model.AccountLogin))
            return false;
        com.dnfm.game.role.model.AccountLogin other = (com.dnfm.game.role.model.AccountLogin)o;
        if (!other.canEqual(this))
            return false;
        Object this$id = getId(), other$id = other.getId();
        if ((this$id == null) ? (other$id != null) : !this$id.equals(other$id))
            return false;
        Object this$userID = getUserID(), other$userID = other.getUserID();
        if ((this$userID == null) ? (other$userID != null) : !this$userID.equals(other$userID))
            return false;
        Object this$passwd = getPasswd(), other$passwd = other.getPasswd();
        if ((this$passwd == null) ? (other$passwd != null) : !this$passwd.equals(other$passwd))
            return false;
        if (getIsStop() != other.getIsStop())
            return false;
        if (getPrivilege() != other.getPrivilege())
            return false;
        if (getScore() != other.getScore())
            return false;
        Object this$channelNo = getChannelNo(), other$channelNo = other.getChannelNo();
        return !((this$channelNo == null) ? (other$channelNo != null) : !this$channelNo.equals(other$channelNo));
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.role.model.AccountLogin;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        Object $id = getId();
        result = result * 59 + (($id == null) ? 43 : $id.hashCode());
        Object $userID = getUserID();
        result = result * 59 + (($userID == null) ? 43 : $userID.hashCode());
        Object $passwd = getPasswd();
        result = result * 59 + (($passwd == null) ? 43 : $passwd.hashCode());
        result = result * 59 + (getIsStop() ? 79 : 97);
        result = result * 59 + getPrivilege();
        result = result * 59 + getScore();
        Object $channelNo = getChannelNo();
        return result * 59 + (($channelNo == null) ? 43 : $channelNo.hashCode());
    }

    public String toString() {
        return "AccountLogin(id=" + getId() + ", userID=" + getUserID() + ", passwd=" + getPasswd() + ", isStop=" + getIsStop() + ", privilege=" + getPrivilege() + ", score=" + getScore() + ", channelNo=" + getChannelNo() + ")";
    }

    public String getId() {
        return this.id;
    }

    public String getUserID() {
        return this.userID;
    }

    public String getPasswd() {
        return this.passwd;
    }

    public short getPrivilege() {
        return this.privilege;
    }

    @Column
    @Default("0")
    private int score = 0;

    @Column
    private String channelNo;

    public int getScore() {
        return this.score;
    }

    public String getChannelNo() {
        return this.channelNo;
    }

    public boolean getIsStop() {
        return this.isStop;
    }

    public void setIsStop(boolean isStop) {
        this.isStop = isStop;
    }
}
