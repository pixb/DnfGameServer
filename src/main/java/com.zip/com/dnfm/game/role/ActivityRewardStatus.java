/*    */
package com.dnfm.game.role;
/*    */ 
/*    */ public class ActivityRewardStatus {
/*    */   private short activity;
/*    */   private byte status;
/*    */   
/*    */   public short getActivity() {
/*  8 */     return this.activity;
/*    */   }
/*    */   
/*    */   public void setActivity(short activity) {
/* 12 */     this.activity = activity;
/*    */   }
/*    */   
/*    */   public byte getStatus() {
/* 16 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(byte status) {
/* 20 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\ActivityRewardStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */