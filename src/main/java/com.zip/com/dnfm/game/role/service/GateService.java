/*    */
package com.dnfm.game.role.service;

/*    */
/*    */

import com.alibaba.fastjson.JSON;
/*    */ import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.game.ServerService;
/*    */ import com.dnfm.game.player.model.PlayerProfile;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.nutz.http.Request;
/*    */ import org.nutz.http.Sender;
/*    */ import org.springframework.stereotype.Service;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
@Service
/*    */ public class GateService
        /*    */ {
    /*    */
    public void addRoleToDist(String sid, PlayerProfile playerProfile) {
        /* 24 */
        Map<String, Object> params = new HashMap<>();
        /* 25 */
        params.put("sid", sid);
        /* 26 */
        params.put("content", JSON.toJSONString(playerProfile));
        /*    */
        try {
            /* 28 */
            Request request = Request.create(((ServerService) SpringUtils.getBean(ServerService.class)).getLoginServerUrl() + "/game/addRole", Request.METHOD.POST).setParams(params);
            /* 29 */
            Sender.create(request).setTimeout(1000).send();
            /* 30 */
        } catch (Exception exception) {
        }
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\service\GateService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */