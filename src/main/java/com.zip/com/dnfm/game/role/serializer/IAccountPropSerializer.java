package com.dnfm.game.role.serializer;


import com.dnfm.game.role.model.Account;

public interface IAccountPropSerializer {
  void serialize(Account paramAccount);
  
  void deserialize(Account paramAccount);
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\serializer\IAccountPropSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */