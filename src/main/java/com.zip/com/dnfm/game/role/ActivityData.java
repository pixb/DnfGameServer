/*    */
package com.dnfm.game.role;
/*    */ 
/*    */ public class ActivityData {
/*    */   private String name;
/*    */   private short count;
/*    */   private short activeValue;
/*    */   private String timeStr;
/*    */   
/*    */   public String getName() {
/* 10 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 14 */     this.name = name;
/*    */   }
/*    */   
/*    */   public short getCount() {
/* 18 */     return this.count;
/*    */   }
/*    */   
/*    */   public void setCount(short count) {
/* 22 */     this.count = count;
/*    */   }
/*    */   
/*    */   public short getActiveValue() {
/* 26 */     return this.activeValue;
/*    */   }
/*    */   
/*    */   public void setActiveValue(short activeValue) {
/* 30 */     this.activeValue = activeValue;
/*    */   }
/*    */   
/*    */   public String getTimeStr() {
/* 34 */     return this.timeStr;
/*    */   }
/*    */   
/*    */   public void setTimeStr(String timeStr) {
/* 38 */     this.timeStr = timeStr;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\ActivityData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */