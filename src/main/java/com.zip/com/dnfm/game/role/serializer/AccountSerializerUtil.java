/*    */
package com.dnfm.game.role.serializer;

/*    */
/*    */

import com.dnfm.game.role.model.Account;
/*    */ import com.dnfm.game.role.serializer.IAccountPropSerializer;
/*    */ import com.dnfm.game.utils.ClassScanner;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Set;

/*    */
/*    */ public class AccountSerializerUtil
        /*    */ {
    /*    */   private static final String SCAN_PATH = "com.dnfm.game";
    /* 13 */   private static final List<IAccountPropSerializer> propSerializers = new ArrayList<>();

    /*    */
    /*    */   static {
        /* 16 */
        Set<Class<?>> handler = ClassScanner.listAllSubclasses("com.dnfm.game", IAccountPropSerializer.class);
        /* 17 */
        for (Class<?> clazz : handler) {
            /*    */
            try {
                /* 19 */
                propSerializers.add((IAccountPropSerializer) clazz.newInstance());
                /* 20 */
            } catch (Exception e) {
                /*    */
                /* 22 */
                System.exit(1);
                /*    */
            }
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    public static void serialize(Account account) {
        /* 28 */
        for (IAccountPropSerializer handler : propSerializers) {
            /* 29 */
            handler.serialize(account);
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    public static void deserialize(Account account) {
        /* 34 */
        for (IAccountPropSerializer handler : propSerializers)
            /* 35 */
            handler.deserialize(account);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\serializer\AccountSerializerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */