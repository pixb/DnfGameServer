/*     */
package com.dnfm.game.role.service;

/*     */
/*     */

import com.alibaba.fastjson.JSONObject;
/*     */ import com.dnfm.game.ServerService;
/*     */ import com.dnfm.game.role.model.Role;
/*     */ import com.dnfm.game.role.service.AccountService;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.http.fileupload.IOUtils;
/*     */ import org.nutz.dao.Dao;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.context.annotation.PropertySource;
/*     */ import org.springframework.stereotype.Service;

/*     */
/*     */
@Service
/*     */
@PropertySource({"classpath:game.properties"})
/*     */ public class PayService
        /*     */ {
    /*  29 */ Logger logger = LoggerFactory.getLogger(com.dnfm.game.role.service.PayService.class);
    /*     */
    /*     */
    @Autowired
    /*     */ ServerService serverService;
    /*     */
    @Autowired
    /*     */ Dao dao;
    /*     */
    @Autowired
    /*     */ AccountService accountService;
    /*  37 */   private final int rate = 1;
    /*     */
    /*     */
    @Value("${pay.notify.url}")
    /*     */ private String notifyUrl;
    /*  41 */   private final List<Integer> appoints = new ArrayList<>(Arrays.asList(new Integer[]{Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(33), Integer.valueOf(34), Integer.valueOf(35), Integer.valueOf(41), Integer.valueOf(42), Integer.valueOf(43), Integer.valueOf(44), Integer.valueOf(45), Integer.valueOf(51), Integer.valueOf(52), Integer.valueOf(53), Integer.valueOf(54), Integer.valueOf(55)}));

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    private String crateShortUrl(String longUrl) {
        /*  90 */
        BufferedReader reader = null;
        /*     */
        try {
            /*  92 */
            longUrl = URLEncoder.encode(longUrl, "GBK");
            /*  93 */
            URL url = new URL("http://api.t.sina.com.cn/short_url/shorten.json?source=2849184197&url_long=" + longUrl);
            /*  94 */
            InputStream iStream = url.openStream();
            /*  95 */
            reader = new BufferedReader(new InputStreamReader(iStream));
            /*  96 */
            String jsonStr = reader.readLine();
            /*  97 */
            JSONObject jsonObj = JSONObject.parseArray(jsonStr).getJSONObject(0);
            /*  98 */
            return jsonObj.getString("url_short");
            /*  99 */
        } catch (Exception e) {
            /* 100 */
            return longUrl;
            /*     */
        } finally {
            /* 102 */
            IOUtils.closeQuietly(reader);
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public void loadCommonSet(Map<String, String> commonSetMap) {
    }

    /*     */
    /*     */
    /*     */
    /*     */
    public void handleAccumulativeReward(Role role, int money, int addGold) {
        /* 114 */
        if (role == null) {
            /*     */
            return;
            /*     */
        }
        /*     */
        /* 118 */
        chargeActivity(role, money, addGold);
        /*     */
    }

    /*     */
    /*     */
    private void chargeActivity(Role role, int money, int addGold) {
    }

    /*     */
    /*     */
    public void addReward(int rmb, Role role) {
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\service\PayService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */