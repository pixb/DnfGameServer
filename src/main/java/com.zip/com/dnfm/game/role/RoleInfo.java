/*    */
package com.dnfm.game.role;
/*    */ 
/*    */ public class RoleInfo {
/*  4 */   private int last_login_time = 0;
/*  5 */   private byte a = 0;
/*    */ 
/*    */   
/*    */   public int getLast_login_time() {
/*  9 */     return this.last_login_time;
/*    */   }
/*    */   
/*    */   public void setLast_login_time(int last_login_time) {
/* 13 */     this.last_login_time = last_login_time;
/*    */   }
/*    */   
/*    */   public byte getA() {
/* 17 */     return this.a;
/*    */   }
/*    */   
/*    */   public void setA(byte a) {
/* 21 */     this.a = a;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\RoleInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */