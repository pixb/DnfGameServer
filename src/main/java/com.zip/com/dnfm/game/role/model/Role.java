package com.dnfm.game.role.model;

import com.dnfm.common.db.BaseEntity;
import com.dnfm.common.db.Db4PlayerService;
import com.dnfm.common.model.Pos;
import com.dnfm.game.auction.model.AuctionBox;
import com.dnfm.game.bag.model.*;
import com.dnfm.game.config.ServerSimpleDataBox;
import com.dnfm.game.equip.model.EquipBox;
import com.dnfm.game.friend.model.FriendBox;
import com.dnfm.game.mail.MailBox;
import com.dnfm.game.party.model.DungeonParty;
import com.dnfm.game.skill.model.*;
import lombok.*;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.nutz.dao.entity.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("t_role")
@TableIndexes({
        @Index(fields = {"roleId"}, unique = false),
        @Index(fields = {"uid"}, unique = false),
        @Index(fields = {"openid"}, unique = false),
        @Index(fields = {"name"}, unique = false)
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Role extends BaseEntity<Long> {
    static Logger logger = LoggerFactory.getLogger(Role.class);

    public int lastNotiTransId = 0;

    @Id(auto = false)
    private int roleId;

    @Column
    private long uid;

    @Column
    private long lastlogout;

    @Column
    private int growtype;

    @Column
    private int secgrowtype;

    @Column
    @Default("0")
    private int job = 0;

    @Column
    @Default("1")
    private int level = 1;

    @Column
    private String name;

    @Column
    private int fatigue;

    @Column
    @Default("229")
    private int equipscore = 229;

    @Column
    private int characterframe;

    @Column
    private int money;

    @Column
    private int rescoin;

    @Column
    private int contributioncoin;

    @Column
    private int magiccrystal;

    @Column
    private int highmagiccrystal;

    @Column
    private int cerascore;

    @Column
    private int pkcoin;

    @Column
    private int friendpoint;

    @Column
    private int smallcoin;

    @Column
    private int avatarVisibleFlags;

    @Column
    private int deletionstatus;

    @Column
    private long deletiontime;

    @Column
    private long createtime;

    @Column
    private boolean changename;

    @Column
    private String openid;

    @Column
    @Default("200")
    private int exp = 200;

    @Column
    @Default("40")
    private int sp = 40;

    @Column
    private int tp;

    @Column
    private int addsp;

    @Column
    private int addtp;

    @Column
    private int day;

    @Column
    private int score;

    @Column
    @Default("100110")
    private int qindex = 100110;

    @Column
    private String distName;

    @Column
    private String servername;

    @Column
    private Date updateTime;

    @Column
    @Comment("封号时间")
    private long lockTime;

    @Column
    @Comment("坐标数据")
    private Pos pos = new Pos();

    @Column
    @Default("1")
    private int storageline = 1;

    @Column
    @Comment("禁言时间")
    @Default("0")
    private long wordTime;

    @Column
    @Comment("武器index")
    private int weaponIndex;

    @Column
    @Default("100")
    private int expratio = 100;

    @Column
    @Default("100")
    private int fatigueratio = 100;

    @Column
    private String adventurename = "";

    private long sessionId;
    private boolean unlock;
    private DungeonParty dungeonParty = new DungeonParty();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private ServerSimpleDataBox serverSimpleDataBox = new ServerSimpleDataBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private FriendBox friendBox = new FriendBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private TitleBox titleBox = new TitleBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("装扮背包")
    private AvatarBox avatarBox = new AvatarBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("徽章背包")
    private EmblemBox emblemBox = new EmblemBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private CardBox cardBox = new CardBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("宠物背包")
    private CreatureBox creatureBox = new CreatureBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("宠物装备")
    private ArtifactBox artifactBox = new ArtifactBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("装备背包")
    private EquipBox equipBox = new EquipBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("已装备")
    private EquippedBox equippedBox = new EquippedBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("材料背包")
    private MaterialBox materialBox = new MaterialBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("消耗品背包")
    private ConsumableBox consumableBox = new ConsumableBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("角色购买记录")
    private RoleShopInfoBox roleShopInfoBox = new RoleShopInfoBox();

    @Comment("Flag背包")
    private FlagBox flagBox = new FlagBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private EquipBox crackEquipBox = new EquipBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private CrackBox crackBox = new CrackBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("伤害字体")
    private DamageBox damageBox = new DamageBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("聊天边框")
    private ChatFrameBox chatFrameBox = new ChatFrameBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("人物边框")
    private CharFrameBox charFrameBox = new CharFrameBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private AvatarBox sdAvatarBox = new AvatarBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private BookmarkBox bookmarkBox = new BookmarkBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private EquipBox scrollBox = new EquipBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("金钱")
    private MoneyBox moneyBox = new MoneyBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private CeraShopBuyInfo ceraShopBuyInfo = new CeraShopBuyInfo();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private TutoBox tutoBox = new TutoBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private SkillBox skillBox = new SkillBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private SkillslotBox skillslotBox = new SkillslotBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private DungeonTicketsBox dungeonTicketsBox = new DungeonTicketsBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("魔力强化信息")
    private TonicBox tonicBox = new TonicBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private MailBox mailBox = new MailBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private MailBox sysMailBox = new MailBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    @Comment("角色金库")
    private CharStorageBox charStorageBox = new CharStorageBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private RePurStoItemBox rePurStoItem = new RePurStoItemBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private TowerInfoBox towerInfoBox = new TowerInfoBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private CreatureErrandBox creatureErrandBox = new CreatureErrandBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private LocalRewardBox localRewardBox = new LocalRewardBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private QuestInfoBox questInfoBox = new QuestInfoBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private SysBuffBox sysBuffBox = new SysBuffBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private ClearDungeonBox clearDungeonBox = new ClearDungeonBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private AchievementBox achievementBox = new AchievementBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private CollectionBox collectionBox = new CollectionBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private NoteMsgBox noteMsgBox = new NoteMsgBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private EssenceBox essenceBox = new EssenceBox();

    @Column
    @ColDefine(type = ColType.MYSQL_JSON)
    private AuctionBox auctionBox = new AuctionBox();

    private int distributeKey;
    private transient Map<String, Object> tempCache;
    private Map<Integer, Integer> heartCounts = new HashMap(4);

    public void setPos(int x, int y, int area, int town) {
        this.pos.setX(x);
        this.pos.setY(y);
        this.pos.setArea(area);
        this.pos.setTown(town);
    }

    public void setExp(int exp) {
        if (exp > 999999999) {
            exp = 999999999;
        } else if (exp < 0) {
            exp = 0;
        }
        this.exp = exp;
    }

    @JsonIgnore
    public Long getId() {
        return this.uid;
    }

    public void doAfterInit() {
    }

    public void doBeforeSave() {
    }

    public void save() {
        Db4PlayerService.getInstance().add2Queue(this);
    }

    public Object pushTempCache(String key, Object value) {
        if (this.tempCache == null) {
            this.tempCache = new HashMap(4);
        }
        return this.tempCache.put(key, value);
    }

    public <T> T popTempCache(String key) {
        return this.tempCache == null ? null : (T) this.tempCache.remove(key);
    }

    public <T> T getTempCache(String key, T defaultValue) {
        return this.tempCache == null ? defaultValue : (T) this.tempCache.getOrDefault(key, defaultValue);
    }

    @JsonIgnore
    public int getFollowPetId() {
        return (Integer)this.getTempCache("followPet", 0);
    }

    @Override
    public String toString() {
        return "Role{charguid=" + this.uid + ", name='" + this.name + '\'' + '}';
    }
}