/*    */
package com.dnfm.game.role;

/*    */
/*    */ import com.dnfm.game.config.PetExp;
/*    */ import com.dnfm.game.config.RoleExp;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleDataPool
/*    */ {
/*    */   public static final int in = 0;
/* 15 */   public static Map<Integer, RoleExp> level2RoleExp = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   public static Map<Integer, PetExp> level2PetExp = new HashMap<>();
/*    */   
/* 22 */   public static Map<Integer, String> tonicUpgrade = new HashMap<>();
/*    */   
/*    */   static {
/* 25 */     tonicUpgrade.put(Integer.valueOf(0), "2013102101-1-16000");
/* 26 */     tonicUpgrade.put(Integer.valueOf(1), "2013102100-8-18000");
/* 27 */     tonicUpgrade.put(Integer.valueOf(2), "2013102100-9-20250");
/* 28 */     tonicUpgrade.put(Integer.valueOf(3), "2013102100-10-22782");
/* 29 */     tonicUpgrade.put(Integer.valueOf(4), "2013102100-11-25629");
/* 30 */     tonicUpgrade.put(Integer.valueOf(5), "2013102101-3-28833");
/* 31 */     tonicUpgrade.put(Integer.valueOf(6), "2013102100-13-32437");
/* 32 */     tonicUpgrade.put(Integer.valueOf(7), "2013102100-15-36492");
/* 33 */     tonicUpgrade.put(Integer.valueOf(8), "2013102100-17-41053");
/* 34 */     tonicUpgrade.put(Integer.valueOf(9), "2013102100-19-46185");
/* 35 */     tonicUpgrade.put(Integer.valueOf(10), "2013102101-4-51958");
/* 36 */     tonicUpgrade.put(Integer.valueOf(11), "2013102100-24-58452");
/* 37 */     tonicUpgrade.put(Integer.valueOf(12), "2013102100-27-65759");
/* 38 */     tonicUpgrade.put(Integer.valueOf(13), "2013102100-30-73979");
/* 39 */     tonicUpgrade.put(Integer.valueOf(14), "2013102100-34-83226");
/* 40 */     tonicUpgrade.put(Integer.valueOf(15), "2013102101-6-93629");
/* 41 */     tonicUpgrade.put(Integer.valueOf(16), "2013102100-43-105333");
/* 42 */     tonicUpgrade.put(Integer.valueOf(17), "2013102100-48-118499");
/* 43 */     tonicUpgrade.put(Integer.valueOf(18), "2013102100-54-133311");
/* 44 */     tonicUpgrade.put(Integer.valueOf(19), "2013102100-60-149975");
/* 45 */     tonicUpgrade.put(Integer.valueOf(20), "2013102101-8-168722");
/* 46 */     tonicUpgrade.put(Integer.valueOf(21), "2013102100-76-189812");
/* 47 */     tonicUpgrade.put(Integer.valueOf(22), "2013102100-86-213539");
/* 48 */     tonicUpgrade.put(Integer.valueOf(23), "2013102100-97-240231");
/* 49 */     tonicUpgrade.put(Integer.valueOf(24), "2013102100-109-270260");
/* 50 */     tonicUpgrade.put(Integer.valueOf(25), "2013102101-9-304042");
/* 51 */     tonicUpgrade.put(Integer.valueOf(26), "2013102100-137-342047");
/* 52 */     tonicUpgrade.put(Integer.valueOf(27), "2013102100-154-384803");
/* 53 */     tonicUpgrade.put(Integer.valueOf(28), "2013102100-174-432904");
/* 54 */     tonicUpgrade.put(Integer.valueOf(29), "2013102100-195-487016");
/* 55 */     tonicUpgrade.put(Integer.valueOf(30), "2013102101-11-547893");
/* 56 */     tonicUpgrade.put(Integer.valueOf(31), "2013102100-247-616380");
/* 57 */     tonicUpgrade.put(Integer.valueOf(32), "2013102100-278-693427");
/* 58 */     tonicUpgrade.put(Integer.valueOf(33), "2013102100-313-780106");
/* 59 */     tonicUpgrade.put(Integer.valueOf(34), "2013102100-352-877619");
/* 60 */     tonicUpgrade.put(Integer.valueOf(35), "2013102101-13-987321");
/* 61 */     tonicUpgrade.put(Integer.valueOf(36), "2013102100-445-1110736");
/* 62 */     tonicUpgrade.put(Integer.valueOf(37), "2013102100-500-1249578");
/* 63 */     tonicUpgrade.put(Integer.valueOf(38), "2013102100-563-1405776");
/* 64 */     tonicUpgrade.put(Integer.valueOf(39), "2013102100-633-1581497");
/* 65 */     tonicUpgrade.put(Integer.valueOf(40), "2013102101-14-1779185");
/* 66 */     tonicUpgrade.put(Integer.valueOf(41), "2013102100-801-2001583");
/* 67 */     tonicUpgrade.put(Integer.valueOf(42), "2013102100-901-2251780");
/* 68 */     tonicUpgrade.put(Integer.valueOf(43), "2013102100-1014-2533253");
/* 69 */     tonicUpgrade.put(Integer.valueOf(44), "2013102100-1140-2849909");
/* 70 */     tonicUpgrade.put(Integer.valueOf(45), "2013102101-16-3206148");
/* 71 */     tonicUpgrade.put(Integer.valueOf(46), "2013102100-1443-3606916");
/* 72 */     tonicUpgrade.put(Integer.valueOf(47), "2013102100-1624-4057781");
/* 73 */     tonicUpgrade.put(Integer.valueOf(48), "2013102100-1827-4565003");
/* 74 */     tonicUpgrade.put(Integer.valueOf(49), "2013102100-2055-5135629");
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\RoleDataPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */