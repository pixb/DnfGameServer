/*    */
package com.dnfm.game.role;
/*    */ 
/*    */ public class ActivityStatus {
/*    */   private String name;
/*    */   private int start;
/*    */   private int end;
/*    */   
/*    */   public String getName() {
/*  9 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 13 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getStart() {
/* 17 */     return this.start;
/*    */   }
/*    */   
/*    */   public void setStart(int start) {
/* 21 */     this.start = start;
/*    */   }
/*    */   
/*    */   public int getEnd() {
/* 25 */     return this.end;
/*    */   }
/*    */   
/*    */   public void setEnd(int end) {
/* 29 */     this.end = end;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\role\ActivityStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */