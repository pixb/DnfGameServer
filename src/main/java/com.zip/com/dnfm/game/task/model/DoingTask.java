/*    */
package com.dnfm.game.task.model;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class DoingTask
        /*    */ {
    /*    */   private int taskId;
    /*    */   private int targetProgress;
    /*    */   private int fightId;
    /*    */   private int npcId;
    /*    */   private long createTime;

    /*    */
    /*    */
    public DoingTask() {
    }

    /*    */
    /*    */
    public DoingTask(int taskId, int targetProgress) {
        /* 35 */
        this.taskId = taskId;
        /* 36 */
        this.targetProgress = targetProgress;
        /* 37 */
        this.createTime = System.currentTimeMillis();
        /*    */
    }

    /*    */
    /*    */
    public int getTaskId() {
        /* 41 */
        return this.taskId;
        /*    */
    }

    /*    */
    /*    */
    public void setTaskId(int taskId) {
        /* 45 */
        this.taskId = taskId;
        /*    */
    }

    /*    */
    /*    */
    public int getTargetProgress() {
        /* 49 */
        return this.targetProgress;
        /*    */
    }

    /*    */
    /*    */
    public void setTargetProgress(int targetProgress) {
        /* 53 */
        this.targetProgress = targetProgress;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void addProgress(int targetIndex) {
        /* 61 */
        this.targetProgress = targetIndex + 1;
        /*    */
    }

    /*    */
    /*    */
    public int getFightId() {
        /* 65 */
        return this.fightId;
        /*    */
    }

    /*    */
    /*    */
    public void setFightId(int fightId) {
        /* 69 */
        this.fightId = fightId;
        /*    */
    }

    /*    */
    /*    */
    public int getNpcId() {
        /* 73 */
        return this.npcId;
        /*    */
    }

    /*    */
    /*    */
    public void setNpcId(int npcId) {
        /* 77 */
        this.npcId = npcId;
        /*    */
    }

    /*    */
    /*    */
    public long getCreateTime() {
        /* 81 */
        return this.createTime;
        /*    */
    }

    /*    */
    /*    */
    public void setCreateTime(long createTime) {
        /* 85 */
        this.createTime = createTime;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\task\model\DoingTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */