/*    */
package com.dnfm.game.task.model;

/*    */
/*    */
/*    */
/*    */
/*    */ public enum TaskType
        /*    */ {
    /*  8 */   MAIN_LINE(1),
    /*    */
    /* 10 */   SCHOOL(2);
    /*    */
    /*    */   private final int id;

    /*    */
    /*    */
    /*    */   TaskType(int id) {
        /* 16 */
        this.id = id;
        /*    */
    }

    /*    */
    /*    */
    public int getId() {
        /* 20 */
        return this.id;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\task\model\TaskType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */