package com.dnfm.game.task;


import com.dnfm.listener.EventType;
import com.dnfm.listener.annotation.EventHandler;
import com.dnfm.listener.event.HeartBeatEvent;
import com.dnfm.listener.event.LoginEvent;
import org.springframework.stereotype.Controller;

@Controller
public class TaskController {
  @EventHandler({EventType.HEART_BEAT})
  public void handleHeartBeat(HeartBeatEvent heartBeatEvent) {}
  
  @EventHandler({EventType.LOGIN})
  public void handleLoginEvent(LoginEvent loginEvent) {}
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\task\TaskController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */