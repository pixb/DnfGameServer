/*    */
package com.dnfm.game.drop.model.user;

/*    */
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleDrop
/*    */ {
/*    */   private Map<String, Integer> dailyDropCountMap;
/*    */   
/*    */   public void setDailyDropCountMap(Map<String, Integer> dailyDropCountMap) {
/* 12 */     this.dailyDropCountMap = dailyDropCountMap;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Integer> getDailyDropCountMap() {
/* 17 */     return this.dailyDropCountMap;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\drop\mode\\user\RoleDrop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */