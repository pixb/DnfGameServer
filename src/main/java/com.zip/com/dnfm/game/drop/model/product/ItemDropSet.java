/*    */
package com.dnfm.game.drop.model.product;

/*    */
/*    */ import org.nutz.dao.entity.annotation.Table;
/*    */ 
/*    */ @Table("p_itemdropset")
/*    */ public class ItemDropSet {
/*    */   private String itemName;
/*    */   private int dropGroup;
/*    */   
/*    */   public void setItemName(String itemName) {
/* 11 */     this.itemName = itemName; } public void setDropGroup(int dropGroup) { this.dropGroup = dropGroup; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getItemName() {
/* 17 */     return this.itemName;
/*    */   }
/*    */   
/*    */   public int getDropGroup() {
/* 21 */     return this.dropGroup;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\drop\model\product\ItemDropSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */