package com.dnfm.game.auction.model;

import com.dnfm.common.thread.IdGenerator;
import com.dnfm.mina.protobuf.PT_AUCTION_EQUIP;
import com.dnfm.mina.protobuf.PT_AUCTION_STACKABLE;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class AuctionBox {
    private Map<Long, PT_AUCTION_EQUIP> equipBuyMap = new HashMap<>();
    private Map<Long, PT_AUCTION_STACKABLE> stackableBuyMap = new HashMap<>();
    private Map<Long, PT_AUCTION_EQUIP> equipSellMap = new HashMap<>();
    private Map<Long, PT_AUCTION_STACKABLE> stackableSellMap = new HashMap<>();
    private Map<Long, PT_AUCTION_EQUIP> equipMapReg = new HashMap<>();
    private Map<Long, PT_AUCTION_STACKABLE> stackableMapReg = new HashMap<>();

    public List<PT_AUCTION_EQUIP> getEquipRegList() {
        return new ArrayList<>(this.equipMapReg.values());
    }

    public List<PT_AUCTION_STACKABLE> getStackableRegList() {
        return new ArrayList<>(this.stackableMapReg.values());
    }

    public void addEquipReg(PT_AUCTION_EQUIP equip) {
        this.equipMapReg.put(equip.auid, equip);
    }

    public void removeEquipReg(PT_AUCTION_EQUIP equip) {
        this.equipMapReg.remove(equip.auid);
    }

    public void addStackableReg(PT_AUCTION_STACKABLE stackable) {
        this.stackableMapReg.put(stackable.auid, stackable);
    }

    public void removeStackableReg(PT_AUCTION_STACKABLE stackable) {
        this.stackableMapReg.remove(stackable.auid);
    }

    public PT_AUCTION_STACKABLE removeStackableReg(long auid) {
        PT_AUCTION_STACKABLE res = this.stackableMapReg.get(auid);
        this.stackableMapReg.remove(auid);
        return res;
    }

    public PT_AUCTION_EQUIP removeEquipReg(long auid) {
        PT_AUCTION_EQUIP res = this.equipMapReg.get(auid);
        this.equipMapReg.remove(auid);
        return res;
    }

    public void addEquipBuy(PT_AUCTION_EQUIP equip) {
        this.equipBuyMap.put(equip.auid, equip);
    }

    public void buyEqu(long auid, int cnt) {
        PT_AUCTION_EQUIP pt_auction_equip = this.equipMapReg.get(auid);
        if (pt_auction_equip != null) {
            PT_AUCTION_EQUIP pT_AUCTION_EQUIP = pt_auction_equip;
            pT_AUCTION_EQUIP.count = pT_AUCTION_EQUIP.count - cnt;
            if (pt_auction_equip.tera == null)
                pt_auction_equip.tera = 0;
            pT_AUCTION_EQUIP = pt_auction_equip;
            pT_AUCTION_EQUIP.tera = pT_AUCTION_EQUIP.tera + cnt * pt_auction_equip.buyprice;
            pt_auction_equip.flag = pt_auction_equip.count == 0 ? 2 : 1;
        } else {
            log.error("UNREACH==AuctionBox.buyEqu: {}", auid);
        }
    }

    public void buyStackable(long auid, int cnt) {
        PT_AUCTION_STACKABLE pt_auction_stackable = this.stackableMapReg.get(auid);
        if (pt_auction_stackable != null) {
            PT_AUCTION_STACKABLE pT_AUCTION_STACKABLE = pt_auction_stackable;
            pT_AUCTION_STACKABLE.count = pT_AUCTION_STACKABLE.count - cnt;
            if (pt_auction_stackable.tera == null)
                pt_auction_stackable.tera = 0;
            pT_AUCTION_STACKABLE = pt_auction_stackable;
            pT_AUCTION_STACKABLE.tera = pT_AUCTION_STACKABLE.tera + cnt * pt_auction_stackable.buyprice;
            pt_auction_stackable.flag = pt_auction_stackable.count == 0 ? 2 : 1;
        } else {
            log.error("UNREACH==AuctionBox.buyStackable: {}", auid);
        }
    }

    public void addEquipBuy(int price, long enddate, int registcount, int buyprice, int index, int count) {
        PT_AUCTION_EQUIP equip = new PT_AUCTION_EQUIP();
        equip.type = 1;
        equip.price = price;
        equip.enddate = enddate;
        equip.registcount = registcount;
        equip.buyprice = buyprice;
        equip.index = index;
        equip.count = count;
        this.equipBuyMap.put(equip.auid, equip);
    }

    public void addStackableBuy(PT_AUCTION_STACKABLE stackable) {
        this.stackableBuyMap.put(stackable.auid, stackable);
    }

    public void addStackableBuy(int price, long enddate, int registcount, int buyprice, int index, int count) {
        PT_AUCTION_STACKABLE stackable = new PT_AUCTION_STACKABLE();
        stackable.auid = IdGenerator.getNextId();
        stackable.type = 1;
        stackable.price = price;
        stackable.enddate = enddate;
        stackable.registcount = registcount;
        stackable.buyprice = buyprice;
        stackable.index = index;
        stackable.count = count;
        this.stackableBuyMap.put(stackable.auid, stackable);
    }

    public void addEquipSell(PT_AUCTION_EQUIP equip) {
        this.equipSellMap.put(equip.auid, equip);
    }

    public void addStackableSell(PT_AUCTION_STACKABLE stackable) {
        this.stackableSellMap.put(stackable.auid, stackable);
    }

    public int removeReg(long auid) {
        if (this.equipMapReg.containsKey(auid)) {
            this.equipMapReg.get(auid).flag = -1;
            return 2;
        }
        this.stackableMapReg.get(auid).flag = -1;
        return 1;
    }

    public int completeReg(long auid) {
        if (this.equipMapReg.containsKey(auid)) {
            addEquipSell(this.equipMapReg.get(auid));
            this.equipMapReg.get(auid).flag = -1;
            return 2;
        }
        addStackableSell(this.stackableMapReg.get(auid));
        this.stackableMapReg.get(auid).flag = -1;
        return 1;
    }

    public List<PT_AUCTION_STACKABLE> getStackableBuyList() {
        return new ArrayList<>(this.stackableBuyMap.values());
    }

    public List<PT_AUCTION_EQUIP> getEquipBuyList() {
        return new ArrayList<>(this.equipBuyMap.values());
    }

    public List<PT_AUCTION_STACKABLE> getStackableSellList() {
        return new ArrayList<>(this.stackableSellMap.values());
    }

    public List<PT_AUCTION_EQUIP> getEquipSellList() {
        return new ArrayList<>(this.equipSellMap.values());
    }

    public PT_AUCTION_STACKABLE getStackableReg(long auid) {
        return this.stackableMapReg.get(auid);
    }

    public PT_AUCTION_EQUIP getEquipReg(long auid) {
        return this.equipMapReg.get(auid);
    }
}