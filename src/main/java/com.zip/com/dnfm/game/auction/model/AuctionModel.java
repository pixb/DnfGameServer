package com.dnfm.game.auction.model;

public class AuctionModel {
  public int category;
  
  public int index;
  
  public String name;
  
  public int intVal;
  
  public String rarity;
}