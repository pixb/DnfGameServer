package com.dnfm.game.auction.model;

import com.alibaba.fastjson.JSON;
import com.dnfm.common.utils.Util;
import com.dnfm.game.auction.model.AuctionBox;
import com.dnfm.game.item.ItemDataPool;
import com.dnfm.game.role.model.Account;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.utils.TimeUtil;
import com.dnfm.mina.cache.DataCache;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.protobuf.PT_AUCTION_EQUIP;
import com.dnfm.mina.protobuf.PT_AUCTION_ITEM_PRICE_INFO;
import com.dnfm.mina.protobuf.PT_AUCTION_STACKABLE;
import com.dnfm.mina.session.SessionManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListMap;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuctionCache {
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof com.dnfm.game.auction.model.AuctionCache))
            return false;
        com.dnfm.game.auction.model.AuctionCache other = (com.dnfm.game.auction.model.AuctionCache)o;
        return !!other.canEqual(this);
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.auction.model.AuctionCache;
    }

    public int hashCode() {
        return 1;
    }

    public String toString() {
        return "AuctionCache()";
    }

    private static final Logger log = LoggerFactory.getLogger(com.dnfm.game.auction.model.AuctionCache.class);

    public static Map<Integer, Integer> index2Category = new ConcurrentHashMap<>();

    public static Map<Integer, List<Integer>> priceMap = new ConcurrentHashMap<>();

    public static Map<Integer, Integer> avrPriceMap = new ConcurrentHashMap<>();

    public static Map<Integer, Map<Integer, Map<Long, PT_AUCTION_STACKABLE>>> indexStackableMap = new ConcurrentHashMap<>();

    public static Map<Integer, Map<Integer, Map<Long, PT_AUCTION_EQUIP>>> indexEquipMap = new ConcurrentHashMap<>();

    public static List<Integer> getPriceList(int index) {
        List<Integer> priceList = priceMap.get(Integer.valueOf(index));
        return priceList;
    }

    public static List<PT_AUCTION_ITEM_PRICE_INFO> GET_AUCTION_ITEM_PRICE_LIST(int index, int type) {
        List<PT_AUCTION_ITEM_PRICE_INFO> resList = new ArrayList<>();
        List<Integer> list = getPriceList(index);
        if (list == null)
            return null;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            int price = ((Integer)list.get(i)).intValue();
            PT_AUCTION_ITEM_PRICE_INFO info = new PT_AUCTION_ITEM_PRICE_INFO();
            info.price = Integer.valueOf(price);
            if (type == 1) {
                info.count = Integer.valueOf(getStackableItemCnt(index, price));
            } else {
                info.count = Integer.valueOf(getEquipItemCnt(index, price));
            }
            if (info.count.intValue() != 0)
                resList.add(info);
        }
        return resList;
    }

    public static void removeAuction(long auid, int index) {
        log.error("removeAuction==auid=={}==index=={}", Long.valueOf(auid), Integer.valueOf(index));
        int type = 1;
        if (ItemDataPool.consumeItemMap.get(Integer.valueOf(index)) == null)
            type = 2;
        if (type == 1) {
            Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map1 = indexStackableMap.get(Integer.valueOf(index));
            if (map1 != null)
                for (Map<Long, PT_AUCTION_STACKABLE> map2 : map1.values())
                    map2.remove(Long.valueOf(auid));
        } else {
            Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map1 = indexEquipMap.get(Integer.valueOf(index));
            if (map1 != null)
                for (Map<Long, PT_AUCTION_EQUIP> map2 : map1.values())
                    map2.remove(Long.valueOf(auid));
        }
    }

    public static void addAuctionStackable(PT_AUCTION_STACKABLE stackable) {
        if (indexStackableMap == null)
            indexStackableMap = new ConcurrentHashMap<>();
        Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map1 = indexStackableMap.get(stackable.index);
        if (map1 == null)
            map1 = new ConcurrentSkipListMap<>();
        Map<Long, PT_AUCTION_STACKABLE> auidMap = map1.get(stackable.price);
        if (auidMap == null)
            auidMap = new ConcurrentHashMap<>();
        auidMap.put(stackable.auid, stackable);
        map1.put(stackable.price, auidMap);
        indexStackableMap.put(stackable.index, map1);
    }

    public static void addAuctionEquip(PT_AUCTION_EQUIP equip) {
        if (indexEquipMap == null)
            indexEquipMap = new ConcurrentHashMap<>();
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map1 = indexEquipMap.get(equip.index);
        if (map1 == null)
            map1 = new ConcurrentSkipListMap<>();
        Map<Long, PT_AUCTION_EQUIP> auidMap = map1.get(equip.price);
        if (auidMap == null)
            auidMap = new ConcurrentHashMap<>();
        auidMap.put(equip.auid, equip);
        map1.put(equip.price, auidMap);
        indexEquipMap.put(equip.index, map1);
    }

    public static int getStackableCnt(int index) {
        Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map = indexStackableMap.get(Integer.valueOf(index));
        if (map == null)
            return 0;
        int cnt = 0;
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_STACKABLE>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            Map<Long, PT_AUCTION_STACKABLE> auidMap = entry.getValue();
            cnt += auidMap.size();
        }
        return cnt;
    }

    public static List<PT_AUCTION_STACKABLE> getStackableList(int index) {
        Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map = indexStackableMap.get(Integer.valueOf(index));
        if (map == null)
            return null;
        List<PT_AUCTION_STACKABLE> resList = new ArrayList<>();
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_STACKABLE>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            Map<Long, PT_AUCTION_STACKABLE> auidMap = entry.getValue();
            resList.addAll(auidMap.values());
        }
        return resList;
    }

    public static int getEquipCnt(int index) {
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null)
            return 0;
        int cnt = 0;
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_EQUIP>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            Map<Long, PT_AUCTION_EQUIP> auidMap = entry.getValue();
            cnt += auidMap.size();
        }
        return cnt;
    }

    public static int getStackableItemCnt(int index, int targetPrice) {
        Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map = indexStackableMap.get(Integer.valueOf(index));
        if (map == null)
            return 0;
        int cnt = 0;
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_STACKABLE>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            if (price == targetPrice) {
                Map<Long, PT_AUCTION_STACKABLE> auidMap = entry.getValue();
                for (PT_AUCTION_STACKABLE pas : auidMap.values())
                    cnt += pas.count.intValue();
            }
        }
        return cnt;
    }

    public static int getEquipItemCnt(int index, int targetPrice) {
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null)
            return 0;
        int cnt = 0;
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_EQUIP>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            if (price == targetPrice) {
                Map<Long, PT_AUCTION_EQUIP> auidMap = entry.getValue();
                for (PT_AUCTION_EQUIP pae : auidMap.values())
                    cnt += pae.count.intValue();
            }
        }
        return cnt;
    }

    public static List<PT_AUCTION_EQUIP> getEquipList(int index) {
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null)
            return null;
        List<PT_AUCTION_EQUIP> resList = new ArrayList<>();
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_EQUIP>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            Map<Long, PT_AUCTION_EQUIP> auidMap = entry.getValue();
            resList.addAll(auidMap.values());
        }
        return resList;
    }

    public static List<Integer> getPriceList(int index, int type) {
        if (type == 1) {
            Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map1 = indexStackableMap.get(Integer.valueOf(index));
            if (map1 == null)
                return getPriceList(null);
            List<Integer> list = new ArrayList<>();
            for (Map.Entry<Integer, Map<Long, PT_AUCTION_STACKABLE>> entry : map1.entrySet()) {
                int price = ((Integer)entry.getKey()).intValue();
                list.add(Integer.valueOf(price));
            }
            return getPriceList(list);
        }
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null)
            return getPriceList(null);
        List<Integer> priceList = new ArrayList<>();
        for (Map.Entry<Integer, Map<Long, PT_AUCTION_EQUIP>> entry : map.entrySet()) {
            int price = ((Integer)entry.getKey()).intValue();
            priceList.add(Integer.valueOf(price));
        }
        return getPriceList(priceList);
    }

    private static List<Integer> getPriceList(List<Integer> list) {
        if (Util.isEmpty(list)) {
            List<Integer> tmpList = new ArrayList<>();
            tmpList.add(Integer.valueOf(100));
            tmpList.add(Integer.valueOf(101));
            tmpList.add(Integer.valueOf(102));
            tmpList.add(Integer.valueOf(103));
            tmpList.add(Integer.valueOf(104));
            tmpList.add(Integer.valueOf(105));
            return tmpList;
        }
        List<Integer> resList = new ArrayList<>();
        if (list.size() <= 6) {
            int delta = 6 - list.size();
            for (int j = 0; j < delta; j++)
                list.add(Integer.valueOf(200 + j));
            return list;
        }
        if (list.size() <= 8)
            return list;
        int size = list.size();
        for (int i = 0; i < 8; i++)
            resList.add(list.get(i));
        return resList;
    }

    public static int getPriceListAllCnt(int index, int price, int type) {
        if (type == 1) {
            Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map1 = indexStackableMap.get(Integer.valueOf(index));
            if (map1 == null)
                return 0;
            int i = 0;
            Map<Long, PT_AUCTION_STACKABLE> map2 = map1.get(Integer.valueOf(price));
            for (Map.Entry<Long, PT_AUCTION_STACKABLE> entry : map2.entrySet())
                i += ((PT_AUCTION_STACKABLE)entry.getValue()).count.intValue();
            return i;
        }
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null)
            return 0;
        int cnt = 0;
        Map<Long, PT_AUCTION_EQUIP> auidMap = map.get(Integer.valueOf(price));
        for (Map.Entry<Long, PT_AUCTION_EQUIP> entry : auidMap.entrySet())
            cnt += ((PT_AUCTION_EQUIP)entry.getValue()).count.intValue();
        return cnt;
    }

    private static void updateRoleAuctionBox() {}

    public static int buyStackable(int index, int price, int cnt) {
        Map<Integer, Map<Long, PT_AUCTION_STACKABLE>> map = indexStackableMap.get(Integer.valueOf(index));
        if (map == null) {
            log.error("buyStackable error, map==null");
            return -1;
        }
        Map<Long, PT_AUCTION_STACKABLE> auidMap = map.get(Integer.valueOf(price));
        int totalCnt = 0;
        for (PT_AUCTION_STACKABLE pas : auidMap.values())
            totalCnt += pas.count.intValue();
        if (totalCnt < cnt) {
            log.error("buyStackable error, totalCnt: {}, cnt: {}", Integer.valueOf(totalCnt), Integer.valueOf(cnt));
            return -1;
        }
        int removeCnt = cnt;
        List<PT_AUCTION_STACKABLE> removeList = new ArrayList<>();
        for (Iterator<Map.Entry<Long, PT_AUCTION_STACKABLE>> it = auidMap.entrySet().iterator(); it.hasNext() &&
                removeCnt > 0; ) {
            Map.Entry<Long, PT_AUCTION_STACKABLE> entry = it.next();
            long auid = ((Long)entry.getKey()).longValue();
            log.error("AuctionCache.buyStackable==price=={}==auid=={}", Integer.valueOf(price), Long.valueOf(auid));
            PT_AUCTION_STACKABLE auction = entry.getValue();
            long now = TimeUtil.currS();
            if (auction.enddate != null && now >= auction.enddate.longValue())
                continue;
            if (removeCnt >= auction.count.intValue()) {
                long l = auction.charguid.longValue();
                IoSession ioSession = SessionManager.INSTANCE.getSessionBy(l);
                Role role1 = (Role)DataCache.AUCTION_ROLES.get(Long.valueOf(l));
                Account account1 = SessionUtils.getAccountBySession(ioSession);
                AuctionBox auctionBox1 = role1.getAuctionBox();
                auctionBox1.buyStackable(auid, auction.count.intValue());
                role1.save();
                account1.save();
                log.error("AuctionCache.remove-auction=={}", auction.auid);
                it.remove();
                removeCnt -= auction.count.intValue();
                continue;
            }
            long charguid = auction.charguid.longValue();
            IoSession session = SessionManager.INSTANCE.getSessionBy(charguid);
            Role role = (Role)DataCache.AUCTION_ROLES.get(Long.valueOf(charguid));
            Account account = SessionUtils.getAccountBySession(session);
            AuctionBox auctionBox = role.getAuctionBox();
            auctionBox.buyStackable(auid, removeCnt);
            long guid = 0L;
            if (auction.guid != null)
                guid = auction.guid.longValue();
            role.save();
            account.save();
            removeCnt = 0;
        }
        return 0;
    }

    public static int buyEquip(int index, int price, int cnt) {
        Map<Integer, Map<Long, PT_AUCTION_EQUIP>> map = indexEquipMap.get(Integer.valueOf(index));
        if (map == null) {
            log.error("buyEquip error==, map==null");
            return -1;
        }
        Map<Long, PT_AUCTION_EQUIP> auidMap = map.get(Integer.valueOf(price));
        int totalCnt = 0;
        for (PT_AUCTION_EQUIP pas : auidMap.values())
            totalCnt += pas.count.intValue();
        if (totalCnt < cnt) {
            log.error("buyEquip error==totalCnt: {}, cnt: {}", Integer.valueOf(totalCnt), Integer.valueOf(cnt));
            return -1;
        }
        int removeCnt = cnt;
        List<PT_AUCTION_EQUIP> removeList = new ArrayList<>();
        for (Iterator<Map.Entry<Long, PT_AUCTION_EQUIP>> it = auidMap.entrySet().iterator(); it.hasNext() &&
                removeCnt > 0; ) {
            Map.Entry<Long, PT_AUCTION_EQUIP> entry = it.next();
            long auid = ((Long)entry.getKey()).longValue();
            PT_AUCTION_EQUIP auction = entry.getValue();
            long now = TimeUtil.currS();
            if (auction.enddate != null && now >= auction.enddate.longValue())
                continue;
            if (removeCnt >= auction.count.intValue()) {
                long l = auction.charguid;
                IoSession ioSession = SessionManager.INSTANCE.getSessionBy(l);
                Role role1 = (Role)DataCache.AUCTION_ROLES.get(Long.valueOf(l));
                Account account1 = SessionUtils.getAccountBySession(ioSession);
                AuctionBox auctionBox1 = role1.getAuctionBox();
                auctionBox1.buyEqu(auid, auction.count.intValue());
                role1.save();
                account1.save();
                log.error("AuctionCache.remove-auction=={}", auction.auid);
                it.remove();
                removeCnt -= auction.count.intValue();
                continue;
            }
            long charguid = auction.charguid;
            IoSession session = SessionManager.INSTANCE.getSessionBy(charguid);
            Role role = (Role)DataCache.AUCTION_ROLES.get(Long.valueOf(charguid));
            Account account = SessionUtils.getAccountBySession(session);
            AuctionBox auctionBox = role.getAuctionBox();
            auctionBox.buyEqu(auid, removeCnt);
            role.save();
            account.save();
            removeCnt = 0;
        }
        return 0;
    }

    public static void main(String[] args) {
        Map<Integer, PT_AUCTION_EQUIP> map = new HashMap<>();
        PT_AUCTION_EQUIP p = new PT_AUCTION_EQUIP();
        p.count = Integer.valueOf(100);
        map.put(Integer.valueOf(1), p);
        System.out.println(JSON.toJSON(map));
        int removeCnt = 5;
        for (Iterator<Map.Entry<Integer, PT_AUCTION_EQUIP>> it = map.entrySet().iterator(); it.hasNext() &&
                removeCnt > 0; ) {
            Map.Entry<Integer, PT_AUCTION_EQUIP> entry = it.next();
            Integer key = entry.getKey();
            PT_AUCTION_EQUIP auction = entry.getValue();
            auction.count = Integer.valueOf(1);
            removeCnt--;
        }
        System.out.println(JSON.toJSON(map));
    }
}
