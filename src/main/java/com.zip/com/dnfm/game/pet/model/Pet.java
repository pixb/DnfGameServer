package com.dnfm.game.pet.model;

import com.dnfm.game.skill.model.SkillBox;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.nutz.dao.entity.annotation.Comment;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Pet {
    private int id;

    @Comment("宠物主人")
    private int hostId;

    @Comment("宠物主人名称")
    private String hostName;

    @Comment("宠物名称")
    private String name;

    @Comment("宠物昵称")
    private String nickname;

    @Comment("guid")
    private String gid;

    @Comment("宠物头像")
    private short icon;

    @Comment("宠物时装")
    private int special_icon;

    @Comment("宠物类型")
    private byte type;

    private byte position;

    @Comment("当前经验")
    private int exp;

    private int mapId;

    private SkillBox skillBox = new SkillBox();
}