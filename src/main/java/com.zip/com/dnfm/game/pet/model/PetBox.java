package com.dnfm.game.pet.model;

import com.dnfm.game.pet.model.Pet;
import com.dnfm.game.pet.model.PetStore;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PetBox implements Serializable {
    private int currentPetId;

    public void setCurrentPetId(int currentPetId) {
        this.currentPetId = currentPetId;
    }

    public void setPetStore(PetStore petStore) {
        this.petStore = petStore;
    }

    public void setAllPets(Map<Integer, Pet> allPets) {
        this.allPets = allPets;
    }

    public int getCurrentPetId() {
        return this.currentPetId;
    }

    private PetStore petStore = new PetStore();

    public PetStore getPetStore() {
        return this.petStore;
    }

    private Map<Integer, Pet> allPets = new HashMap<>();

    public Map<Integer, Pet> getAllPets() {
        return this.allPets;
    }

    public void addNewPet(Pet pet) {
        this.allPets.put(Integer.valueOf(pet.getId()), pet);
    }

    public void removePet(Pet pet) {
        this.allPets.remove(Integer.valueOf(pet.getId()));
    }

    public Set<Integer> allPets() {
        Set<Integer> set = new HashSet<>();
        return set;
    }

    public Pet getPetByPetId(int petId) {
        if (!allPets().contains(Integer.valueOf(petId)))
            return null;
        for (Map.Entry<Integer, Pet> entry : this.allPets.entrySet()) {
            Pet pet = entry.getValue();
            if (pet.getId() == petId)
                return pet;
        }
        return null;
    }

    public Pet getEquippedPetByPosition(byte pos) {
        Set<Integer> equipped = allPets();
        for (Map.Entry<Integer, Pet> entry : this.allPets.entrySet()) {
            Pet pet = entry.getValue();
            if (!equipped.contains(Integer.valueOf(pet.getId())))
                continue;
            if (pet.getPosition() == pos)
                return pet;
        }
        return null;
    }
}
