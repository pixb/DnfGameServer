/*     */
package com.dnfm.game.onlinemall;
/*     */ 
/*     */ 
/*     */ public class OnlineMallInfo
/*     */ {
/*     */   private String name;
/*     */   private String barcode;
/*     */   private short for_sale;
/*     */   private short show_pos;
/*     */   private short rpos;
/*     */   private short sale_quota;
/*     */   private short recommend;
/*     */   private int price;
/*     */   private byte discount;
/*     */   private int discountTime;
/*     */   private byte page;
/*     */   private short quota_limit;
/*  18 */   private byte must_vip = 0;
/*  19 */   private byte is_gift = -1;
/*  20 */   private byte follow_pet_type = -1;
/*     */   
/*     */   private int deadline;
/*     */   
/*     */   private int sale_end_time;
/*     */   
/*     */   public String getBarcode() {
/*  27 */     return this.barcode;
/*     */   }
/*     */   
/*     */   public void setBarcode(String barcode) {
/*  31 */     this.barcode = barcode;
/*     */   }
/*     */   
/*     */   public short getFor_sale() {
/*  35 */     return this.for_sale;
/*     */   }
/*     */   
/*     */   public void setFor_sale(short for_sale) {
/*  39 */     this.for_sale = for_sale;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  44 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  48 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShow_pos() {
/*  53 */     return this.show_pos;
/*     */   }
/*     */   
/*     */   public void setShow_pos(short show_pos) {
/*  57 */     this.show_pos = show_pos;
/*     */   }
/*     */   
/*     */   public short getRpos() {
/*  61 */     return this.rpos;
/*     */   }
/*     */   
/*     */   public void setRpos(short rpos) {
/*  65 */     this.rpos = rpos;
/*     */   }
/*     */   
/*     */   public short getSale_quota() {
/*  69 */     return this.sale_quota;
/*     */   }
/*     */   
/*     */   public void setSale_quota(short sale_quota) {
/*  73 */     this.sale_quota = sale_quota;
/*     */   }
/*     */   
/*     */   public short getRecommend() {
/*  77 */     return this.recommend;
/*     */   }
/*     */   
/*     */   public void setRecommend(short recommend) {
/*  81 */     this.recommend = recommend;
/*     */   }
/*     */   
/*     */   public int getPrice() {
/*  85 */     return this.price;
/*     */   }
/*     */   
/*     */   public void setPrice(int price) {
/*  89 */     this.price = price;
/*     */   }
/*     */   
/*     */   public byte getPage() {
/*  93 */     return this.page;
/*     */   }
/*     */   
/*     */   public void setPage(byte page) {
/*  97 */     this.page = page;
/*     */   }
/*     */   
/*     */   public byte getDiscount() {
/* 101 */     return this.discount;
/*     */   }
/*     */   
/*     */   public void setDiscount(byte discount) {
/* 105 */     this.discount = discount;
/*     */   }
/*     */   
/*     */   public int getDiscountTime() {
/* 109 */     return this.discountTime;
/*     */   }
/*     */   
/*     */   public void setDiscountTime(int discountTime) {
/* 113 */     this.discountTime = discountTime;
/*     */   }
/*     */   
/*     */   public short getQuota_limit() {
/* 117 */     return this.quota_limit;
/*     */   }
/*     */   
/*     */   public void setQuota_limit(short quota_limit) {
/* 121 */     this.quota_limit = quota_limit;
/*     */   }
/*     */   
/*     */   public byte getMust_vip() {
/* 125 */     return this.must_vip;
/*     */   }
/*     */   
/*     */   public void setMust_vip(byte must_vip) {
/* 129 */     this.must_vip = must_vip;
/*     */   }
/*     */   
/*     */   public byte getIs_gift() {
/* 133 */     return this.is_gift;
/*     */   }
/*     */   
/*     */   public void setIs_gift(byte is_gift) {
/* 137 */     this.is_gift = is_gift;
/*     */   }
/*     */   
/*     */   public byte getFollow_pet_type() {
/* 141 */     return this.follow_pet_type;
/*     */   }
/*     */   
/*     */   public void setFollow_pet_type(byte follow_pet_type) {
/* 145 */     this.follow_pet_type = follow_pet_type;
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\onlinemall\OnlineMallInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */