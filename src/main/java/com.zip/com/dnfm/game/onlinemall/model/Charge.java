/*    */
package com.dnfm.game.onlinemall.model;

/*    */
/*    */ import java.util.Date;
/*    */ import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Index;
/*    */ import org.nutz.dao.entity.annotation.Name;
/*    */ import org.nutz.dao.entity.annotation.Table;
/*    */ import org.nutz.dao.entity.annotation.TableIndexes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Table("t_charge")
/*    */ @TableIndexes({@Index(fields = {"userName"}, unique = false)})
/*    */ public class Charge
/*    */ {
/*    */   @Id
/*    */   private int id;
/*    */   @Name
/*    */   private String tradeNo;
/*    */   @Column
/*    */   private int gold;
/*    */   
/*    */   public String getTradeNo() {
/* 26 */     return this.tradeNo; } @Column
/*    */   private int rmb; @Column
/*    */   private Date time; @Column
/*    */   private String userName; @Column
/* 30 */   private int status; public void setTradeNo(String tradeNo) { this.tradeNo = tradeNo; }
/*    */ 
/*    */   
/*    */   public int getId() {
/* 34 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 38 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int getGold() {
/* 42 */     return this.gold;
/*    */   }
/*    */   
/*    */   public void setGold(int gold) {
/* 46 */     this.gold = gold;
/*    */   }
/*    */   
/*    */   public int getRmb() {
/* 50 */     return this.rmb;
/*    */   }
/*    */   
/*    */   public void setRmb(int rmb) {
/* 54 */     this.rmb = rmb;
/*    */   }
/*    */   
/*    */   public Date getTime() {
/* 58 */     return this.time;
/*    */   }
/*    */   
/*    */   public void setTime(Date time) {
/* 62 */     this.time = time;
/*    */   }
/*    */   
/*    */   public String getUserName() {
/* 66 */     return this.userName;
/*    */   }
/*    */   
/*    */   public void setUserName(String userName) {
/* 70 */     this.userName = userName;
/*    */   }
/*    */   
/*    */   public int getStatus() {
/* 74 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(int status) {
/* 78 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\onlinemall\model\Charge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */