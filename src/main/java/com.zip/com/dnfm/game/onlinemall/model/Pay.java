/*     */
package com.dnfm.game.onlinemall.model;

/*     */
/*     */ import java.util.Date;
/*     */ import org.nutz.dao.entity.annotation.Column;
/*     */ import org.nutz.dao.entity.annotation.Comment;
/*     */ import org.nutz.dao.entity.annotation.Id;
/*     */ import org.nutz.dao.entity.annotation.Table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Table("t_paydata")
/*     */ public class Pay
/*     */ {
/*     */   @Id
/*     */   private int id;
/*     */   @Column("userid")
/*     */   @Comment("用户ID")
/*     */   private String userid;
/*     */   @Column("orderid")
/*     */   @Comment("订单号")
/*     */   private String orderid;
/*     */   @Column("pkg")
/*     */   @Comment("包名")
/*     */   private String pkg;
/*     */   @Column("money")
/*     */   @Comment("金额")
/*     */   private String money;
/*     */   @Column("gamename")
/*     */   @Comment("游戏名称")
/*     */   private String gamename;
/*     */   @Column("createtime")
/*     */   @Comment("时间")
/*  37 */   private Date createtime = new Date();
/*     */ 
/*     */   
/*     */   @Column("app_channel")
/*     */   @Comment("游戏渠道码")
/*     */   private String app_channel;
/*     */ 
/*     */   
/*     */   @Column("userchannel")
/*     */   @Comment("用户渠道")
/*     */   private String userchannel;
/*     */   
/*     */   @Column("status")
/*     */   @Comment("支付状态")
/*     */   private String status;
/*     */ 
/*     */   
/*     */   public String getUserid() {
/*  55 */     return this.userid;
/*     */   }
/*     */   
/*     */   public void setUserid(String userid) {
/*  59 */     this.userid = userid;
/*     */   }
/*     */   
/*     */   public String getOrderid() {
/*  63 */     return this.orderid;
/*     */   }
/*     */   
/*     */   public void setOrderid(String orderid) {
/*  67 */     this.orderid = orderid;
/*     */   }
/*     */   
/*     */   public String getPkg() {
/*  71 */     return this.pkg;
/*     */   }
/*     */   
/*     */   public void setPkg(String pkg) {
/*  75 */     this.pkg = pkg;
/*     */   }
/*     */   
/*     */   public String getMoney() {
/*  79 */     return this.money;
/*     */   }
/*     */   
/*     */   public void setMoney(String money) {
/*  83 */     this.money = money;
/*     */   }
/*     */   
/*     */   public String getGamename() {
/*  87 */     return this.gamename;
/*     */   }
/*     */   
/*     */   public void setGamename(String gamename) {
/*  91 */     this.gamename = gamename;
/*     */   }
/*     */   
/*     */   public Date getCreatetime() {
/*  95 */     return this.createtime;
/*     */   }
/*     */   
/*     */   public void setCreatetime(Date createtime) {
/*  99 */     this.createtime = createtime;
/*     */   }
/*     */   
/*     */   public String getApp_channel() {
/* 103 */     return this.app_channel;
/*     */   }
/*     */   
/*     */   public void setApp_channel(String app_channel) {
/* 107 */     this.app_channel = app_channel;
/*     */   }
/*     */   
/*     */   public String getUserchannel() {
/* 111 */     return this.userchannel;
/*     */   }
/*     */   
/*     */   public void setUserchannel(String userchannel) {
/* 115 */     this.userchannel = userchannel;
/*     */   }
/*     */   
/*     */   public String getStatus() {
/* 119 */     return this.status;
/*     */   }
/*     */   
/*     */   public void setStatus(String status) {
/* 123 */     this.status = status;
/*     */   }
/*     */   
/*     */   public int getId() {
/* 127 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/* 131 */     this.id = id;
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\onlinemall\model\Pay.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */