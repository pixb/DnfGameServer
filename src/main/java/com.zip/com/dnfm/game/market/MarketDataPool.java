package com.dnfm.game.market;


import org.nutz.lang.util.NutMap;

public class MarketDataPool {
  public static NutMap marketDatas;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\market\MarketDataPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */