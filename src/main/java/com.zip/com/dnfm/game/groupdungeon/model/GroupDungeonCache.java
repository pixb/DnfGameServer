/*    */
package com.dnfm.game.groupdungeon.model;

/*    */
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ public class GroupDungeonCache
/*    */ {
/* 10 */   private static final Map<Long, List<Long>> ALL_UDP_ROOMS = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/* 13 */   private static final Map<Long, Integer> playerIdMap = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/* 16 */   public static final Map<Long, Long> matchingGuidMap = new ConcurrentHashMap<>();
/*    */   
/*    */   public static void addPlayerId(long charGuid, int playerId) {
/* 19 */     playerIdMap.put(Long.valueOf(charGuid), Integer.valueOf(playerId));
/*    */   }
/*    */   
/*    */   public static int getPlayerId(long charGuid) {
/* 23 */     return ((Integer)playerIdMap.get(Long.valueOf(charGuid))).intValue();
/*    */   }
/*    */   
/*    */   public static void createRoom(long roomId) {
/* 27 */     List<Long> charguidList = ALL_UDP_ROOMS.get(Long.valueOf(roomId));
/* 28 */     if (charguidList == null) {
/* 29 */       charguidList = new ArrayList<>();
/* 30 */       ALL_UDP_ROOMS.put(Long.valueOf(roomId), charguidList);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void removeRoom(long roomId) {
/* 38 */     ALL_UDP_ROOMS.remove(Long.valueOf(roomId));
/*    */   }
/*    */   
/*    */   public static void addPlayer(long roomId, long charguid) {
/* 42 */     List<Long> charguidList = ALL_UDP_ROOMS.get(Long.valueOf(roomId));
/* 43 */     if (charguidList == null) {
/* 44 */       charguidList = new ArrayList<>();
/*    */     }
/* 46 */     charguidList.add(Long.valueOf(charguid));
/* 47 */     ALL_UDP_ROOMS.put(Long.valueOf(roomId), charguidList);
/*    */   }
/*    */   
/*    */   public static void removePlayer(long roomId, long charguid) {
/* 51 */     List<Long> charguidList = ALL_UDP_ROOMS.get(Long.valueOf(roomId));
/* 52 */     if (charguidList == null) {
/*    */       return;
/*    */     }
/* 55 */     charguidList.remove(Long.valueOf(charguid));
/* 56 */     ALL_UDP_ROOMS.put(Long.valueOf(roomId), charguidList);
/*    */   }
/*    */   
/*    */   public static List<Long> getCharguidList(long roomId) {
/* 60 */     return ALL_UDP_ROOMS.get(Long.valueOf(roomId));
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\groupdungeon\model\GroupDungeonCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */