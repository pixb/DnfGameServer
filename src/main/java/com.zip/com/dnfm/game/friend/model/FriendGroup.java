/*    */
package com.dnfm.game.friend.model;
/*    */ 
/*    */ public class FriendGroup {
/*    */   private String number;
/*    */   private String groupName;
/*    */   
/*    */   public String getNumber() {
/*  8 */     return this.number;
/*    */   }
/*    */   
/*    */   public void setNumber(String number) {
/* 12 */     this.number = number;
/*    */   }
/*    */   
/*    */   public String getGroupName() {
/* 16 */     return this.groupName;
/*    */   }
/*    */   
/*    */   public void setGroupName(String groupName) {
/* 20 */     this.groupName = groupName;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\FriendGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */