/*    */
package com.dnfm.game.friend.model;

/*    */
/*    */ import org.nutz.dao.entity.annotation.ColDefine;
/*    */ import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Name;
/*    */ import org.nutz.dao.entity.annotation.Table;
/*    */ 
/*    */ @Table("t_offline")
/*    */ public class RoleOfflineData {
/*    */   @Name
/*    */   protected String type;
/*    */   
/* 13 */   public String getType() { return this.type; } @Column
/*    */   @ColDefine(customType = "longtext")
/*    */   private String data; public String getData() {
/* 16 */     return this.data;
/*    */   }
/*    */   
/*    */   public RoleOfflineData() {}
/*    */   
/*    */   public RoleOfflineData(String type, String data) {
/* 22 */     this.type = type;
/* 23 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\RoleOfflineData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */