/*    */
package com.dnfm.game.friend.model;
/*    */ 
/*    */ public class FriendRefuse {
/*    */   private byte count;
/*    */   private long refuseTime;
/*    */   
/*  7 */   public void setCount(byte count) { this.count = count; } public void setRefuseTime(long refuseTime) { this.refuseTime = refuseTime; }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte getCount() {
/* 12 */     return this.count; } public long getRefuseTime() {
/* 13 */     return this.refuseTime;
/*    */   }
/*    */   
/*    */   public FriendRefuse() {}
/*    */   
/*    */   public FriendRefuse(byte count, long refuseTime) {
/* 19 */     this.count = count;
/* 20 */     this.refuseTime = refuseTime;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\FriendRefuse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */