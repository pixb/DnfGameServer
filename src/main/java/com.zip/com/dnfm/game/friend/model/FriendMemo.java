/*    */
package com.dnfm.game.friend.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FriendMemo
/*    */ {
/*    */   private String gid;
/*    */   private String memo;
/*    */   
/*    */   public String getGid() {
/* 12 */     return this.gid;
/*    */   }
/*    */   
/*    */   public void setGid(String gid) {
/* 16 */     this.gid = gid;
/*    */   }
/*    */   
/*    */   public String getMemo() {
/* 20 */     return this.memo;
/*    */   }
/*    */   
/*    */   public void setMemo(String memo) {
/* 24 */     this.memo = memo;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\FriendMemo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */