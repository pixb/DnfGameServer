/*    */
package com.dnfm.game.friend.model;
/*    */ 
/*    */ public class FriendVerify {
/*    */   private long uid;
/*    */   private String name;
/*    */   
/*  7 */   public long getUid() { return this.uid; } public String getName() {
/*  8 */     return this.name;
/*    */   }
/*    */   
/*    */   public FriendVerify() {}
/*    */   
/*    */   public FriendVerify(long uid, String name) {
/* 14 */     this.uid = uid;
/* 15 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\FriendVerify.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */