/*     */
package com.dnfm.game.friend.service;

/*     */
/*     */ import com.dnfm.game.ServerService;
/*     */ import com.dnfm.game.equip.service.EquipService;
/*     */ import com.dnfm.game.map.service.MapService;
/*     */ import com.dnfm.game.player.PlayerService;
/*     */ import com.dnfm.game.role.model.Role;
/*     */ import com.dnfm.game.role.service.RoleService;
/*     */ import com.dnfm.game.utils.TimeUtil;
/*     */ import com.dnfm.listener.EventType;
/*     */ import com.dnfm.listener.annotation.EventHandler;
/*     */ import com.dnfm.listener.event.LoginEvent;
/*     */ import com.dnfm.listener.event.LogoutEvent;
/*     */ import com.dnfm.mina.protobuf.PT_FRIEND_INFO;
/*     */ import org.nutz.dao.Dao;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.stereotype.Service;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Service
/*     */ public class FriendService
/*     */ {
/*  26 */   Logger logger = LoggerFactory.getLogger(com.dnfm.game.friend.service.FriendService.class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   Dao dao;
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   MapService mapService;
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   RoleService roleService;
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   ServerService serverService;
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   EquipService equipService;
/*     */ 
/*     */ 
/*     */   
/*     */   @Autowired
/*     */   PlayerService playerService;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler({EventType.LOGOUT})
/*     */   public void handleLogoutEvent(LogoutEvent logoutEvent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler({EventType.LOGIN})
/*     */   public void handleLoginEvent(LoginEvent loginEvent) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendFriendInvite(Role role, Role targetRole) {
/*  72 */     for (PT_FRIEND_INFO send : role.getFriendBox().getSends()) {
/*  73 */       if (send.fguid.longValue() == targetRole.getUid()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/*  78 */     PT_FRIEND_INFO sendInfo = new PT_FRIEND_INFO();
/*  79 */     sendInfo.world = Integer.valueOf(1);
/*  80 */     sendInfo.fguid = Long.valueOf(targetRole.getUid());
/*  81 */     sendInfo.name = targetRole.getName();
/*  82 */     sendInfo.level = Integer.valueOf(targetRole.getLevel());
/*  83 */     sendInfo.job = Integer.valueOf(targetRole.getJob());
/*  84 */     sendInfo.growtype = Integer.valueOf(targetRole.getGrowtype());
/*  85 */     sendInfo.secondgrowtype = Integer.valueOf(targetRole.getSecgrowtype());
/*  86 */     sendInfo.date = Long.valueOf(TimeUtil.currS());
/*  87 */     sendInfo.online = Integer.valueOf(1);
/*  88 */     sendInfo.channel = Integer.valueOf(1);
/*  89 */     role.getFriendBox().addSendFriend(sendInfo);
/*     */ 
/*     */     
/*  92 */     PT_FRIEND_INFO receivedInfo = new PT_FRIEND_INFO();
/*  93 */     receivedInfo.world = Integer.valueOf(1);
/*  94 */     receivedInfo.fguid = Long.valueOf(role.getUid());
/*  95 */     receivedInfo.name = role.getName();
/*  96 */     receivedInfo.level = Integer.valueOf(role.getLevel());
/*  97 */     receivedInfo.job = Integer.valueOf(role.getJob());
/*  98 */     receivedInfo.growtype = Integer.valueOf(role.getGrowtype());
/*  99 */     receivedInfo.secondgrowtype = Integer.valueOf(role.getSecgrowtype());
/* 100 */     receivedInfo.date = Long.valueOf(TimeUtil.currS());
/* 101 */     receivedInfo.online = Integer.valueOf(1);
/* 102 */     sendInfo.channel = Integer.valueOf(1);
/* 103 */     targetRole.getFriendBox().addReceivedFriend(receivedInfo);
/*     */     
/* 105 */     if (this.roleService.isOnline(targetRole)) {
/*     */       
/* 107 */       this.logger.error("目标角色在线");
/*     */     }
/*     */     else {
/*     */       
/* 111 */       targetRole.save();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void operateFriendInvite(int type, Role role, Long fguid) {
/* 117 */     Role sendRole = this.roleService.getPlayerBy(fguid.longValue());
/* 118 */     PT_FRIEND_INFO sendInvite = sendRole.getFriendBox().getSendFriendByGid(role.getUid());
/* 119 */     PT_FRIEND_INFO receivedInvite = role.getFriendBox().getReceivedFriendByGid(fguid.longValue());
/* 120 */     if (type == 1) {
/* 121 */       sendInvite.status = Integer.valueOf(type);
/* 122 */       receivedInvite.status = Integer.valueOf(type);
/*     */     } else {
/* 124 */       PT_FRIEND_INFO info = new PT_FRIEND_INFO();
/* 125 */       info.world = Integer.valueOf(1);
/* 126 */       info.fguid = Long.valueOf(sendRole.getUid());
/* 127 */       info.name = sendRole.getName();
/* 128 */       info.level = Integer.valueOf(sendRole.getLevel());
/* 129 */       info.job = Integer.valueOf(sendRole.getJob());
/* 130 */       info.growtype = Integer.valueOf(sendRole.getGrowtype());
/* 131 */       info.secondgrowtype = Integer.valueOf(sendRole.getSecgrowtype());
/* 132 */       info.date = Long.valueOf(TimeUtil.currMs());
/* 133 */       info.online = Integer.valueOf(1);
/* 134 */       info.channel = Integer.valueOf(1);
/* 135 */       role.getFriendBox().addFriend(info);
/*     */       
/* 137 */       PT_FRIEND_INFO info2 = new PT_FRIEND_INFO();
/* 138 */       info2.world = Integer.valueOf(1);
/* 139 */       info2.fguid = Long.valueOf(role.getUid());
/* 140 */       info2.name = role.getName();
/* 141 */       info2.level = Integer.valueOf(role.getLevel());
/* 142 */       info2.job = Integer.valueOf(role.getJob());
/* 143 */       info2.growtype = Integer.valueOf(role.getGrowtype());
/* 144 */       info2.secondgrowtype = Integer.valueOf(role.getSecgrowtype());
/* 145 */       info2.date = Long.valueOf(TimeUtil.currMs());
/* 146 */       info2.online = Integer.valueOf(1);
/* 147 */       info2.channel = Integer.valueOf(1);
/* 148 */       sendRole.getFriendBox().addFriend(info2);
/*     */     } 
/* 150 */     sendRole.getFriendBox().removeSendFriend(sendInvite);
/* 151 */     role.getFriendBox().removeReceivedFriend(receivedInvite);
/* 152 */     if (!this.roleService.isOnline(sendRole)) {
/* 153 */       this.logger.error("目标角色离线");
/* 154 */       sendRole.save();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int deleteFriend(Role role, Long fguid) {
/* 159 */     PT_FRIEND_INFO info = role.getFriendBox().getFriendByGid(fguid.longValue());
/* 160 */     if (info != null) {
/* 161 */       role.getFriendBox().removeFriend(info);
/* 162 */       return 0;
/*     */     } 
/* 164 */     return 1;
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\service\FriendService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */