
/*    */
package com.dnfm.game.friend.model;
/*    */ 
/*    */ public class FriendInfo
/*    */ {
/*    */   private String numberName;
/*    */   private short status;
/*    */   private String lineName;
/*  8 */   private byte a = 0;
/*    */ 
/*    */   
/*    */   public String getNumberName() {
/* 12 */     return this.numberName;
/*    */   }
/*    */   
/*    */   public void setNumberName(String numberName) {
/* 16 */     this.numberName = numberName;
/*    */   }
/*    */   
/*    */   public short getStatus() {
/* 20 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(short status) {
/* 24 */     this.status = status;
/*    */   }
/*    */   
/*    */   public String getLineName() {
/* 28 */     return this.lineName;
/*    */   }
/*    */   
/*    */   public void setLineName(String lineName) {
/* 32 */     this.lineName = lineName;
/*    */   }
/*    */   
/*    */   public byte getA() {
/* 36 */     return this.a;
/*    */   }
/*    */   
/*    */   public void setA(byte a) {
/* 40 */     this.a = a;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\friend\model\FriendInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */