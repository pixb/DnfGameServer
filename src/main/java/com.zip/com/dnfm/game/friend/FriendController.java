package com.dnfm.game.friend;

import com.dnfm.game.friend.service.FriendService;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.RoleService;
import com.dnfm.mina.annotation.RequestMapping;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.Message;
import com.dnfm.mina.protobuf.REQ_DELETE_FRIEND;
import com.dnfm.mina.protobuf.REQ_FRIEND_FIND;
import com.dnfm.mina.protobuf.REQ_FRIEND_RECOMMEND;
import com.dnfm.mina.protobuf.REQ_FRIEND_RECOMMEND_WITH_ME;
import com.dnfm.mina.protobuf.REQ_REPLY_FRIEND_INVITE;
import com.dnfm.mina.protobuf.REQ_REQUEST_FRIEND_INVITE;
import com.dnfm.mina.protobuf.RES_DELETE_FRIEND;
import com.dnfm.mina.protobuf.RES_FRIEND_FIND;
import com.dnfm.mina.protobuf.RES_FRIEND_RECOMMEND;
import com.dnfm.mina.protobuf.RES_FRIEND_RECOMMEND_WITH_ME;
import com.dnfm.mina.protobuf.RES_REPLY_FRIEND_INVITE;
import com.dnfm.mina.protobuf.RES_REQUEST_FRIEND_INVITE;
import java.util.ArrayList;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class FriendController {
    Logger logger = LoggerFactory.getLogger(com.dnfm.game.friend.FriendController.class);

    @Autowired
    public RoleService roleService;

    @Autowired
    public FriendService friendService;

    @RequestMapping
    public void ReqFriendRecommendWithMe(IoSession session, REQ_FRIEND_RECOMMEND_WITH_ME reqFriendRecommendWithMe) {
        RES_FRIEND_RECOMMEND_WITH_ME resFriendRecommendWithMe = new RES_FRIEND_RECOMMEND_WITH_ME();
        resFriendRecommendWithMe.flist = new ArrayList();
        MessagePusher.pushMessage(session, (Message)resFriendRecommendWithMe);
    }

    @RequestMapping
    public void reqFriendRecommend(IoSession session, REQ_FRIEND_RECOMMEND reqFriendRecommend) {
        RES_FRIEND_RECOMMEND resFriendRecommend = new RES_FRIEND_RECOMMEND();
        resFriendRecommend.flist = new ArrayList();
        MessagePusher.pushMessage(session, (Message)resFriendRecommend);
    }

    @RequestMapping
    public void reqFriendFind(IoSession session, REQ_FRIEND_FIND reqFriendFind) {
        Role role = this.roleService.getPlayerBy(reqFriendFind.fname);
        RES_FRIEND_FIND resFriendFind = new RES_FRIEND_FIND();
        if (role != null) {
            resFriendFind.fguid = Long.valueOf(role.getUid());
            resFriendFind.name = role.getName();
            resFriendFind.level = Integer.valueOf(role.getLevel());
            resFriendFind.job = Integer.valueOf(role.getJob());
            resFriendFind.growtype = Integer.valueOf(role.getGrowtype());
            resFriendFind.secgrowtype = Integer.valueOf(role.getSecgrowtype());
            resFriendFind.creditscore = Integer.valueOf(role.getCerascore());
            resFriendFind.world = Integer.valueOf(1);
            resFriendFind.characterframe = Integer.valueOf(role.getCharacterframe());
        } else {
            resFriendFind.error = Integer.valueOf(1);
        }
        this.logger.error("reqFriendFind = {}", resFriendFind.toString());
        MessagePusher.pushMessage(session, (Message)resFriendFind);
    }

    @RequestMapping
    public void reqRequestFriendInvite(IoSession session, REQ_REQUEST_FRIEND_INVITE reqRequestFriendInvite) {
        RES_REQUEST_FRIEND_INVITE resRequestFriendInvite = new RES_REQUEST_FRIEND_INVITE();
        Role role = SessionUtils.getRoleBySession(session);
        Role targetRole = this.roleService.getPlayerBy(reqRequestFriendInvite.fguid.longValue());
        if (targetRole != null) {
            resRequestFriendInvite.fguid = Long.valueOf(role.getUid());
            resRequestFriendInvite.name = role.getName();
            resRequestFriendInvite.level = Integer.valueOf(role.getLevel());
            resRequestFriendInvite.job = Integer.valueOf(role.getJob());
            resRequestFriendInvite.growtype = Integer.valueOf(role.getGrowtype());
            resRequestFriendInvite.creditscore = Integer.valueOf(role.getCerascore());
            resRequestFriendInvite.world = Integer.valueOf(1);
            this.friendService.sendFriendInvite(role, targetRole);
        } else {
            resRequestFriendInvite.error = Integer.valueOf(1);
        }
        MessagePusher.pushMessage(session, (Message)resRequestFriendInvite);
    }

    @RequestMapping
    public void replyFriendInvite(IoSession session, REQ_REPLY_FRIEND_INVITE reqReplyFriendInvite) {
        Role role = SessionUtils.getRoleBySession(session);
        int type = 0;
        if (reqReplyFriendInvite.type != null)
            type = reqReplyFriendInvite.type.intValue();
        this.friendService.operateFriendInvite(type, role, reqReplyFriendInvite.fguid);
        RES_REPLY_FRIEND_INVITE resReplyFriendInvite = new RES_REPLY_FRIEND_INVITE();
        resReplyFriendInvite.world = Integer.valueOf(1);
        resReplyFriendInvite.fguid = reqReplyFriendInvite.fguid;
        resReplyFriendInvite.type = reqReplyFriendInvite.type;
        MessagePusher.pushMessage(session, (Message)resReplyFriendInvite);
    }

    @RequestMapping
    public void reqDeleteFriend(IoSession session, REQ_DELETE_FRIEND reqDeleteFriend) {
        Role role = SessionUtils.getRoleBySession(session);
        int result = this.friendService.deleteFriend(role, reqDeleteFriend.fguid);
        RES_DELETE_FRIEND resDeleteFriend = new RES_DELETE_FRIEND();
        resDeleteFriend.fguid = reqDeleteFriend.fguid;
        if (result != 0)
            resDeleteFriend.error = Integer.valueOf(result);
        MessagePusher.pushMessage(session, (Message)resDeleteFriend);
    }
}
