package com.dnfm.game.map.service;

import com.dnfm.game.ServerService;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.RoleService;
import com.dnfm.game.scene.SceneManager;
import org.nutz.dao.Dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 地图服务类。
 * 负责处理角色与地图相关的逻辑，例如进入城镇、离开城镇、移动以及获取附近角色。
 */
@Service
public class MapService {

    @Autowired
    private Dao dao;

    @Autowired
    private ServerService serverService;

    @Autowired
    private RoleService roleService;

    private final Logger logger = LoggerFactory.getLogger(MapService.class);

    /**
     * 让角色进入城镇。
     *
     * @param role 角色对象
     */
    public void enterTown(Role role) {
        int mapId = role.getPos().getTown() * 100 + role.getPos().getArea();
        SceneManager.INSTANCE.enterMap(mapId, role);
    }

    /**
     * 让角色离开城镇。
     *
     * @param role 角色对象
     */
    public void leaveTown(Role role) {
        int mapId = role.getPos().getTown() * 100 + role.getPos().getArea();
        SceneManager.INSTANCE.leaveMap(mapId, role);
    }

    /**
     * 让角色在地图上移动。
     *
     * @param role 角色对象
     */
    public void move(Role role) {
        int mapId = role.getPos().getTown() * 100 + role.getPos().getArea();
        SceneManager.INSTANCE.movePosition(mapId, role);
    }

    /**
     * 获取角色附近的其他角色列表。
     *
     * @param role 角色对象
     * @return 附近的角色列表
     */
    public List<Role> getNearbyRoles(Role role) {
        int mapId = role.getPos().getTown() * 100 + role.getPos().getArea();
        return SceneManager.INSTANCE.getNearbyRoles(mapId, role);
    }
}