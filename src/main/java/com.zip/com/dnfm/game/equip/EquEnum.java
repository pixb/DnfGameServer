package com.dnfm.game.equip;

public interface EquEnum {
  public static final int ENUM_EQUIPMENTTYPE_WEAPON = 11;
  
  public static final int ENUM_EQUIPMENTTYPE_JACKET = 13;
  
  public static final int ENUM_EQUIPMENTTYPE_SHOULDER = 14;
  
  public static final int ENUM_EQUIPMENTTYPE_PANTS = 15;
  
  public static final int ENUM_EQUIPMENTTYPE_SHOES = 16;
  
  public static final int ENUM_EQUIPMENTTYPE_WAIST = 17;
  
  public static final int ENUM_EQUIPMENTTYPE_AMULET = 18;
  
  public static final int ENUM_EQUIPMENTTYPE_WRIST = 19;
  
  public static final int ENUM_EQUIPMENTTYPE_RING = 20;
  
  public static final int RARITY_COMMON = 0;
  
  public static final int RARITY_UNCOMMON = 1;
  
  public static final int RARITY_RARE = 2;
  
  public static final int RARITY_UNIQUE = 3;
  
  public static final int RARITY_EPIC = 4;
  
  public static final int RARITY_CHRONICLE = 5;
  
  public static final int RARITY_LEGENDARY = 6;
  
  public static final double GOLD_RATIO = 0.5D;
  
  public static final double MATERIAL_RATIO = 0.5D;
  
  public static final double ADV_MATERIAL_RATIO = 0.5D;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\EquEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */