/*    */
package com.dnfm.game.equip;

/*    */
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Const {
/*  7 */   public static final Map<Integer, Integer> SWORDMAN = new HashMap<>();
/*    */ 
/*    */   
/*    */   static {
/* 11 */     SWORDMAN.put(Integer.valueOf(1), Integer.valueOf(2001030027));
/* 12 */     SWORDMAN.put(Integer.valueOf(2), Integer.valueOf(2000060036));
/* 13 */     SWORDMAN.put(Integer.valueOf(3), Integer.valueOf(2000110036));
/* 14 */     SWORDMAN.put(Integer.valueOf(4), Integer.valueOf(2000160031));
/* 15 */     SWORDMAN.put(Integer.valueOf(5), Integer.valueOf(2000210037));
/* 16 */     SWORDMAN.put(Integer.valueOf(6), Integer.valueOf(2000260031));
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\Const.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */