package com.dnfm.game.equip;

public interface EquipType {
  public static final int WEAPON = 1;
  
  public static final int COAT = 2;
  
  public static final int PANTS = 3;
  
  public static final int SHOULDER = 4;
  
  public static final int WAIST = 5;
  
  public static final int SHOES = 6;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\EquipType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */