/*    */
package com.dnfm.game.equip.model;

/*    */
/*    */ import com.dnfm.game.equip.model.Leiji;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class LeijiData {
/*  7 */   private HashMap<Integer, Leiji> data = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HashMap<Integer, Leiji> getData() {
/* 13 */     return this.data;
/*    */   }
/*    */   
/*    */   public void setData(HashMap<Integer, Leiji> data) {
/* 17 */     this.data = data;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\model\LeijiData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */