/*    */
package com.dnfm.game.equip.model;

/*    */
/*    */ import com.dnfm.game.equip.model.RoleData;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ChargeData {
/*    */   long time;
/*    */   
/*    */   public long getTime() {
/* 10 */     return this.time;
/*    */   }
/*    */   HashMap<Long, RoleData> hashMap;
/*    */   public void setTime(long time) {
/* 14 */     this.time = time;
/*    */   }
/*    */   
/*    */   public HashMap<Long, RoleData> getHashMap() {
/* 18 */     return this.hashMap;
/*    */   }
/*    */   
/*    */   public void setHashMap(HashMap<Long, RoleData> hashMap) {
/* 22 */     this.hashMap = hashMap;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\model\ChargeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */