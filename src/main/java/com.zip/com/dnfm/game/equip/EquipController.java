package com.dnfm.game.equip;

import cn.hutool.core.util.RandomUtil;
import com.dnfm.common.utils.Util;
import com.dnfm.game.bag.model.EmblemBox;
import com.dnfm.game.bag.model.EquippedBox;
import com.dnfm.game.config.Equip;
import com.dnfm.game.equip.EquipDataPool;
import com.dnfm.game.equip.model.UpgradeInfo;
import com.dnfm.game.equip.service.EquipService;
import com.dnfm.game.item.ItemDataPool;
import com.dnfm.game.make.MakeController;
import com.dnfm.game.role.model.Role;
import com.dnfm.mina.annotation.RequestMapping;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.Message;
import com.dnfm.mina.protobuf.PT_ARTIFACT;
import com.dnfm.mina.protobuf.PT_AVATAR_ITEM;
import com.dnfm.mina.protobuf.PT_CARD_ATTACH;
import com.dnfm.mina.protobuf.PT_CONTENTS_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_CREATURE;
import com.dnfm.mina.protobuf.PT_CURRENCY_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_EMBLEM;
import com.dnfm.mina.protobuf.PT_EMBLEM_RESULT;
import com.dnfm.mina.protobuf.PT_EQUIP;
import com.dnfm.mina.protobuf.PT_EQUIPPED;
import com.dnfm.mina.protobuf.PT_EQUIP_PUT_ON_OFF;
import com.dnfm.mina.protobuf.PT_ITEMS;
import com.dnfm.mina.protobuf.PT_ITEM_REWARD_INFO;
import com.dnfm.mina.protobuf.PT_MONEY_ITEM;
import com.dnfm.mina.protobuf.PT_RANDOMOPTION_ITEM;
import com.dnfm.mina.protobuf.PT_REMOVEITEMS;
import com.dnfm.mina.protobuf.PT_SKIN_ITEM;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import com.dnfm.mina.protobuf.REQ_AVATAR_VISIBLE_FLAGS_SET;
import com.dnfm.mina.protobuf.REQ_CARD_ATTACH;
import com.dnfm.mina.protobuf.REQ_EMBLEM_EQUIP;
import com.dnfm.mina.protobuf.REQ_EQUIPMENT_RARIFY;
import com.dnfm.mina.protobuf.REQ_EQUIPPED_LIST;
import com.dnfm.mina.protobuf.REQ_EQUIP_PUT_ON_OFF;
import com.dnfm.mina.protobuf.REQ_ITEM_EMBLEM_EXTRACT;
import com.dnfm.mina.protobuf.REQ_ITEM_REINFORCE;
import com.dnfm.mina.protobuf.REQ_RANDOMOPTION_CHANGE;
import com.dnfm.mina.protobuf.REQ_RANDOMOPTION_SELECT;
import com.dnfm.mina.protobuf.REQ_RANDOMOPTION_SLOT_LOCK;
import com.dnfm.mina.protobuf.REQ_RANDOMOPTION_UNLOCK;
import com.dnfm.mina.protobuf.REQ_TRANSMISSION_ITEM;
import com.dnfm.mina.protobuf.RES_AVATAR_VISIBLE_FLAGS_SET;
import com.dnfm.mina.protobuf.RES_CARD_ATTACH;
import com.dnfm.mina.protobuf.RES_EMBLEM_EQUIP;
import com.dnfm.mina.protobuf.RES_EMBLEM_EXTRACT;
import com.dnfm.mina.protobuf.RES_EQUIPMENT_RARIFY;
import com.dnfm.mina.protobuf.RES_EQUIPPED_LIST;
import com.dnfm.mina.protobuf.RES_EQUIP_PUT_ON_OFF;
import com.dnfm.mina.protobuf.RES_ITEM_REINFORCE;
import com.dnfm.mina.protobuf.RES_RANDOMOPTION_CHANGE;
import com.dnfm.mina.protobuf.RES_RANDOMOPTION_SELECT;
import com.dnfm.mina.protobuf.RES_RANDOMOPTION_SLOT_LOCK;
import com.dnfm.mina.protobuf.RES_RANDOMOPTION_UNLOCK;
import com.dnfm.mina.protobuf.RES_TRANSMISSION_ITEM;
import com.dnfm.mina.protobuf.UPDATE_ANTIEVIL_SCORE;
import com.dnfm.mina.protobuf.UPDATE_ANTIEVIL_SCORE1;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class EquipController {
    @Autowired
    EquipService equipService;

    Logger logger = LoggerFactory.getLogger(MakeController.class);

    @RequestMapping
    public void REQ_EQUIP_PUT_ON_OFF(IoSession session, REQ_EQUIP_PUT_ON_OFF req_equip_put_on_off) {
        List<PT_EQUIP_PUT_ON_OFF> reqequip = req_equip_put_on_off.equip;
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIP ptequip = new PT_EQUIP();
        PT_EQUIPPED ptEquipped = new PT_EQUIPPED();
        PT_AVATAR_ITEM ptAvatarItem = new PT_AVATAR_ITEM();
        RES_EQUIP_PUT_ON_OFF res_equip_put_on_off = new RES_EQUIP_PUT_ON_OFF();
        int equipscore = role.getEquipscore();
        UPDATE_ANTIEVIL_SCORE update_antievil_score = new UPDATE_ANTIEVIL_SCORE();
        for (PT_EQUIP_PUT_ON_OFF equip : reqequip) {
            if (equip.slot == null)
                equip.slot = Integer.valueOf(0);
            if (equip.guid != null) {
                if (equip.slot.intValue() == 0 || equip.slot.intValue() == 1 || equip.slot.intValue() == 2 || equip.slot.intValue() == 3 || equip.slot.intValue() == 4 || equip.slot.intValue() == 5 || equip.slot.intValue() == 6 || equip.slot.intValue() == 7 || equip.slot.intValue() == 8 || equip.slot.intValue() == 9 || equip.slot.intValue() == 10) {
                    ptAvatarItem = role.getAvatarBox().getAvatar(equip.guid.longValue());
                    equipscore += ptAvatarItem.score;
                    PT_AVATAR_ITEM pt_avatar_item = role.getEquippedBox().getAvatarBySlot(equip.slot.intValue());
                    ptAvatarItem.setSlot(equip.slot.intValue());
                    role.getAvatarBox().remove(ptAvatarItem.guid.longValue());
                    role.getEquippedBox().addAvatar(ptAvatarItem);
                    if (pt_avatar_item != null) {
                        role.getAvatarBox().addAvatar(pt_avatar_item);
                        equipscore -= pt_avatar_item.score;
                        role.getEquippedBox().removeAvatar(pt_avatar_item);
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptAvatarItem.score + pt_avatar_item.score);
                    } else {
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptAvatarItem.score);
                    }
                    res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                    update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
                    continue;
                }
                if (equip.slot.intValue() == 2000 || equip.slot.intValue() == 2001 || equip.slot.intValue() == 2002 || equip.slot.intValue() == 2003 || equip.slot.intValue() == 2004 || equip.slot.intValue() == 2005 || equip.slot.intValue() == 2006 || equip.slot.intValue() == 2007 || equip.slot.intValue() == 2008 || equip.slot.intValue() == 2009 || equip.slot.intValue() == 2010) {
                    ptAvatarItem = role.getAvatarBox().getAvatar(equip.guid.longValue());
                    equipscore += ptAvatarItem.score;
                    PT_AVATAR_ITEM pt_avatar_item = role.getEquippedBox().getAvatarSkinBySlot(equip.slot.intValue());
                    ptAvatarItem.setSlot(equip.slot.intValue());
                    role.getEquippedBox().addAvatarskin(ptAvatarItem);
                    role.getAvatarBox().remove(ptAvatarItem.guid.longValue());
                    if (pt_avatar_item != null) {
                        role.getAvatarBox().addAvatar(pt_avatar_item);
                        equipscore -= pt_avatar_item.score;
                        role.getEquippedBox().removeAvatarskin(pt_avatar_item.guid.longValue());
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptAvatarItem.score + pt_avatar_item.score);
                    } else {
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptAvatarItem.score);
                    }
                    res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                    update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
                    continue;
                }
                if (equip.slot.intValue() == 12) {
                    ptEquipped = role.getEquippedBox().getEquippedBySlot(equip.slot.intValue());
                    PT_EQUIP ptequip1 = role.getTitleBox().getTitle(equip.guid.longValue());
                    ptequip1.setSlot(equip.slot);
                    role.getTitleBox().removeTitle(ptequip1.guid.longValue());
                    PT_EQUIPPED ptEquipped1 = EquipDataPool.changeEquipped(ptequip1);
                    role.getEquippedBox().addEquip(ptEquipped1);
                    equipscore += ptEquipped1.score;
                    if (ptEquipped != null) {
                        ptequip = role.getTitleBox().changeTitle(ptEquipped);
                        role.getTitleBox().addTitle(ptequip);
                        equipscore -= ptequip.score;
                        role.getEquippedBox().removeEquip(ptEquipped);
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptEquipped1.score + ptequip.score);
                    } else {
                        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() - ptAvatarItem.score);
                    }
                    res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                    update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
                    continue;
                }
                if (equip.slot.intValue() == 11 || equip.slot.intValue() == 13 || equip.slot.intValue() == 14 || equip.slot.intValue() == 15 || equip.slot.intValue() == 16 || equip.slot.intValue() == 17 || equip.slot.intValue() == 18 || equip.slot.intValue() == 19 || equip.slot.intValue() == 20) {
                    ptEquipped = role.getEquippedBox().getEquippedBySlot(equip.slot.intValue());
                    PT_EQUIP ptequip1 = role.getEquipBox().getEquip(equip.guid.longValue());
                    ptequip1.setSlot(equip.slot);
                    PT_EQUIPPED ptEquipped1 = EquipDataPool.changeEquipped(ptequip1);
                    role.getEquippedBox().addEquip(ptEquipped1);
                    role.getEquipBox().removeEquip(equip.guid.longValue());
                    if (ptEquipped != null) {
                        ptequip = EquipDataPool.changeEquip(ptEquipped);
                        role.getEquipBox().addEquip(ptequip);
                        role.getEquippedBox().removeEquip(ptEquipped);
                    }
                }
                continue;
            }
            if (equip.slot.intValue() == 12) {
                ptEquipped = role.getEquippedBox().getEquippedBySlot(equip.slot.intValue());
                ptequip = role.getTitleBox().changeTitle(ptEquipped);
                role.getTitleBox().addTitle(ptequip);
                role.getEquippedBox().removeEquip(ptEquipped);
                equipscore -= ptequip.score;
                res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() + ptequip.score);
                update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
                continue;
            }
            if (equip.slot.intValue() == 11 || equip.slot.intValue() == 13 || equip.slot.intValue() == 14 || equip.slot.intValue() == 15 || equip.slot.intValue() == 16 || equip.slot.intValue() == 17 || equip.slot.intValue() == 18 || equip.slot.intValue() == 19 || equip.slot.intValue() == 20) {
                ptEquipped = role.getEquippedBox().getEquippedBySlot(equip.slot.intValue());
                ptequip = EquipDataPool.changeEquip(ptEquipped);
                role.getEquipBox().addEquip(ptequip);
                role.getEquippedBox().removeEquip(ptEquipped);
                continue;
            }
            if (equip.slot.intValue() == 0 || equip.slot.intValue() == 1 || equip.slot.intValue() == 2 || equip.slot.intValue() == 3 || equip.slot.intValue() == 4 || equip.slot.intValue() == 5 || equip.slot.intValue() == 6 || equip.slot.intValue() == 7 || equip.slot.intValue() == 8 || equip.slot.intValue() == 9 || equip.slot.intValue() == 10) {
                ptAvatarItem = role.getEquippedBox().getAvatarBySlot(equip.slot.intValue());
                ptAvatarItem.setSlot(666);
                role.getAvatarBox().addAvatar(ptAvatarItem);
                role.getEquippedBox().removeAvatar(ptAvatarItem.guid.longValue());
                equipscore -= ptAvatarItem.score;
                update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() + ptAvatarItem.score);
                res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
                continue;
            }
            if (equip.slot.intValue() == 2000 || equip.slot.intValue() == 2001 || equip.slot.intValue() == 2002 || equip.slot.intValue() == 2003 || equip.slot.intValue() == 2004 || equip.slot.intValue() == 2005 || equip.slot.intValue() == 2006 || equip.slot.intValue() == 2007 || equip.slot.intValue() == 2008 || equip.slot.intValue() == 2009 || equip.slot.intValue() == 2010) {
                ptAvatarItem = role.getEquippedBox().getAvatarSkinBySlot(equip.slot.intValue());
                ptAvatarItem.setSlot(666);
                role.getAvatarBox().addAvatar(ptAvatarItem);
                role.getEquippedBox().removeAvatarskin(ptAvatarItem.guid.longValue());
                equipscore -= ptAvatarItem.score;
                res_equip_put_on_off.equipscore = Integer.valueOf(role.getEquipscore());
                update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore() + ptAvatarItem.score);
                update_antievil_score.afterscore = Integer.valueOf(role.getEquipscore());
            }
        }
        role.setEquipscore(equipscore);
        res_equip_put_on_off.equip = reqequip;
        res_equip_put_on_off.transId = req_equip_put_on_off.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)res_equip_put_on_off);
    }

    @RequestMapping
    public void UPDATE_ANTIEVIL_SCORE1(IoSession session, UPDATE_ANTIEVIL_SCORE1 updateAntievilScore) {
        UPDATE_ANTIEVIL_SCORE update_antievil_score = new UPDATE_ANTIEVIL_SCORE();
        Role role = SessionUtils.getRoleBySession(session);
        update_antievil_score.prevscore = Integer.valueOf(role.getEquipscore());
        if (updateAntievilScore.afterscore != null)
            role.setEquipscore(updateAntievilScore.afterscore.intValue());
        update_antievil_score.afterscore = updateAntievilScore.afterscore;
        update_antievil_score.transId = updateAntievilScore.transId;
        MessagePusher.pushMessage(session, (Message)update_antievil_score);
    }

    @RequestMapping
    public void ReqEquippedList(IoSession session, REQ_EQUIPPED_LIST reqEquippedList) {
        Role role = SessionUtils.getRoleBySession(session);
        EquippedBox equippedBox = role.getEquippedBox();
        List<PT_EQUIPPED> equiplist = equippedBox.getEquiplist();
        List<PT_CREATURE> creaturelist = equippedBox.getCreaturelist();
        List<PT_AVATAR_ITEM> avatarlist = equippedBox.getAvatarlist();
        List<PT_ARTIFACT> cartifactlist = equippedBox.getCartifactlist();
        List<PT_EQUIPPED> equipskinlist = equippedBox.getEquipskinlist();
        List<PT_AVATAR_ITEM> avatarskinlist = equippedBox.getAvatarskinlist();
        List<PT_SKIN_ITEM> skinlist = equippedBox.getSkinlist();
        List<PT_AVATAR_ITEM> sdavatarlist = equippedBox.getSdavatarlist();
        RES_EQUIPPED_LIST res_equipped_list = new RES_EQUIPPED_LIST();
        if (equiplist != null)
            res_equipped_list.equiplist = equiplist;
        if (creaturelist != null)
            res_equipped_list.creaturelist = creaturelist;
        if (avatarlist != null)
            res_equipped_list.avatarlist = avatarlist;
        if (cartifactlist != null)
            res_equipped_list.cartifactlist = cartifactlist;
        if (equipskinlist != null)
            res_equipped_list.equipskinlist = equipskinlist;
        if (avatarskinlist != null)
            res_equipped_list.avatarskinlist = avatarskinlist;
        if (skinlist != null)
            res_equipped_list.skinlist = skinlist;
        if (sdavatarlist != null)
            res_equipped_list.sdavatarlist = sdavatarlist;
        res_equipped_list.transId = reqEquippedList.transId;
        MessagePusher.pushMessage(session, (Message)res_equipped_list);
    }

    @RequestMapping
    public void REQ_ITEM_REINFORCE(IoSession session, REQ_ITEM_REINFORCE reqItemReinforce) {
        Equip equipinfo;
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED equipped = role.getEquippedBox().getEquipped(reqItemReinforce.guid.longValue());
        int upgrade = 0;
        PT_EQUIP ptEquip = new PT_EQUIP();
        int updatepoint = 0;
        if (equipped != null) {
            upgrade = equipped.upgrade.intValue();
            equipinfo = EquipDataPool.getEquip(equipped.index.intValue());
            updatepoint = equipped.upgradepoint.intValue();
        } else {
            ptEquip = role.getEquipBox().getEquip(reqItemReinforce.guid.longValue());
            upgrade = ptEquip.upgrade.intValue();
            equipinfo = EquipDataPool.getEquip(ptEquip.index.intValue());
            updatepoint = ptEquip.upgradepoint.intValue();
        }
        int equiptype = equipinfo.getEquiptype();
        int rarity = equipinfo.getRarity();
        int level = equipinfo.getMinlevel();
        Random random = new Random();
        UpgradeInfo upgradeInfo = EquipDataPool.getUpgradeInfo(upgrade, equiptype, level, rarity);
        int needGold = upgradeInfo.needGold;
        int needMaterial = upgradeInfo.needMaterial;
        int needAdvMaterial = upgradeInfo.needAdvMaterial;
        int pointMax = upgradeInfo.pointMax;
        double sucrandom = random.nextInt(10000) * 0.01D;
        Boolean isSuccess = Boolean.valueOf(false);
        double rate = 0.0D;
        double luckyrate = 1.0D;
        int talisman = 0;
        RES_ITEM_REINFORCE res_item_reinforce = new RES_ITEM_REINFORCE();
        PT_REMOVEITEMS removeitems = new PT_REMOVEITEMS();
        List<PT_STACKABLE> materialitems = new ArrayList<>();
        if (reqItemReinforce.talisman != null) {
            talisman = reqItemReinforce.talisman.intValue();
            if (equipinfo.getMinlevel() == 55) {
                if (upgrade == 10 || upgrade == 11 || upgrade == 12 || upgrade == 13 || upgrade == 14 || upgrade == 15 || upgrade == 16) {
                    talisman = 2;
                } else if (upgrade == 17) {
                    talisman = 3;
                } else if (upgrade == 18) {
                    talisman = 4;
                } else if (upgrade == 19) {
                    talisman = 5;
                }
            } else if (upgrade == 10 || upgrade == 11 || upgrade == 12 || upgrade == 13 || upgrade == 14 || upgrade == 15 || upgrade == 16) {
                talisman = 1;
            } else if (upgrade == 17) {
                talisman = 2;
            } else if (upgrade == 18) {
                talisman = 3;
            } else if (upgrade == 19) {
                talisman = 4;
            }
            PT_STACKABLE ptStackable = role.getMaterialBox().getMaterial(2013104426);
            PT_STACKABLE ptStackable1 = role.getMaterialBox().getMaterial(2013000026);
            luckyrate = 3.0D;
            if (ptStackable != null)
                if (ptStackable.count.intValue() >= talisman) {
                    ptStackable.count = Integer.valueOf(ptStackable.count.intValue() - talisman);
                    materialitems.add(ptStackable);
                    materialitems.add(ItemDataPool.setMaterial(2013104426, 0, true));
                } else {
                    talisman -= ptStackable.count.intValue();
                    ptStackable.count = Integer.valueOf(0);
                    materialitems.add(ptStackable);
                    ptStackable1.count = Integer.valueOf(ptStackable1.count.intValue() - talisman);
                    materialitems.add(ptStackable1);
                    role.getMaterialBox().removeMaterial(ptStackable.index.intValue());
                    materialitems.add(ItemDataPool.setMaterial(2013000026, 0, true));
                }
        }
        if (0 <= upgrade && upgrade < 4) {
            isSuccess = Boolean.valueOf(true);
        } else if (4 <= upgrade && upgrade < 6) {
            rate = 0.7D;
            if (sucrandom > 30.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (70.0D + sucrandom) * rate;
            }
        } else if (6 <= upgrade && upgrade < 8) {
            rate = 0.6D;
            if (sucrandom > 65.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (60.0D + sucrandom) * rate;
            }
        } else if (8 <= upgrade && upgrade < 9) {
            rate = 0.4D;
            if (sucrandom > 70.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (40.0D + sucrandom) * rate;
            }
        } else if (9 <= upgrade && upgrade < 10) {
            rate = 0.2D;
            if (sucrandom > 83.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (40.0D + sucrandom) * rate;
            }
        } else if (10 <= upgrade && upgrade < 11) {
            rate = 0.15D;
            if (sucrandom > 88.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (11 <= upgrade && upgrade < 12) {
            rate = 0.1D;
            if (sucrandom > 92.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (12 <= upgrade && upgrade < 13) {
            rate = 0.07D;
            if (sucrandom > 94.5D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 13) {
            rate = 0.05D;
            if (sucrandom > 96.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 14) {
            rate = 0.03D;
            if (sucrandom > 98.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 15) {
            rate = 0.02D;
            if (sucrandom > 98.5D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 16) {
            rate = 0.01D;
            if (sucrandom > 99.0D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 17) {
            rate = 0.01D;
            if (sucrandom > 99.2D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 18) {
            rate = 0.01D;
            if (sucrandom > 99.5D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        } else if (upgrade == 19) {
            rate = 0.01D;
            if (sucrandom > 99.8D) {
                isSuccess = Boolean.valueOf(true);
            } else {
                isSuccess = Boolean.valueOf(false);
                sucrandom = (50.0D + sucrandom / 2.0D) * rate;
            }
        }
        if (isSuccess.booleanValue()) {
            updatepoint = 0;
            upgrade++;
            res_item_reinforce.success = Boolean.valueOf(true);
        } else {
            updatepoint += (int)((pointMax / 2) * sucrandom / 100.0D * luckyrate * 0.9D);
            if (updatepoint >= pointMax) {
                res_item_reinforce.success = Boolean.valueOf(true);
                updatepoint -= pointMax;
                upgrade++;
            } else {
                res_item_reinforce.success = Boolean.valueOf(false);
            }
        }
        if (equipped != null) {
            equipped.upgrade = Integer.valueOf(upgrade);
            equipped.upgradepoint = Integer.valueOf(updatepoint);
            role.getEquippedBox().updateEquip(equipped);
        } else {
            ptEquip.upgrade = Integer.valueOf(upgrade);
            ptEquip.upgradepoint = Integer.valueOf(updatepoint);
            role.getEquipBox().addEquip(ptEquip);
        }
        if (upgrade > 14) {
            materialitems.add(ItemDataPool.setMaterial(2013106036, 0, true));
            materialitems.add(ItemDataPool.setMaterial(2013106035, 0, false));
            PT_STACKABLE cola = (PT_STACKABLE)role.getMaterialBox().getMaterialsMap().get(Integer.valueOf(2013106035));
            PT_STACKABLE cola1 = (PT_STACKABLE)role.getMaterialBox().getMaterialsMap().get(Integer.valueOf(2013106036));
            if (cola != null) {
                if (cola.count.intValue() > needAdvMaterial) {
                    needMaterial = 0;
                    cola.count = Integer.valueOf(cola.count.intValue() - needAdvMaterial);
                    role.getMaterialBox().addMaterial(cola);
                } else {
                    needMaterial = needAdvMaterial - cola.count.intValue();
                    role.getMaterialBox().removeMaterial(2013106035);
                    cola.count = Integer.valueOf(0);
                }
                cola.acquisitiontime = Long.valueOf(System.currentTimeMillis() / 1000L);
                materialitems.add(cola);
            } else {
                materialitems.add(ItemDataPool.setMaterial(2013106035, 0, true));
            }
            if (cola1 != null) {
                if (needMaterial > 0) {
                    if (cola1.count.intValue() > needMaterial) {
                        cola1.count = Integer.valueOf(cola1.count.intValue() - needMaterial);
                        role.getMaterialBox().addMaterial(cola1);
                        needMaterial = 0;
                    } else {
                        needMaterial -= cola1.count.intValue();
                        cola1.count = Integer.valueOf(0);
                        role.getMaterialBox().removeMaterial(2013106036);
                    }
                    cola1.acquisitiontime = Long.valueOf(System.currentTimeMillis() / 1000L);
                }
                materialitems.add(cola1);
            } else {
                materialitems.add(ItemDataPool.setMaterial(2013100894, 0, false));
            }
        } else {
            materialitems.add(ItemDataPool.setMaterial(2013106066, 0, true));
            materialitems.add(ItemDataPool.setMaterial(2013106066, 0, false));
            materialitems.add(ItemDataPool.setMaterial(2013104171, 0, false));
            materialitems.add(ItemDataPool.setMaterial(2013100894, 0, true));
            materialitems.add(ItemDataPool.setMaterial(2013104187, 0, false));
            PT_STACKABLE luyantan = (PT_STACKABLE)role.getMaterialBox().getMaterialsMap().get(Integer.valueOf(2013104187));
            PT_STACKABLE luyantan1 = (PT_STACKABLE)role.getMaterialBox().getMaterialsMap().get(Integer.valueOf(2013104171));
            PT_STACKABLE luyantan2 = (PT_STACKABLE)role.getMaterialBox().getMaterialsMap().get(Integer.valueOf(2013100894));
            if (luyantan != null) {
                if (luyantan.count.intValue() > needMaterial) {
                    luyantan.count = Integer.valueOf(luyantan.count.intValue() - needMaterial);
                    needMaterial = 0;
                    role.getMaterialBox().addMaterial(luyantan);
                } else {
                    needMaterial -= luyantan.count.intValue();
                    luyantan.count = Integer.valueOf(0);
                    role.getMaterialBox().removeMaterial(2013104187);
                }
                luyantan.acquisitiontime = Long.valueOf(System.currentTimeMillis() / 1000L);
                materialitems.add(luyantan);
            } else {
                materialitems.add(ItemDataPool.setMaterial(2013104187, 0, true));
            }
            if (luyantan1 != null) {
                if (needMaterial > 0) {
                    if (luyantan1.count.intValue() > needMaterial) {
                        luyantan1.count = Integer.valueOf(luyantan1.count.intValue() - needMaterial);
                        role.getMaterialBox().addMaterial(luyantan1);
                        needMaterial = 0;
                    } else {
                        needMaterial -= luyantan1.count.intValue();
                        luyantan1.count = Integer.valueOf(0);
                        role.getMaterialBox().removeMaterial(2013104171);
                    }
                    luyantan1.acquisitiontime = Long.valueOf(System.currentTimeMillis() / 1000L);
                }
                materialitems.add(luyantan1);
            } else {
                materialitems.add(ItemDataPool.setMaterial(2013104171, 0, true));
            }
            if (luyantan2 != null) {
                if (needMaterial > 0) {
                    if (luyantan2.count.intValue() > needMaterial) {
                        luyantan2.count = Integer.valueOf(luyantan2.count.intValue() - needMaterial);
                        role.getMaterialBox().addMaterial(luyantan2);
                        needMaterial = 0;
                    } else {
                        needMaterial -= luyantan2.count.intValue();
                        luyantan2.count = Integer.valueOf(0);
                        role.getMaterialBox().removeMaterial(2013100894);
                    }
                    luyantan2.acquisitiontime = Long.valueOf(System.currentTimeMillis() / 1000L);
                    materialitems.add(luyantan2);
                } else {
                    materialitems.add(luyantan2);
                }
            } else {
                materialitems.add(ItemDataPool.setMaterial(2013100894, 0, false));
            }
        }
        role.getMoneyBox().subCnt(0, needGold);
        removeitems.materialitems = materialitems;
        List<PT_MONEY_ITEM> currency = new ArrayList<>();
        currency.add(role.getMoneyBox().getMoneyItem(0));
        res_item_reinforce.guid = reqItemReinforce.guid;
        res_item_reinforce.upgrade = Integer.valueOf(upgrade);
        res_item_reinforce.upgradepoint = Integer.valueOf(updatepoint);
        res_item_reinforce.removeitems = removeitems;
        res_item_reinforce.currency = currency;
        res_item_reinforce.transId = reqItemReinforce.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)res_item_reinforce);
    }

    @RequestMapping
    public void REQ_RANDOMOPTION_UNLOCK(IoSession session, REQ_RANDOMOPTION_UNLOCK reqItemReinforce) {
        Equip equip;
        long guid = reqItemReinforce.guid.longValue();
        RES_RANDOMOPTION_UNLOCK resRandomoptionUnlock = new RES_RANDOMOPTION_UNLOCK();
        if (reqItemReinforce.type != null)
            resRandomoptionUnlock.type = reqItemReinforce.type;
        resRandomoptionUnlock.guid = Long.valueOf(guid);
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            equip = (Equip)EquipDataPool.index2Equip.get(ptEquip.index);
        } else {
            equip = (Equip)EquipDataPool.index2Equip.get(ptEquipped.index);
        }
        int rarity = equip.getRarity();
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            ptEquip.roption = EquipDataPool.getrop(rarity, equip.getEquiptype(), equip.getMinlevel());
            role.getEquipBox().addEquip(ptEquip);
            resRandomoptionUnlock.equip = ptEquip;
        } else {
            ptEquipped.roption = EquipDataPool.getrop(rarity, equip.getEquiptype(), equip.getMinlevel());
            role.getEquippedBox().updateEquip(ptEquipped);
            PT_EQUIP equipnew = EquipDataPool.changeEquip(ptEquipped);
            resRandomoptionUnlock.equip = equipnew;
        }
        resRandomoptionUnlock.transId = reqItemReinforce.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resRandomoptionUnlock);
    }

    @RequestMapping
    public void REQ_RANDOMOPTION_CHANGE(IoSession session, REQ_RANDOMOPTION_CHANGE reqRandomoptionChange) {
        Equip equip;
        RES_RANDOMOPTION_CHANGE resRandomoptionChange = new RES_RANDOMOPTION_CHANGE();
        long guid = reqRandomoptionChange.guid.longValue();
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        double costrate = 1.0D;
        double rarityrate = 1.0D;
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            equip = (Equip)EquipDataPool.index2Equip.get(ptEquip.index);
        } else {
            equip = (Equip)EquipDataPool.index2Equip.get(ptEquipped.index);
        }
        int rarity = equip.getRarity();
        int level = equip.getMinlevel();
        if (rarity <= 2) {
            costrate = 0.2D;
        } else if (rarity == 3) {
            costrate = 1.5D;
        } else if (rarity == 4) {
            costrate = 8.0D;
            rarityrate = 0.2D;
        } else if (rarity == 5) {
            costrate = 8.0D;
        }
        int costgold = (int)((500 * level) * costrate * rarityrate);
        role.getMoneyBox().subCnt(0, costgold);
        PT_EQUIP equipnew = new PT_EQUIP();
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            equipnew.index = ptEquip.index;
            equipnew.guid = ptEquip.guid;
            equipnew.quality = ptEquip.quality;
            equipnew.endurance = ptEquip.endurance;
            equipnew.rappearance = ptEquip.rappearance;
            equipnew.roption = ptEquip.roption;
            equipnew.rnoption = EquipDataPool.getrnop(rarity, equip.getEquiptype(), ptEquip.roption, equip.getMinlevel());
            ptEquip.rnoption = equipnew.rnoption;
            role.getEquipBox().addEquip(ptEquip);
        } else {
            equipnew.index = ptEquipped.index;
            equipnew.guid = ptEquipped.guid;
            equipnew.quality = ptEquipped.quality;
            equipnew.endurance = ptEquipped.endurance;
            equipnew.rappearance = ptEquipped.rappearance;
            equipnew.roption = ptEquipped.roption;
            equipnew.rnoption = EquipDataPool.getrnop(rarity, equip.getEquiptype(), ptEquipped.roption, equip.getMinlevel());
            ptEquipped.rnoption = equipnew.rnoption;
            role.getEquippedBox().updateEquip(ptEquipped);
        }
        List<PT_MONEY_ITEM> currency = new ArrayList<>();
        currency.add(role.getMoneyBox().getMoneyItem(0));
        PT_REMOVEITEMS removeitems = new PT_REMOVEITEMS();
        List<PT_STACKABLE> materialitems = new ArrayList<>();
        PT_STACKABLE materialitem = role.getMaterialBox().getMaterial(2013105727);
        if (materialitem != null) {
            role.getMaterialBox().updateMaterialSub(2013105727, 1);
            materialitems.add(role.getMaterialBox().getMaterial(2013105727));
        } else {
            PT_STACKABLE materialitem1 = role.getMaterialBox().getMaterial(2013106585);
            if (materialitem1 != null) {
                role.getMaterialBox().updateMaterialSub(2013106585, 1);
                materialitems.add(role.getMaterialBox().getMaterial(2013106585));
            } else {
                PT_STACKABLE materialitem2 = role.getMaterialBox().getMaterial(2013105726);
                role.getMaterialBox().updateMaterialSub(2013105726, 1);
                materialitems.add(role.getMaterialBox().getMaterial(2013105726));
            }
        }
        removeitems.materialitems = materialitems;
        resRandomoptionChange.guid = Long.valueOf(guid);
        resRandomoptionChange.type = reqRandomoptionChange.type;
        resRandomoptionChange.equip = equipnew;
        resRandomoptionChange.currency = currency;
        resRandomoptionChange.removeitems = removeitems;
        resRandomoptionChange.transId = reqRandomoptionChange.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resRandomoptionChange);
    }

    @RequestMapping
    public void REQ_RANDOMOPTION_SLOT_LOCK(IoSession session, REQ_RANDOMOPTION_SLOT_LOCK reqRandomoptionSlotLock) {
        RES_RANDOMOPTION_SLOT_LOCK resRandomoptionSlotLock = new RES_RANDOMOPTION_SLOT_LOCK();
        long guid = reqRandomoptionSlotLock.guid.longValue();
        int index = 0;
        if (reqRandomoptionSlotLock.index != null)
            index = reqRandomoptionSlotLock.index.intValue();
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        PT_EQUIP ptEquip = new PT_EQUIP();
        if (reqRandomoptionSlotLock.locked != null) {
            if (ptEquipped == null) {
                ptEquip.roption = EquipDataPool.selectRoption(ptEquip.roption, index, reqRandomoptionSlotLock.locked.booleanValue());
                role.getEquipBox().addEquip(ptEquip);
            } else {
                ptEquipped.roption = EquipDataPool.selectRoption(ptEquipped.roption, index, reqRandomoptionSlotLock.locked.booleanValue());
                role.getEquippedBox().updateEquip(ptEquipped);
                ptEquip = EquipDataPool.changeEquip(ptEquipped);
            }
        } else if (ptEquipped == null) {
            ptEquip = role.getEquipBox().getEquip(guid);
            ptEquip.roption = EquipDataPool.selectRoption(ptEquip.roption, index, false);
            role.getEquipBox().addEquip(ptEquip);
        } else {
            ptEquipped.roption = EquipDataPool.selectRoption(ptEquipped.roption, index, false);
            role.getEquippedBox().updateEquip(ptEquipped);
            ptEquip = EquipDataPool.changeEquip(ptEquipped);
        }
        resRandomoptionSlotLock.guid = Long.valueOf(guid);
        resRandomoptionSlotLock.type = reqRandomoptionSlotLock.type;
        resRandomoptionSlotLock.equip = ptEquip;
        resRandomoptionSlotLock.transId = reqRandomoptionSlotLock.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resRandomoptionSlotLock);
    }

    @RequestMapping
    public void REQ_RANDOMOPTION_SELECT(IoSession session, REQ_RANDOMOPTION_SELECT reqRandomoptionSelect) {
        RES_RANDOMOPTION_SELECT resRandomoptionSelect = new RES_RANDOMOPTION_SELECT();
        long guid = reqRandomoptionSelect.guid.longValue();
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        PT_EQUIP ptEquip = new PT_EQUIP();
        if (reqRandomoptionSelect.selecttype != null) {
            if (ptEquipped == null) {
                ptEquip = role.getEquipBox().getEquip(guid);
                ptEquip.roption = ptEquip.rnoption;
                ptEquip.rnoption = new ArrayList();
                role.getEquipBox().addEquip(ptEquip);
            } else {
                ptEquipped.setRoption(ptEquipped.rnoption);
                ptEquipped.rnoption = new ArrayList();
                role.getEquippedBox().updateEquip(ptEquipped);
                ptEquip = EquipDataPool.changeEquip(ptEquipped);
            }
        } else if (ptEquipped == null) {
            ptEquip = role.getEquipBox().getEquip(guid);
            ptEquip.rnoption = new ArrayList();
            role.getEquipBox().addEquip(ptEquip);
        } else {
            ptEquipped.rnoption = new ArrayList();
            role.getEquippedBox().updateEquip(ptEquipped);
            ptEquip = EquipDataPool.changeEquip(ptEquipped);
        }
        resRandomoptionSelect.guid = Long.valueOf(guid);
        resRandomoptionSelect.type = reqRandomoptionSelect.type;
        resRandomoptionSelect.equip = ptEquip;
        resRandomoptionSelect.transId = reqRandomoptionSelect.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resRandomoptionSelect);
    }

    @RequestMapping
    public void REQ_EQUIPMENT_RARIFY(IoSession session, REQ_EQUIPMENT_RARIFY reqEquipmentRarify) {
        RES_EQUIPMENT_RARIFY resEquipmentRarify = new RES_EQUIPMENT_RARIFY();
        long guid = reqEquipmentRarify.guid.longValue();
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        int quality = 0;
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            quality = RandomUtil.randomInt(1, 101);
            ptEquip.quality = Integer.valueOf(quality);
            role.getEquipBox().addEquip(ptEquip);
        } else {
            quality = RandomUtil.randomInt(1, 101);
            ptEquipped.quality = Integer.valueOf(quality);
            role.getEquippedBox().updateEquip(ptEquipped);
        }
        resEquipmentRarify.removeitems = new PT_REMOVEITEMS();
        resEquipmentRarify.removeitems.consumeitems = new ArrayList();
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        if (role.getConsumableBox().getConsumable(2013106098) != null && (role.getConsumableBox().getConsumable(2013106098)).count.intValue() > 0) {
            ptStackable.index = Integer.valueOf(2013106098);
            ptStackable.count = Integer.valueOf((role.getConsumableBox().getConsumable(2013106098)).count.intValue() - 1);
        } else {
            ptStackable.index = Integer.valueOf(2013101270);
            ptStackable.count = Integer.valueOf((role.getConsumableBox().getConsumable(2013101270)).count.intValue() - 1);
        }
        role.getConsumableBox().addConsumable(ptStackable);
        role.getMoneyBox().submoney(10000);
        resEquipmentRarify.guid = Long.valueOf(guid);
        resEquipmentRarify.currency = new ArrayList();
        resEquipmentRarify.currency.add(role.getMoneyBox().getMoneyItem(0));
        resEquipmentRarify.removeitems.consumeitems.add(ptStackable);
        resEquipmentRarify.quality = Integer.valueOf(quality);
        resEquipmentRarify.transId = reqEquipmentRarify.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resEquipmentRarify);
    }

    @RequestMapping
    public void REQ_CARD_ATTACH(IoSession session, REQ_CARD_ATTACH reqCardAttach) {
        RES_CARD_ATTACH resCardAttach = new RES_CARD_ATTACH();
        Role role = SessionUtils.getRoleBySession(session);
        long guid = reqCardAttach.guid.longValue();
        int index = reqCardAttach.card.index.intValue();
        PT_STACKABLE card = role.getCardBox().getCard(index);
        if (card.count == null) {
            card.count = Integer.valueOf(0);
        } else {
            card.count = Integer.valueOf(card.count.intValue() - 1);
        }
        role.getCardBox().updateCard(card);
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        PT_CARD_ATTACH ptCardAttach = new PT_CARD_ATTACH();
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(guid);
        if (ptEquipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            ptStackable = new PT_STACKABLE();
            ptStackable.index = Integer.valueOf(index);
            ptEquip.card = new ArrayList();
            ptEquip.card.add(ptStackable);
            role.getEquipBox().addEquip(ptEquip);
        } else {
            ptStackable = new PT_STACKABLE();
            ptStackable.index = Integer.valueOf(index);
            ptEquipped.card = new ArrayList();
            ptEquipped.card.add(ptStackable);
            role.getEquippedBox().updateEquip(ptEquipped);
        }
        ptCardAttach.index = Integer.valueOf(index);
        resCardAttach.guid = Long.valueOf(guid);
        resCardAttach.card = ptCardAttach;
        role.getMoneyBox().submoney(10000);
        resCardAttach.currency = new ArrayList();
        resCardAttach.currency.add(role.getMoneyBox().getMoneyItem(0));
        resCardAttach.transId = reqCardAttach.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resCardAttach);
    }

    @RequestMapping
    public void REQ_AVATAR_VISIBLE_FLAGS_SET(IoSession session, REQ_AVATAR_VISIBLE_FLAGS_SET reqAvatarVisibleFlagsSet) {
        RES_AVATAR_VISIBLE_FLAGS_SET resAvatarVisibleFlagsSet = new RES_AVATAR_VISIBLE_FLAGS_SET();
        Role role = SessionUtils.getRoleBySession(session);
        resAvatarVisibleFlagsSet.guid = Long.valueOf(role.getUid());
        resAvatarVisibleFlagsSet.flags = reqAvatarVisibleFlagsSet.flags;
        resAvatarVisibleFlagsSet.transId = reqAvatarVisibleFlagsSet.transId;
        MessagePusher.pushMessage(session, (Message)resAvatarVisibleFlagsSet);
    }

    @RequestMapping
    public void REQ_TRANSMISSION_ITEM(IoSession session, REQ_TRANSMISSION_ITEM reqTransmissionItem) {
        RES_TRANSMISSION_ITEM resTransmissionItem = new RES_TRANSMISSION_ITEM();
        long oldguid = reqTransmissionItem.materialguid.longValue();
        long newguid = reqTransmissionItem.itemguid.longValue();
        Role role = SessionUtils.getRoleBySession(session);
        PT_EQUIP ptEquipOld = role.getEquipBox().getEquip(oldguid);
        Equip equipInfoOld = EquipDataPool.getEquip(ptEquipOld.index.intValue());
        UpgradeInfo upgradeInfoold = EquipDataPool.getUpgradeInfo(ptEquipOld.upgrade.intValue(), ptEquipOld.equiptype, equipInfoOld.getMinlevel(), equipInfoOld.getRarity());
        int accuPointMaxOld = upgradeInfoold.accuPointMax;
        int pointAllOld = accuPointMaxOld + ptEquipOld.upgradepoint.intValue();
        int accuPointMaxNew = 0;
        int pointCount = 0;
        PT_EQUIP ptEquipnew = new PT_EQUIP();
        PT_EQUIPPED ptEquipped = role.getEquippedBox().getEquipped(newguid);
        if (ptEquipped == null) {
            ptEquipnew = role.getEquipBox().getEquip(newguid);
            Equip equipInfoNew = EquipDataPool.getEquip(ptEquipnew.index.intValue());
            UpgradeInfo upgradeInfoNew = EquipDataPool.getUpgradeInfo(ptEquipnew.upgrade.intValue(), equipInfoNew.getEquiptype(), equipInfoNew.getMinlevel(), equipInfoNew.getRarity());
            int pointAllNew = upgradeInfoNew.accuPointMax + ptEquipnew.upgradepoint.intValue();
            for (int i = 0; i <= 19; i++) {
                upgradeInfoNew = EquipDataPool.getUpgradeInfo(i, equipInfoNew.getEquiptype(), equipInfoNew.getMinlevel(), equipInfoNew.getRarity());
                accuPointMaxNew = upgradeInfoNew.accuPointMax;
                if (pointAllOld < accuPointMaxNew) {
                    ptEquipnew.upgrade = Integer.valueOf(i - 1);
                    ptEquipnew.upgradepoint = Integer.valueOf(pointCount);
                    break;
                }
                if (pointAllOld == accuPointMaxNew) {
                    ptEquipnew.upgrade = Integer.valueOf(i);
                    ptEquipnew.upgradepoint = Integer.valueOf(0);
                    break;
                }
                pointCount = pointAllOld - accuPointMaxNew;
            }
            pointCount = pointAllNew - accuPointMaxOld;
            for (int j = 0; j <= 19; j++) {
                UpgradeInfo upgradeInfoOld = EquipDataPool.getUpgradeInfo(j, equipInfoOld.getEquiptype(), equipInfoOld.getMinlevel(), equipInfoOld.getRarity());
                accuPointMaxOld = upgradeInfoOld.accuPointMax;
                if (pointAllNew < accuPointMaxOld) {
                    if (j == 0) {
                        ptEquipOld.upgrade = Integer.valueOf(0);
                        ptEquipOld.upgradepoint = Integer.valueOf(pointCount);
                        role.getEquipBox().addEquip(ptEquipOld);
                        break;
                    }
                    ptEquipOld.upgrade = Integer.valueOf(j - 1);
                    ptEquipOld.upgradepoint = Integer.valueOf(pointCount);
                    break;
                }
                if (pointAllNew == accuPointMaxOld) {
                    ptEquipOld.upgrade = Integer.valueOf(j);
                    ptEquipOld.upgradepoint = Integer.valueOf(0);
                    break;
                }
                pointCount = pointAllNew - accuPointMaxOld;
            }
            List<PT_RANDOMOPTION_ITEM> roption = ptEquipnew.roption;
            ptEquipnew.roption = ptEquipOld.roption;
            ptEquipOld.roption = roption;
            List<PT_EMBLEM> emblem = ptEquipnew.emblem;
            List<PT_EMBLEM> emblemold = ptEquipOld.emblem;
            if (emblem != null)
                ptEquipOld.emblem = emblem;
            if (emblemold != null)
                ptEquipnew.emblem = emblemold;
            List<PT_STACKABLE> card = ptEquipnew.card;
            List<PT_STACKABLE> cardold = ptEquipOld.card;
            if (card != null)
                ptEquipOld.card = card;
            if (cardold != null)
                ptEquipnew.card = cardold;
            role.getEquipBox().addEquip(ptEquipnew);
            role.getEquipBox().addEquip(ptEquipOld);
            resTransmissionItem.targetitem = ptEquipnew;
            resTransmissionItem.metarialitem = ptEquipOld;
        } else {
            Equip equipInfoNew = EquipDataPool.getEquip(ptEquipped.index.intValue());
            UpgradeInfo upgradeInfoNew = EquipDataPool.getUpgradeInfo(ptEquipped.upgrade.intValue(), equipInfoNew.getEquiptype(), equipInfoNew.getMinlevel(), equipInfoNew.getRarity());
            int pointAllNew = upgradeInfoNew.accuPointMax + ptEquipped.upgradepoint.intValue();
            for (int i = 0; i <= 19; i++) {
                upgradeInfoNew = EquipDataPool.getUpgradeInfo(i, equipInfoNew.getEquiptype(), equipInfoNew.getMinlevel(), equipInfoNew.getRarity());
                accuPointMaxNew = upgradeInfoNew.accuPointMax;
                if (pointAllOld < accuPointMaxNew) {
                    ptEquipped.upgrade = Integer.valueOf(i - 1);
                    ptEquipped.upgradepoint = Integer.valueOf(pointCount);
                    break;
                }
                if (pointAllOld == accuPointMaxNew) {
                    ptEquipped.upgrade = Integer.valueOf(i);
                    ptEquipped.upgradepoint = Integer.valueOf(0);
                    break;
                }
                pointCount = pointAllOld - accuPointMaxNew;
            }
            for (int j = 0; j <= 19; j++) {
                UpgradeInfo upgradeInfoOld = EquipDataPool.getUpgradeInfo(j, equipInfoOld.getEquiptype(), equipInfoOld.getMinlevel(), equipInfoOld.getRarity());
                accuPointMaxOld = upgradeInfoOld.accuPointMax;
                if (pointAllNew < accuPointMaxOld) {
                    if (j == 0) {
                        ptEquipOld.upgrade = Integer.valueOf(0);
                        ptEquipOld.upgradepoint = Integer.valueOf(pointCount);
                        break;
                    }
                    ptEquipOld.upgrade = Integer.valueOf(j - 1);
                    ptEquipOld.upgradepoint = Integer.valueOf(pointCount);
                    break;
                }
                if (pointAllNew == accuPointMaxOld) {
                    ptEquipOld.upgrade = Integer.valueOf(j);
                    ptEquipOld.upgradepoint = Integer.valueOf(0);
                    break;
                }
            }
            List<PT_RANDOMOPTION_ITEM> roption = ptEquipped.roption;
            ptEquipped.roption = ptEquipOld.roption;
            ptEquipOld.roption = roption;
            List<PT_STACKABLE> card = ptEquipped.card;
            List<PT_STACKABLE> cardold = ptEquipOld.card;
            if (card != null)
                ptEquipOld.card = card;
            if (cardold != null)
                ptEquipped.card = cardold;
            role.getEquippedBox().updateEquip(ptEquipped);
            role.getEquipBox().addEquip(ptEquipOld);
            resTransmissionItem.targetitem = EquipDataPool.changeEquip(ptEquipped);
            resTransmissionItem.metarialitem = ptEquipOld;
        }
        role.getMoneyBox().submoney(100000);
        resTransmissionItem.rewardinfo = new PT_CONTENTS_REWARD_INFO();
        resTransmissionItem.rewardinfo.currency = new PT_CURRENCY_REWARD_INFO();
        resTransmissionItem.rewardinfo.currency.currency = new ArrayList();
        resTransmissionItem.rewardinfo.currency.currency.add(role.getMoneyBox().getMoneyItem(0));
        resTransmissionItem.transId = reqTransmissionItem.transId;
        role.save();
        MessagePusher.pushMessage(session, (Message)resTransmissionItem);
    }

    @RequestMapping
    public void REQ_EMBLEM_EQUIP(IoSession session, REQ_EMBLEM_EQUIP req_emblem_equip) {
        Role role = SessionUtils.getRoleBySession(session);
        EquippedBox equippedBox = role.getEquippedBox();
        EmblemBox emblemBox = role.getEmblemBox();
        RES_EMBLEM_EQUIP res_emblem_equip = new RES_EMBLEM_EQUIP();
        res_emblem_equip.output = new PT_EMBLEM_RESULT();
        int index = req_emblem_equip.emblem.index.intValue();
        long guid = req_emblem_equip.guid.longValue();
        int slot = 0;
        if (req_emblem_equip.emblem.slot != null)
            slot = req_emblem_equip.emblem.slot.intValue();
        PT_STACKABLE emblem = emblemBox.getEmblem(index);
        PT_STACKABLE pT_STACKABLE1 = emblem;
        pT_STACKABLE1.count = Integer.valueOf(pT_STACKABLE1.count.intValue() - 1);
        emblemBox.putEmblem(emblem);
        PT_EQUIPPED pt_equipped = equippedBox.getEquipped(guid);
        if (pt_equipped == null) {
            PT_EQUIP pt_equip = role.getEquipBox().getEquip(guid);
            if (Util.isEmpty(pt_equip.emblem)) {
                pt_equip.emblem = new ArrayList();
                PT_EMBLEM tmp = new PT_EMBLEM();
                tmp.index = Integer.valueOf(index);
                tmp.count = Integer.valueOf(1);
                tmp.slot = Integer.valueOf(slot);
                pt_equip.emblem.add(tmp);
            } else {
                int outputIndex = -1;
                int removeIndex = -1;
                for (int i = 0; i < pt_equip.emblem.size(); i++) {
                    PT_EMBLEM e = pt_equip.emblem.get(i);
                    if (e.slot.intValue() == slot) {
                        removeIndex = i;
                        outputIndex = e.index.intValue();
                        break;
                    }
                }
                if (outputIndex != -1) {
                    pt_equip.emblem.remove(removeIndex);
                    PT_EMBLEM tmp = new PT_EMBLEM();
                    tmp.index = Integer.valueOf(index);
                    tmp.count = Integer.valueOf(1);
                    tmp.slot = Integer.valueOf(slot);
                    pt_equip.emblem.add(tmp);
                    res_emblem_equip.output.index = Integer.valueOf(outputIndex);
                } else {
                    PT_EMBLEM tmp = new PT_EMBLEM();
                    tmp.index = Integer.valueOf(index);
                    tmp.count = Integer.valueOf(1);
                    tmp.slot = Integer.valueOf(slot);
                    pt_equip.emblem.add(tmp);
                }
            }
            role.getEquipBox().addEquip(pt_equip);
        } else {
            if (Util.isEmpty(pt_equipped.emblem)) {
                pt_equipped.emblem = new ArrayList();
                PT_EMBLEM tmp = new PT_EMBLEM();
                tmp.index = Integer.valueOf(index);
                tmp.count = Integer.valueOf(1);
                tmp.slot = Integer.valueOf(slot);
                pt_equipped.emblem.add(tmp);
            } else {
                int outputIndex = -1;
                int removeIndex = -1;
                for (int i = 0; i < pt_equipped.emblem.size(); i++) {
                    PT_EMBLEM e = pt_equipped.emblem.get(i);
                    if (e.slot.intValue() == slot) {
                        removeIndex = i;
                        outputIndex = e.index.intValue();
                        break;
                    }
                }
                if (outputIndex != -1) {
                    pt_equipped.emblem.remove(removeIndex);
                    PT_EMBLEM tmp = new PT_EMBLEM();
                    tmp.index = Integer.valueOf(index);
                    tmp.count = Integer.valueOf(1);
                    tmp.slot = Integer.valueOf(slot);
                    pt_equipped.emblem.add(tmp);
                    res_emblem_equip.output.index = Integer.valueOf(outputIndex);
                } else {
                    PT_EMBLEM tmp = new PT_EMBLEM();
                    tmp.index = Integer.valueOf(index);
                    tmp.count = Integer.valueOf(1);
                    tmp.slot = Integer.valueOf(slot);
                    pt_equipped.emblem.add(tmp);
                }
            }
            equippedBox.updateEquip(pt_equipped);
            role.setEquippedBox(equippedBox);
        }
        res_emblem_equip.emblem = new PT_STACKABLE();
        res_emblem_equip.emblem.index = Integer.valueOf(index);
        res_emblem_equip.emblem.count = Integer.valueOf(1);
        res_emblem_equip.guid = Long.valueOf(guid);
        if (req_emblem_equip.emblem.slot != null)
            res_emblem_equip.slot = req_emblem_equip.emblem.slot;
        role.save();
        res_emblem_equip.transId = req_emblem_equip.transId;
        MessagePusher.pushMessage(session, (Message)res_emblem_equip);
    }

    @RequestMapping
    public void REQ_ITEM_EMBLEM_EXTRACT(IoSession session, REQ_ITEM_EMBLEM_EXTRACT req_item_emblem_extract) {
        PT_EMBLEM emblem;
        Role role = SessionUtils.getRoleBySession(session);
        EquippedBox equippedBox = role.getEquippedBox();
        long guid = req_item_emblem_extract.guid.longValue();
        int slot = 0;
        RES_EMBLEM_EXTRACT res_emblem_extract = new RES_EMBLEM_EXTRACT();
        if (req_item_emblem_extract.slot != null) {
            slot = req_item_emblem_extract.slot.intValue();
            res_emblem_extract.slot = Integer.valueOf(slot);
        }
        PT_EQUIPPED pt_equipped = equippedBox.getEquipped(guid);
        if (pt_equipped == null) {
            PT_EQUIP ptEquip = role.getEquipBox().getEquip(guid);
            int removeIndex = equippedBox.removeEmblem2(ptEquip, slot);
            if (removeIndex == -1) {
                this.logger.error("ERROR==REQ_ITEM_EMBLEM_EXTRACT remove emblem failed");
                return;
            }
            emblem = ptEquip.emblem.get(removeIndex);
            ptEquip.emblem.remove(removeIndex);
            role.getEmblemBox().updateEmblemAdd(removeIndex, 1);
            role.getEquipBox().addEquip(ptEquip);
        } else {
            int removeIndex = equippedBox.removeEmblem(pt_equipped, slot);
            if (removeIndex == -1) {
                this.logger.error("ERROR==REQ_ITEM_EMBLEM_EXTRACT remove emblem failed");
                return;
            }
            emblem = pt_equipped.emblem.get(removeIndex);
            pt_equipped.emblem.remove(removeIndex);
            role.getEmblemBox().updateEmblemAdd(removeIndex, 1);
            equippedBox.updateEquip(pt_equipped);
        }
        res_emblem_extract.guid = Long.valueOf(guid);
        res_emblem_extract.rewards = new PT_CONTENTS_REWARD_INFO();
        res_emblem_extract.rewards.items = new PT_ITEM_REWARD_INFO();
        res_emblem_extract.rewards.items.inventory = new PT_ITEMS();
        res_emblem_extract.rewards.items.inventory.emblemitems = new ArrayList();
        PT_STACKABLE ptStackable = new PT_STACKABLE();
        ptStackable.index = emblem.index;
        ptStackable.count = Integer.valueOf(1);
        res_emblem_extract.rewards.items.inventory.emblemitems.add(ptStackable);
        role.setEquippedBox(equippedBox);
        role.save();
        res_emblem_extract.transId = req_item_emblem_extract.transId;
        MessagePusher.pushMessage(session, (Message)res_emblem_extract);
    }
}
