package com.dnfm.game.equip.model;

/**
 * 升级信息模型类。
 * 包含升级所需的金币、材料、冒险材料以及升级点数的最大值。
 */
public class UpgradeInfo {

    // 升级所需金币
    public int needGold;

    // 升级所需材料
    public int needMaterial;

    // 升级所需冒险材料
    public int needAdvMaterial;

    // 单次升级最大点数
    public int pointMax;

    // 累积升级最大点数
    public int accuPointMax;
}