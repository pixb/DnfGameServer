/*    */
package com.dnfm.game.equip.model;
/*    */ 
/*    */ public class Leiji
/*    */ {
/*    */   private int roleId;
/*    */   private String name;
/*    */   private int count;
/*    */   
/*    */   public int getRoleId() {
/* 10 */     return this.roleId;
/*    */   }
/*    */   
/*    */   public void setRoleId(int roleId) {
/* 14 */     this.roleId = roleId;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 18 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 22 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getCount() {
/* 26 */     return this.count;
/*    */   }
/*    */   
/*    */   public void setCount(int count) {
/* 30 */     this.count = count;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\model\Leiji.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */