/*    */
package com.dnfm.game.equip.model;
/*    */ 
/*    */ public class RoleData {
/*    */   int charge;
/*    */   long uid;
/*    */   String name;
/*    */   
/*    */   public int getCharge() {
/*  9 */     return this.charge;
/*    */   }
/*    */   
/*    */   public void setCharge(int charge) {
/* 13 */     this.charge = charge;
/*    */   }
/*    */   
/*    */   public long getUid() {
/* 17 */     return this.uid;
/*    */   }
/*    */   
/*    */   public void setUid(long uid) {
/* 21 */     this.uid = uid;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 25 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 29 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\equip\model\RoleData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */