package com.dnfm.game.equip.model;

import com.dnfm.mina.protobuf.PT_CRACK;
import com.dnfm.mina.protobuf.PT_EMBLEM;
import com.dnfm.mina.protobuf.PT_RANDOMOPTION_ITEM;
import com.dnfm.mina.protobuf.PT_STACKABLE;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoleEquip {

    private Integer id;
    private Integer index;
    private Integer slot = -1;
    private Long guid;
    private Integer upgrade;
    private Integer quality;
    private Integer endurance;
    private Integer enchant;
    private Integer reforge;
    private Integer reforgeexp;
    private Integer amplify;
    private Integer aoption;
    private List<PT_EMBLEM> emblem;
    private List<PT_STACKABLE> card;
    private Integer scount;
    private Integer tcount;
    private Long expiretime;
    private Boolean rappearance;
    private List<PT_RANDOMOPTION_ITEM> roption;
    private List<PT_RANDOMOPTION_ITEM> rnoption;
    private Integer skin;
    private Long skinguid;
    private Boolean locked;
    private Boolean seal;
    private Integer enchantindex;
    private List<PT_CRACK> crack;
    private Integer sindex;
    private Integer sealing;
    private Integer upgradepoint;
    private Integer gaizaoJindu;
    private Integer score = 1;
    private Long roleId;
    private String type;
    private String name;
}