package com.dnfm.game.equip.model;

import com.dnfm.common.thread.IdGenerator;
import com.dnfm.mina.protobuf.PT_EQUIP;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@EqualsAndHashCode
public class EquipBox implements Serializable {
    private int maxcount = 40;
    private Map<Long, PT_EQUIP> equips = new ConcurrentHashMap<>();

    public PT_EQUIP getEquip(long equipGuid) {
        return equips.get(equipGuid);
    }

    public PT_EQUIP removeEquip(long equipGuid) {
        return equips.remove(equipGuid);
    }

    public PT_EQUIP getEquipByIndex(int index) {
        return equips.values().stream()
                .filter(equip -> equip.getIndex() == index)
                .findFirst()
                .orElse(null);
    }

    public void addEquip(PT_EQUIP pt_equip) {
        equips.put(pt_equip.guid, pt_equip);
    }

    public void addEquip(int index, int upgrade) {
        PT_EQUIP pt_equip = new PT_EQUIP();
        pt_equip.index = index;
        pt_equip.guid = IdGenerator.getNextId();
        if (upgrade != 0) {
            pt_equip.upgrade = upgrade;
        }
        pt_equip.quality = 100;
        pt_equip.endurance = 30;
        equips.put(pt_equip.guid, pt_equip);
    }

    public List<PT_EQUIP> getEquipList() {
        return new ArrayList<>(equips.values());
    }
}