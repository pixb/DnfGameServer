package com.dnfm.game.shop.model;

public class GachaRecipeModel {
  public int recipe;
  
  public int index;
  
  public int count;
  
  public int rate;
  
  public int grade;
  
  public int rateNum;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\shop\model\GachaRecipeModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */