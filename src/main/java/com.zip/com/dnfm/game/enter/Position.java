/*    */
package com.dnfm.game.enter;
/*    */ 
/*    */ public class Position {
/*    */   private short x;
/*    */   private short y;
/*    */   
/*    */   public short getX() {
/*  8 */     return this.x;
/*    */   }
/*    */   
/*    */   public void setX(short x) {
/* 12 */     this.x = x;
/*    */   }
/*    */   
/*    */   public short getY() {
/* 16 */     return this.y;
/*    */   }
/*    */   
/*    */   public void setY(short y) {
/* 20 */     this.y = y;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\enter\Position.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */