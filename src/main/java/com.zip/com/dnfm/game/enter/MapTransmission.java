/*    */
package com.dnfm.game.enter;
/*    */ 
/*    */ public class MapTransmission {
/*    */   private String name;
/*    */   private short X;
/*    */   private short Y;
/*    */   private short dir;
/*  8 */   private short a = 0;
/*    */   
/*    */   public String getName() {
/* 11 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 15 */     this.name = name;
/*    */   }
/*    */   
/*    */   public short getX() {
/* 19 */     return this.X;
/*    */   }
/*    */   
/*    */   public void setX(short x) {
/* 23 */     this.X = x;
/*    */   }
/*    */   
/*    */   public short getY() {
/* 27 */     return this.Y;
/*    */   }
/*    */   
/*    */   public void setY(short y) {
/* 31 */     this.Y = y;
/*    */   }
/*    */   
/*    */   public short getDir() {
/* 35 */     return this.dir;
/*    */   }
/*    */   
/*    */   public void setDir(short dir) {
/* 39 */     this.dir = dir;
/*    */   }
/*    */   
/*    */   public short getA() {
/* 43 */     return this.a;
/*    */   }
/*    */   
/*    */   public void setA(short a) {
/* 47 */     this.a = a;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\enter\MapTransmission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */