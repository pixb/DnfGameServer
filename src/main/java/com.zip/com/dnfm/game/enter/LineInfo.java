/*    */
package com.dnfm.game.enter;
/*    */ 
/*    */ public class LineInfo {
/*    */   private short id;
/*    */   private String lineName;
/*    */   private String lineIp;
/*    */   private short status;
/*    */   
/*    */   public short getId() {
/* 10 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(short id) {
/* 14 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getLineName() {
/* 18 */     return this.lineName;
/*    */   }
/*    */   
/*    */   public void setLineName(String lineName) {
/* 22 */     this.lineName = lineName;
/*    */   }
/*    */   
/*    */   public String getLineIp() {
/* 26 */     return this.lineIp;
/*    */   }
/*    */   
/*    */   public void setLineIp(String lineIp) {
/* 30 */     this.lineIp = lineIp;
/*    */   }
/*    */   
/*    */   public short getStatus() {
/* 34 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(short status) {
/* 38 */     this.status = status;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\enter\LineInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */