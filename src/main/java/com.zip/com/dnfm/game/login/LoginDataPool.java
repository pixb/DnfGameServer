package com.dnfm.game.login;

public class LoginDataPool {
  public static final int REQ_LOGIN = 1;
  
  public static final int REQ_SELECT_PLAYER = 2;
  
  public static final int RES_LOGIN = 501;
  
  public static final int LOGIN_FAIL = 0;
  
  public static final int LOGIN_SUCC = 1;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\login\LoginDataPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */