// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.game.item.model;

import java.util.ArrayList;
import java.util.List;

public class GiftContentMap {
    public List<GiftContent> giftContents = new ArrayList();
    public int allCount;
}
