// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.game.item.model;

public class GiftContent {
  public int id;
  public int count;
  public int probability;
}
