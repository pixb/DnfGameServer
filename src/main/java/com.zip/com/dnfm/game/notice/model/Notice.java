
/*    */
package com.dnfm.game.notice.model;

/*    */
/*    */ import org.nutz.dao.entity.annotation.ColDefine;
/*    */ import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;
/*    */ 
/*    */ @Table("t_notice")
/*    */ public class Notice {
/*    */   @Id
/*    */   private int id;
/*    */   @Column
/*    */   @ColDefine(width = 1024)
/*    */   private String content;
/*    */   
/*    */   public int getId() {
/* 17 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 21 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getContent() {
/* 25 */     return this.content;
/*    */   }
/*    */   
/*    */   public void setContent(String content) {
/* 29 */     this.content = content;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\notice\model\Notice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */