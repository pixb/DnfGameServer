// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.game.adventure.model;

import com.dnfm.mina.protobuf.PT_REAP_REWARD;

import java.util.ArrayList;

public class AdventureReapInfo {
    private ArrayList<PT_REAP_REWARD> rewards;
    private long starttime = -1L;

    public AdventureReapInfo() {
    }

    public ArrayList<PT_REAP_REWARD> getRewards() {
        return this.rewards;
    }

    public long getStarttime() {
        return this.starttime;
    }

    public void setRewards(ArrayList<PT_REAP_REWARD> rewards) {
        this.rewards = rewards;
    }

    public void setStarttime(long starttime) {
        this.starttime = starttime;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof AdventureReapInfo)) {
            return false;
        } else {
            AdventureReapInfo other = (AdventureReapInfo) o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                Object this$rewards = this.getRewards();
                Object other$rewards = other.getRewards();
                if (this$rewards == null) {
                    if (other$rewards == null) {
                        return this.getStarttime() == other.getStarttime();
                    }
                } else if (this$rewards.equals(other$rewards)) {
                    return this.getStarttime() == other.getStarttime();
                }

                return false;
            }
        }
    }

    protected boolean canEqual(Object other) {
        return other instanceof AdventureReapInfo;
    }

    public String toString() {
        return "AdventureReapInfo(rewards=" + this.getRewards() + ", starttime=" + this.getStarttime() + ")";
    }
}
