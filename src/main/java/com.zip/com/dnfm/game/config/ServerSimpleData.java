package com.dnfm.game.config;

import lombok.Data;

@Data
public class ServerSimpleData {
    private int type;
    private int enumvalue;
    private String value;
    private int transId;
}