package com.dnfm.game.config;

import lombok.Data;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Table;

@Data
@Table("p_itemshop")
public class ItemShop {
    @Column
    private int index;
    @Column
    private int goodsid;
    @Column
    private int moneytype;
    @Column
    private int moneycount;
    @Column
    private String limittype;
    @Column
    private String limitday;
    @Column
    private int limitcount;
    @Column
    private String shopname;
}