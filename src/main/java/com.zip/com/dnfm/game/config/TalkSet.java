/*    */
package com.dnfm.game.config;

/*    */
/*    */

import org.nutz.dao.entity.annotation.ColDefine;
/*    */ import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;

/*    */
/*    */
@Table("p_talkset")
/*    */ public class TalkSet implements Cloneable {
    /*    */
    @Id
    /*    */ private int id;
    /*    */
    @Column
    /*    */ private String npcName;
    /*    */
    @Column
    /*    */ private short npcIcon;
    /*    */
    @Column
    /*    */
    @ColDefine(width = 512)
    /*    */ private String msg;
    /*    */
    @Column
    /*    */ private String taskName;
    /*    */
    @Column
    /*    */ private String name;
    /*    */
    @Column
    /*    */ private int nextId;

    /*    */
    /*    */
    public String getName() {
        /* 27 */
        return this.name;
        /*    */
    }

    /*    */
    /*    */
    public void setName(String name) {
        /* 31 */
        this.name = name;
        /*    */
    }

    /*    */
    /*    */
    public int getId() {
        /* 35 */
        return this.id;
        /*    */
    }

    /*    */
    /*    */
    public void setId(int id) {
        /* 39 */
        this.id = id;
        /*    */
    }

    /*    */
    /*    */
    public String getNpcName() {
        /* 43 */
        return this.npcName;
        /*    */
    }

    /*    */
    /*    */
    public void setNpcName(String npcName) {
        /* 47 */
        this.npcName = npcName;
        /*    */
    }

    /*    */
    /*    */
    public short getNpcIcon() {
        /* 51 */
        return this.npcIcon;
        /*    */
    }

    /*    */
    /*    */
    public void setNpcIcon(short npcIcon) {
        /* 55 */
        this.npcIcon = npcIcon;
        /*    */
    }

    /*    */
    /*    */
    public String getMsg() {
        /* 59 */
        return this.msg;
        /*    */
    }

    /*    */
    /*    */
    public void setMsg(String msg) {
        /* 63 */
        this.msg = msg;
        /*    */
    }

    /*    */
    /*    */
    public String getTaskName() {
        /* 67 */
        return this.taskName;
        /*    */
    }

    /*    */
    /*    */
    public void setTaskName(String taskName) {
        /* 71 */
        this.taskName = taskName;
        /*    */
    }

    /*    */
    /*    */
    public int getNextId() {
        /* 75 */
        return this.nextId;
        /*    */
    }

    /*    */
    /*    */
    public void setNextId(int nextId) {
        /* 79 */
        this.nextId = nextId;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public com.dnfm.game.config.TalkSet clone() throws CloneNotSupportedException {
        /* 84 */
        return (com.dnfm.game.config.TalkSet) super.clone();
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\TalkSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */