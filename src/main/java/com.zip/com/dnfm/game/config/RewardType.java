package com.dnfm.game.config;

public interface RewardType {
  public static final String STK = "stk";
  
  public static final String EQU = "equ";
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\RewardType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */