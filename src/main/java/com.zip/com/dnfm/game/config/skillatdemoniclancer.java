/*    */
package com.dnfm.game.config;

/*    */
/*    */

import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Comment;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
@Table("p_skillatdemoniclancer")
/*    */ public class skillatdemoniclancer
        /*    */ {
    /*    */
    @Id
    /*    */
    @Column("index")
    /*    */ private int index;
    /*    */
    @Column("name")
    /*    */
    @Comment("技能名称")
    /*    */ private String skillName;
    /*    */
    @Column("type")
    /*    */ private String type;
    /*    */
    @Column("growtype")
    /*    */ private int growtype;
    /*    */
    @Column("reqlevel")
    /*    */ private int reqlevel;
    /*    */
    @Column("levelrange")
    /*    */ private int levelrange;
    /*    */
    @Column("cost")
    /*    */ private int cost;
    /*    */
    @Column("maxlevel")
    /*    */ private int maxlevel;

    /*    */
    /*    */
    public int getIndex() {
        /* 39 */
        return this.index;
        /*    */
    }

    /*    */
    /*    */
    public void setIndex(int index) {
        /* 43 */
        this.index = index;
        /*    */
    }

    /*    */
    /*    */
    public String getSkillName() {
        /* 47 */
        return this.skillName;
        /*    */
    }

    /*    */
    /*    */
    public void setSkillName(String skillName) {
        /* 51 */
        this.skillName = skillName;
        /*    */
    }

    /*    */
    /*    */
    public String getType() {
        /* 55 */
        return this.type;
        /*    */
    }

    /*    */
    /*    */
    public void setType(String type) {
        /* 59 */
        this.type = type;
        /*    */
    }

    /*    */
    /*    */
    public int getGrowtype() {
        /* 63 */
        return this.growtype;
        /*    */
    }

    /*    */
    /*    */
    public void setGrowtype(int growtype) {
        /* 67 */
        this.growtype = growtype;
        /*    */
    }

    /*    */
    /*    */
    public int getReqlevel() {
        /* 71 */
        return this.reqlevel;
        /*    */
    }

    /*    */
    /*    */
    public void setReqlevel(int reqlevel) {
        /* 75 */
        this.reqlevel = reqlevel;
        /*    */
    }

    /*    */
    /*    */
    public int getLevelrange() {
        /* 79 */
        return this.levelrange;
        /*    */
    }

    /*    */
    /*    */
    public void setLevelrange(int levelrange) {
        /* 83 */
        this.levelrange = levelrange;
        /*    */
    }

    /*    */
    /*    */
    public int getCost() {
        /* 87 */
        return this.cost;
        /*    */
    }

    /*    */
    /*    */
    public void setCost(int cost) {
        /* 91 */
        this.cost = cost;
        /*    */
    }

    /*    */
    /*    */
    public int getMaxlevel() {
        /* 95 */
        return this.maxlevel;
        /*    */
    }

    /*    */
    /*    */
    public void setMaxlevel(int maxlevel) {
        /* 99 */
        this.maxlevel = maxlevel;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\skillatdemoniclancer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */