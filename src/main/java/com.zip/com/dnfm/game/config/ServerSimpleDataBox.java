package com.dnfm.game.config;

import java.util.HashMap;
import java.util.Map;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ServerSimpleDataBox {
    public int nextTransId = 0;
    private Map<String, ServerSimpleData> allDatas = new HashMap<>();

    public void addServerSimpleData(int type, int enumvalue, ServerSimpleData data) {
        String key = type + "_" + enumvalue;
        this.allDatas.put(key, data);
    }

    public ServerSimpleData getData(int type, int enumvalue) {
        String key = type + "_" + enumvalue;
        return this.allDatas.get(key);
    }
}