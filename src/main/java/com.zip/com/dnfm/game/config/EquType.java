package com.dnfm.game.config;

public interface EquType {
  public static final String TITLE = "title";
  
  public static final String AVATAR = "avatar";
  
  public static final String WEAPON = "weapon";
  
  public static final String FLAG = "flag";
  
  public static final String ARTIFACT = "artifact";
  
  public static final String CREATURE = "creature";
  
  public static final String SD = "sd ";
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\EquType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */