package com.dnfm.game.config;

import com.dnfm.game.pet.model.Pet;
import lombok.*;
import org.nutz.dao.entity.annotation.*;
import org.nutz.lang.util.NutMap;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Table("p_npc")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NPC implements Cloneable {
    @Id
    private int id;

    @Column
    @Comment("npc名称")
    private String name;

    @Column
    @Default("1")
    @Comment("npc类型")
    private byte type;

    @Column
    private short x;

    @Column
    private short y;

    @Column
    private short fangxiang;

    @Column
    @Comment("地图id")
    private int mapId;

    @Column
    @Comment("对话")
    private String content = "";

    @Column
    @Comment("对话2")
    private String content1;

    @Column
    @Comment("外观")
    private int icon;

    @Column
    @Comment("物品")
    @Default("[]")
    private List<String> list;

    private int wuqiId;
    private int taozhuangId;
    private int faguangId;
    private NutMap status;
    private long createTime = System.currentTimeMillis();
    private long endTime = -1L;
    private Lock lock = new ReentrantLock(true);
    private String tempName;
    private int level;
    private long roleUid;
    private NutMap roleInfo;
    private Pet pet;
    private final AtomicBoolean inFight = new AtomicBoolean();
    private String bossSetName;
    private String title;
    private byte polar;

    @Override
    public NPC clone() throws CloneNotSupportedException {
        return (NPC) super.clone();
    }

    public NutMap getStatus() {
        if (this.status == null) {
            return NutMap.NEW();
        }
        return this.status;
    }

    public boolean isShow() {
        return (this.endTime <= 0L || System.currentTimeMillis() <= this.endTime);
    }

    public boolean isMatchPolar(byte polar) {
        if (this.polar <= 0) {
            return true;
        }
        return (this.polar == polar);
    }
}