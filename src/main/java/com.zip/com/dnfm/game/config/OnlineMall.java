package com.dnfm.game.config;

import lombok.Data;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;
import java.util.Date;

@Data
@Table("p_onlinemall")
public class OnlineMall {
    @Id
    private int id;

    @Column
    @Comment("物品名称")
    private String name;

    @Column
    @Comment("物品编号")
    private String number;

    @Column
    @Comment("花费金钱类型")
    private short costtype;

    @Column
    @Comment("所在位置")
    private short pos;

    @Column
    @Comment("限购数量")
    private short xiangou;

    @Column
    @Comment("价格")
    private int price;

    @Column
    @Comment("折扣")
    private byte sale;

    @Column
    @Comment("限购时间")
    private Date time;

    @Column
    @Comment("所在页面")
    private byte page;

    @Column
    @Comment("使用类型")
    private int type;

    @Column
    @Comment("物品类型")
    private short itemtype;

    @Column
    @Comment("量词")
    private String unit;
}