package com.dnfm.game.config;

import lombok.EqualsAndHashCode;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_consume")
@EqualsAndHashCode
public class ConsumeItem {
    @Column
    @Comment("物品名称")
    private String itemname;
    @Id
    private int index;
    @Column
    @Comment("客户端物品类型")
    private int stackabletype;
    @Column
    @Comment("物品品质")
    private int grade;
    @Column
    @Comment("类别")
    private int subtype;
    @Column
    @Comment("物品重量")
    private int weight;
    @Column
    @Comment("抗魔值")
    private int score;
    @Column
    @Comment("最低使用等级")
    private int minlevel;
    @Column
    @Comment("稀有度")
    private int rarity;
    @Column
    @Comment("物品等级")
    private int level;
    @Column
    @Comment("出售价格")
    private int sellprice;

    public String getItemname() {
        return this.itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getStackabletype() {
        return this.stackabletype;
    }

    public void setStackabletype(int stackabletype) {
        this.stackabletype = stackabletype;
    }

    public int getGrade() {
        return this.grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getSubtype() {
        return this.subtype;
    }

    public void setSubtype(int subtype) {
        this.subtype = subtype;
    }

    public int getWeight() {
        return this.weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getScore() {
        return this.score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getMinlevel() {
        return this.minlevel;
    }

    public void setMinlevel(int minlevel) {
        this.minlevel = minlevel;
    }

    public int getRarity() {
        return this.rarity;
    }

    public void setRarity(int rarity) {
        this.rarity = rarity;
    }

    public int getLevel() {
        return this.level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getSellprice() {
        return this.sellprice;
    }

    public void setSellprice(int sellprice) {
        this.sellprice = sellprice;
    }

    public String toString() {
        return "ConsumeItem(itemname=" + getItemname() + ", index=" + getIndex() + ", stackabletype=" + getStackabletype() + ", grade=" + getGrade() + ", subtype=" + getSubtype() + ", weight=" + getWeight() + ", score=" + getScore() + ", minlevel=" + getMinlevel() + ", rarity=" + getRarity() + ", level=" + getLevel() + ", sellprice=" + getSellprice() + ")";
    }
}