/*     */
package com.dnfm.game.config;

/*     */
/*     */

import org.nutz.dao.entity.annotation.Column;
/*     */ import org.nutz.dao.entity.annotation.Comment;
/*     */ import org.nutz.dao.entity.annotation.Id;
/*     */ import org.nutz.dao.entity.annotation.Table;

/*     */
/*     */
@Table("p_skill")
/*     */ public class Skill {
    /*     */
    @Id
    /*     */ private int id;
    /*     */
    @Column("Skill_ID")
    /*     */
    @Comment("技能id")
    /*     */ private int skillId;
    /*     */
    @Column("Skill_Name")
    /*     */
    @Comment("技能名称")
    /*     */ private String skillName;
    /*     */
    @Column("Skill_Job")
    /*     */
    @Comment("技能职业")
    /*     */ private int skillJob;
    /*     */
    @Column("Skill_Target")
    /*     */
    @Comment("技能目标")
    /*     */ private int skillTarget;
    /*     */
    @Column("Skill_Life")
    /*     */
    @Comment("")
    /*     */ private int skillLife;
    /*     */
    @Column("Skill_The")
    /*     */
    @Comment("技能类型")
    /*     */ private int skillType;
    /*     */
    @Column("Skill_Color")
    /*     */
    @Comment("技能颜色")
    /*     */ private int skillColor;
    /*     */
    @Column("Skill_req_Level")
    /*     */
    @Comment("技能所需等级")
    /*     */ private int reqLevel;
    /*     */
    @Column("Skill_Front")
    /*     */
    @Comment("先学习此技能到达等级")
    /*     */ private int skillFront;
    /*     */
    @Column("Front_Skill")
    /*     */
    @Comment("先学习此技能")
    /*     */ private int frontSkill;
    /*     */
    @Column("Max_Target")
    /*     */
    @Comment("技能最大目标数量")
    /*     */ private int maxTarget;
    /*     */
    @Column("jeishu")
    /*     */
    @Comment("技能阶数")
    /*     */ private byte jeishu;

    /*     */
    /*     */
    public byte getJeishu() {
        /*  50 */
        return this.jeishu;
        /*     */
    }

    /*     */
    /*     */
    public void setJeishu(byte jeishu) {
        /*  54 */
        this.jeishu = jeishu;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillType() {
        /*  58 */
        return this.skillType;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillType(int skillType) {
        /*  62 */
        this.skillType = skillType;
        /*     */
    }

    /*     */
    /*     */
    public int getId() {
        /*  66 */
        return this.id;
        /*     */
    }

    /*     */
    /*     */
    public void setId(int id) {
        /*  70 */
        this.id = id;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillId() {
        /*  74 */
        return this.skillId;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillId(int skillId) {
        /*  78 */
        this.skillId = skillId;
        /*     */
    }

    /*     */
    /*     */
    public String getSkillName() {
        /*  82 */
        return this.skillName;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillName(String skillName) {
        /*  86 */
        this.skillName = skillName;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillJob() {
        /*  90 */
        return this.skillJob;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillJob(int skillJob) {
        /*  94 */
        this.skillJob = skillJob;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillTarget() {
        /*  98 */
        return this.skillTarget;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillTarget(int skillTarget) {
        /* 102 */
        this.skillTarget = skillTarget;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillLife() {
        /* 106 */
        return this.skillLife;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillLife(int skillLife) {
        /* 110 */
        this.skillLife = skillLife;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillColor() {
        /* 114 */
        return this.skillColor;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillColor(int skillColor) {
        /* 118 */
        this.skillColor = skillColor;
        /*     */
    }

    /*     */
    /*     */
    public int getReqLevel() {
        /* 122 */
        return this.reqLevel;
        /*     */
    }

    /*     */
    /*     */
    public void setReqLevel(int reqLevel) {
        /* 126 */
        this.reqLevel = reqLevel;
        /*     */
    }

    /*     */
    /*     */
    public int getSkillFront() {
        /* 130 */
        return this.skillFront;
        /*     */
    }

    /*     */
    /*     */
    public void setSkillFront(int skillFront) {
        /* 134 */
        this.skillFront = skillFront;
        /*     */
    }

    /*     */
    /*     */
    public int getFrontSkill() {
        /* 138 */
        return this.frontSkill;
        /*     */
    }

    /*     */
    /*     */
    public void setFrontSkill(int frontSkill) {
        /* 142 */
        this.frontSkill = frontSkill;
        /*     */
    }

    /*     */
    /*     */
    public int getMaxTarget() {
        /* 146 */
        return this.maxTarget;
        /*     */
    }

    /*     */
    /*     */
    public void setMaxTarget(int maxTarget) {
        /* 150 */
        this.maxTarget = maxTarget;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public boolean isMagicSkill() {
        /* 159 */
        return (this.skillType == 146 && this.skillId != 501);
        /*     */
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\Skill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */