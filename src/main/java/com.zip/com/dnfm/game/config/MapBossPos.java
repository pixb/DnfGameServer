/*    */
package com.dnfm.game.config;

/*    */
/*    */

import com.dnfm.game.enter.Position;
/*    */ import java.util.List;
/*    */ import org.nutz.dao.entity.annotation.ColDefine;
/*    */ import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Default;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;

/*    */
/*    */
/*    */
/*    */
@Table("p_mapbosspos")
/*    */ public class MapBossPos
        /*    */ {
    /*    */
    @Id
    /*    */ private int id;

    /*    */
    /*    */
    public int getMapId() {
        /* 20 */
        return this.mapId;
    }

    @Column
    /*    */ private int mapId;
    @Column
    /*    */
    @Default("[]")
    /*    */
    @ColDefine(width = 4096)
    /* 24 */ private List<Position> list;

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    /*    */
    /*    */
    /*    */
    public List<Position> getList() {
        /* 28 */
        return this.list;
        /*    */
    }

    /*    */
    /*    */
    public void setList(List<Position> list) {
        /* 32 */
        this.list = list;
        /*    */
    }

    /*    */
    /*    */
    public int getId() {
        /* 36 */
        return this.id;
        /*    */
    }

    /*    */
    /*    */
    public void setId(int id) {
        /* 40 */
        this.id = id;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\MapBossPos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */