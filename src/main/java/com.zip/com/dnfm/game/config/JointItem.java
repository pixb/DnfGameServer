package com.dnfm.game.config;

public class JointItem {
    public int index;

    public int min;

    public int max;
}