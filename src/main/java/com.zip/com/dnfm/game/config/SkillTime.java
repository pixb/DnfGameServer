/*    */
package com.dnfm.game.config;

/*    */
/*    */

import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;

/*    */
/*    */
@Table("p_skill_play_time")
/*    */ public class SkillTime
        /*    */ {
    /*    */
    @Id
    /*    */ private int id;
    /*    */
    @Column
    /*    */ private String name;
    /*    */
    @Column
    /*    */ private int millisecond;

    /*    */
    /*    */
    public int getId() {
        /* 18 */
        return this.id;
        /*    */
    }

    /*    */
    /*    */
    public void setId(int id) {
        /* 22 */
        this.id = id;
        /*    */
    }

    /*    */
    /*    */
    public String getName() {
        /* 26 */
        return this.name;
        /*    */
    }

    /*    */
    /*    */
    public void setName(String name) {
        /* 30 */
        this.name = name;
        /*    */
    }

    /*    */
    /*    */
    public int getMillisecond() {
        /* 34 */
        return this.millisecond;
        /*    */
    }

    /*    */
    /*    */
    public void setMillisecond(int millisecond) {
        /* 38 */
        this.millisecond = millisecond;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\SkillTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */