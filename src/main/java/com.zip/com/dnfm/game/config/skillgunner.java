/*    */
package com.dnfm.game.config;

/*    */
/*    */

import org.nutz.dao.entity.annotation.Column;
/*    */ import org.nutz.dao.entity.annotation.Comment;
/*    */ import org.nutz.dao.entity.annotation.Id;
/*    */ import org.nutz.dao.entity.annotation.Table;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
@Table("p_skillgunner")
/*    */ public class skillgunner
        /*    */ {
    /*    */
    @Id
    /*    */
    @Column("index")
    /*    */ private int index;
    /*    */
    @Column("name")
    /*    */
    @Comment("技能名称")
    /*    */ private String skillName;
    /*    */
    @Column("type")
    /*    */ private String type;
    /*    */
    @Column("growtype")
    /*    */ private int growtype;
    /*    */
    @Column("reqlevel")
    /*    */ private int reqlevel;
    /*    */
    @Column("levelrange")
    /*    */ private int levelrange;
    /*    */
    @Column("cost")
    /*    */ private int cost;
    /*    */
    @Column("maxlevel")
    /*    */ private int maxlevel;

    /*    */
    /*    */
    public int getIndex() {
        /* 38 */
        return this.index;
        /*    */
    }

    /*    */
    /*    */
    public void setIndex(int index) {
        /* 42 */
        this.index = index;
        /*    */
    }

    /*    */
    /*    */
    public String getSkillName() {
        /* 46 */
        return this.skillName;
        /*    */
    }

    /*    */
    /*    */
    public void setSkillName(String skillName) {
        /* 50 */
        this.skillName = skillName;
        /*    */
    }

    /*    */
    /*    */
    public String getType() {
        /* 54 */
        return this.type;
        /*    */
    }

    /*    */
    /*    */
    public void setType(String type) {
        /* 58 */
        this.type = type;
        /*    */
    }

    /*    */
    /*    */
    public int getGrowtype() {
        /* 62 */
        return this.growtype;
        /*    */
    }

    /*    */
    /*    */
    public void setGrowtype(int growtype) {
        /* 66 */
        this.growtype = growtype;
        /*    */
    }

    /*    */
    /*    */
    public int getReqlevel() {
        /* 70 */
        return this.reqlevel;
        /*    */
    }

    /*    */
    /*    */
    public void setReqlevel(int reqlevel) {
        /* 74 */
        this.reqlevel = reqlevel;
        /*    */
    }

    /*    */
    /*    */
    public int getLevelrange() {
        /* 78 */
        return this.levelrange;
        /*    */
    }

    /*    */
    /*    */
    public void setLevelrange(int levelrange) {
        /* 82 */
        this.levelrange = levelrange;
        /*    */
    }

    /*    */
    /*    */
    public int getCost() {
        /* 86 */
        return this.cost;
        /*    */
    }

    /*    */
    /*    */
    public void setCost(int cost) {
        /* 90 */
        this.cost = cost;
        /*    */
    }

    /*    */
    /*    */
    public int getMaxlevel() {
        /* 94 */
        return this.maxlevel;
        /*    */
    }

    /*    */
    /*    */
    public void setMaxlevel(int maxlevel) {
        /* 98 */
        this.maxlevel = maxlevel;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\config\skillgunner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */