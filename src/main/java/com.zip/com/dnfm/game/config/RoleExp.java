package com.dnfm.game.config;

import lombok.Data;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

/**
 * 角色经验配置实体类。
 * 使用 Lombok 注解自动生成 getter、setter、equals、hashCode 和 toString 方法。
 * 使用 Nutz DAO 注解映射数据库表。
 */
@Data // 自动生成 getter、setter、equals、hashCode 和 toString
@Table("p_exp")
public class RoleExp {

    @Id(auto = false)
    @Comment("level")
    private int level;

    @Column
    @Comment("exp")
    private int exp;
}