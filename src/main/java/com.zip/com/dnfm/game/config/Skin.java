package com.dnfm.game.config;

import lombok.Getter;
import lombok.Setter;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Comment;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("p_skin")
@Getter
@Setter
public class Skin {
    @Column
    @Comment("物品名称")
    private String itemname;
    @Id
    private int index;
    @Column
    @Comment("客户端物品类型")
    private int periodtype;
    @Column
    @Comment("物品品质")
    private int grade;
    @Column
    @Comment("物品类型")
    private int subtype;
    @Column
    @Comment("物品重量")
    private int weight;
    @Column
    @Comment("抗魔值")
    private int score;
    @Column
    @Comment("最低使用等级")
    private int minlevel;
    @Column
    @Comment("物品介绍")
    private String iteminfo;
}