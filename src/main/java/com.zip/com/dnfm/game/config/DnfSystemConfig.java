package com.dnfm.game.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DNF 系统配置类，用于管理升级评分配置和角色评分配置。
 * 该类包含静态方法和静态字段，用于初始化和查询配置数据。
 * Lombok 在此类中不适用，因为没有需要生成 getter/setter 的实例属性。
 */
public class DnfSystemConfig {

    // 存储升级评分配置，键为升级 ID
    private static Map<Integer, UpgradeScoreConfig> upgradeScoreConfig;

    // 存储角色评分配置，键为 jobID + groupName
    private static Map<String, CharacterScoreConfig> characterScoreConfig;

    /**
     * 初始化升级评分配置。
     *
     * @param list 升级评分配置列表
     */
    public static void initUpgradeScoreConfig(List<UpgradeScoreConfig> list) {
        upgradeScoreConfig = new HashMap<>();
        for (UpgradeScoreConfig config : list) {
            upgradeScoreConfig.put(config.getId(), config); // 直接使用 config.getId()，假设 getId() 返回 Integer
        }
    }

    /**
     * 根据索引获取升级评分配置。
     *
     * @param index 升级配置索引
     * @return 对应的升级评分配置
     */
    public static UpgradeScoreConfig getUpgradeScoreConfig(int index) {
        return upgradeScoreConfig.get(index); // 直接使用 int，自动装箱为 Integer
    }

    /**
     * 初始化角色评分配置。
     *
     * @param list 角色评分配置列表
     */
    public static void initCharacterScoreConfig(List<CharacterScoreConfig> list) {
        characterScoreConfig = new HashMap<>();
        for (CharacterScoreConfig config : list) {
            String key = config.getJobid() + config.getGroupname(); // 假设 getJobid() 返回 int, getGroupname() 返回 String
            characterScoreConfig.put(key, config);
        }
    }

    /**
     * 根据职业 ID 和组名获取角色评分配置。
     *
     * @param jobID     职业 ID
     * @param groupName 组名
     * @return 对应的角色评分配置
     */
    public static CharacterScoreConfig getCharacterScoreConfig(Integer jobID, String groupName) {
        String key = jobID + groupName; // Integer 和 String 拼接
        return characterScoreConfig.get(key);
    }

    /**
     * 根据魔法值获取对应的系数。
     *
     * @param magicSpell 魔法值
     * @return 对应的系数
     */
    public static double getMagicSpell(int magicSpell) {
        switch (magicSpell) {
            case 1:
                return 1.0;
            case 2:
                return 1.6;
            case 3:
                return 2.2;
            case 4:
                return 2.8;
            case 5:
                return 3.0;
            case 6:
                return 3.5;
            default:
                return 0.0; // 明确指定默认返回值
        }
    }
}