/*    */
package com.dnfm.game.skill.model;

/*    */ public class RoleSkill {
    private int roleId;
    /*    */   private int index;
    /*    */   private int level;

    /*    */
    /*  6 */
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean equals(Object o) {
        if (o == this) return true;
        if (!(o instanceof com.dnfm.game.skill.model.RoleSkill)) return false;
        com.dnfm.game.skill.model.RoleSkill other = (com.dnfm.game.skill.model.RoleSkill) o;
        if (!other.canEqual(this)) return false;
        if (getRoleId() != other.getRoleId()) return false;
        if (getIndex() != other.getIndex()) return false;
        if (getLevel() != other.getLevel()) return false;
        if (getSlot() != other.getSlot()) return false;
        Object this$name = getName(), other$name = other.getName();
        return !((this$name == null) ? (other$name != null) : !this$name.equals(other$name));
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.game.skill.model.RoleSkill;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + getRoleId();
        result = result * 59 + getIndex();
        result = result * 59 + getLevel();
        result = result * 59 + getSlot();
        Object $name = getName();
        return result * 59 + (($name == null) ? 43 : $name.hashCode());
    }

    public String toString() {
        return "RoleSkill(roleId=" + getRoleId() + ", index=" + getIndex() + ", level=" + getLevel() + ", slot=" + getSlot() + ", name=" + getName() + ")";
    }

    /*    */
    /*    */
    public int getRoleId() {
        /*  9 */
        return this.roleId;
        /*    */
    }

    public int getIndex() {
        /* 11 */
        return this.index;
        /*    */
    }

    public int getLevel() {
        /* 13 */
        return this.level;
        /*    */
    }

    /* 15 */   private int slot = -1;
    private String name;

    public int getSlot() {
        return this.slot;
    }

    /*    */
    public String getName() {
        /* 17 */
        return this.name;
        /*    */
    }
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\skill\model\RoleSkill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */