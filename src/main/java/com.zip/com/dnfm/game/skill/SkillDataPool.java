package com.dnfm.game.skill;


import com.dnfm.game.config.Skill;
import java.util.Map;

public class SkillDataPool {
  public static Map<Integer, Skill> id2Skill;
  
  public static Map<String, Skill> name2Skill;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\skill\SkillDataPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */