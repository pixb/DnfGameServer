package com.dnfm.game.skill.model;

import com.dnfm.mina.protobuf.PT_SKILL;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Data
@NoArgsConstructor
@EqualsAndHashCode
public class SkillBox {
    private int sp = 40;
    private int tp = 0;
    private int addsp = 0;
    private int addtp = 0;
    private int sp_pk = 40;
    private int tp_pk = 0;
    private int addsp_pk = 0;
    private int addtp_pk = 0;
    private List<PT_SKILL> skilllist = new ArrayList<>();
    private List<PT_SKILL> skilllist_pk = new ArrayList<>();
    private List<PT_SKILL> skilllist_dungeon = new ArrayList<>();

    public void addSkill_dungeon(PT_SKILL pt_skill) {
        this.skilllist_dungeon.add(pt_skill);
    }

    public void addSkill(PT_SKILL pt_skill) {
        this.skilllist.add(pt_skill);
    }

    public void addSkill(int index) {
        PT_SKILL pt_skill = new PT_SKILL();
        pt_skill.index = index;
        pt_skill.level = 1;
        this.skilllist.add(pt_skill);
    }

    public void addSkill(int index, int level) {
        PT_SKILL pt_skill = new PT_SKILL();
        pt_skill.index = index;
        pt_skill.level = level;
        this.skilllist.add(pt_skill);
    }

    public void subSkill(int index) {
        Iterator<PT_SKILL> var2 = this.skilllist.iterator();
        while(var2.hasNext()) {
            PT_SKILL pt_skill = var2.next();
            if (pt_skill.index == index) {
                this.skilllist.remove(pt_skill);
                break;
            }
        }
    }

    public void addSkill_pk(PT_SKILL pt_skill) {
        this.skilllist_pk.add(pt_skill);
    }

    public void addSkill_pk(int index) {
        PT_SKILL pt_skill = new PT_SKILL();
        pt_skill.index = index;
        pt_skill.level = 1;
        this.skilllist_pk.add(pt_skill);
    }

    public void addSkill_pk(int index, int level) {
        PT_SKILL pt_skill = new PT_SKILL();
        pt_skill.index = index;
        pt_skill.level = level;
        this.skilllist_pk.add(pt_skill);
    }

    public void learnSkill(PT_SKILL roleSkill) {
        this.skilllist.add(roleSkill);
    }

    public PT_SKILL querySkillBy(int skillId) {
        Iterator<PT_SKILL> var2 = this.skilllist.iterator();
        PT_SKILL pt_skill;
        do {
            if (!var2.hasNext()) {
                return null;
            }
            pt_skill = var2.next();
        } while(pt_skill.index != skillId);
        return pt_skill;
    }

    public List<PT_SKILL> queryAllSkills() {
        return this.skilllist;
    }
}