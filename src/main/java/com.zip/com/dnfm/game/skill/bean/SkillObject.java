package com.dnfm.game.skill.bean;

import lombok.Data;

@Data
public class SkillObject {
    private String name = "";
    private int index;
    private int cost = 0;
    private String type = "";
    private int growtype = 0;
    private int reqlevel = 0;
    private int levelrange = 0;
    private int maxlevel = 0;
}