/*    */
package com.dnfm.game.skill.service;

/*    */
/*    */

import com.dnfm.game.config.Skill;
/*    */ import com.dnfm.game.skill.SkillDataPool;
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.stereotype.Service;

/*    */
/*    */
/*    */
@Service
/*    */ public class SkillService
        /*    */ {
    /* 17 */ Logger logger = LoggerFactory.getLogger(com.dnfm.game.skill.service.SkillService.class);
    /*    */
    /*    */
    /*    */
    /*    */
    /* 22 */   private final List<Integer> targetNumSkillIds = Arrays.asList(new Integer[]{Integer.valueOf(701), Integer.valueOf(702), Integer.valueOf(703), Integer.valueOf(704), Integer.valueOf(925), Integer.valueOf(926), Integer.valueOf(927), Integer.valueOf(928), Integer.valueOf(922), Integer.valueOf(923), Integer.valueOf(924)});

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void initSkill(List<Skill> list) {
        /* 30 */
        Map<Integer, Skill> id2Skill = new HashMap<>(list.size());
        /* 31 */
        Map<String, Skill> name2Skill = new HashMap<>(list.size());
        /* 32 */
        for (Skill skill : list) {
            /* 33 */
            id2Skill.put(Integer.valueOf(skill.getSkillId()), skill);
            /* 34 */
            name2Skill.put(skill.getSkillName(), skill);
            /*    */
        }
        /* 36 */
        SkillDataPool.id2Skill = id2Skill;
        /* 37 */
        SkillDataPool.name2Skill = name2Skill;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public Skill getSkillInfo(int skillId) {
        /* 45 */
        return (Skill) SkillDataPool.id2Skill.get(Integer.valueOf(skillId));
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\skill\service\SkillService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */