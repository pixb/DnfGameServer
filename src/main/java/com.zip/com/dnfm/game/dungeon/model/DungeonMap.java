package com.dnfm.game.dungeon.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode
@Table("p_dungeonmap")
public class DungeonMap {
    @Id
    private int index;

    @Column
    private int dungeon;

    @Column
    private String type;

    @Column
    private String monster;

    @Column
    private String ai;
}