package com.dnfm.game.dungeon.model;

public class PartyBoard {
    public int type;
    public int area;
    public int subtype;
    public int stageindex;
    public int dungeonindex;
}