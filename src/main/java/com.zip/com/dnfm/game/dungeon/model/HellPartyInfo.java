package com.dnfm.game.dungeon.model;


import java.util.List;

public class HellPartyInfo {
  public int hellObjectIndex;
  
  public int dropObjectIndex;
  
  public int dropMonsterIndex;
  
  public List<Integer> hellMonsters;
  
  public List<Integer> hellMonsters2;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\dungeon\model\HellPartyInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */