/*    */
package com.dnfm.game.dungeon.model;
/*    */ 
/*    */ public class RewardItem {
/*    */   public int index;
/*    */   public double minRate;
/*    */   public double maxRate;
/*    */   public int finalCnt;
/*    */   
/*    */   public RewardItem(int index, double minRate, double maxRate) {
/* 10 */     this.index = index;
/* 11 */     this.minRate = minRate;
/* 12 */     this.maxRate = maxRate;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\dungeon\model\RewardItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */