package com.dnfm.game.dungeon.model;

public class TowerRewardItem {
  public int index;
  
  public int cnt;
}