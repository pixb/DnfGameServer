package com.dnfm.game.dungeon.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Data
@NoArgsConstructor
@EqualsAndHashCode
@Table("p_dungeon")
public class Dungeon {
    @Id
    private int index;

    @Column
    private String name;

    @Column
    private String mapSpec;

    @Column
    private String startMap;

    @Column
    private String bossMap;

    @Column
    private String dungeonType;

    @Column
    private Integer basisLevel;

    @Column
    private Integer clearExp;

    @Column
    private String hellmap;
}
