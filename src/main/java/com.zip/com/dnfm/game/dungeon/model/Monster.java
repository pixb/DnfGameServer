package com.dnfm.game.dungeon.model;

public class Monster {
    public boolean isAI = false;
    public int index;
    public String type0;
    public String type;
    public String dummy;
}