/*    */
package com.dnfm.game.dungeon.model;

/*    */
/*    */ import com.dnfm.game.dungeon.model.RewardItem;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RewardList {
/*  8 */   public List<RewardItem> selList = new ArrayList<>();
/*    */ 
/*    */   
/* 11 */   public List<RewardItem> everyMustList = new ArrayList<>();
/*    */ 
/*    */   
/* 14 */   public List<RewardItem> rareList = new ArrayList<>();
/*    */ 
/*    */   
/* 17 */   public List<RewardItem> fullMustList = new ArrayList<>();
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\dungeon\model\RewardList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */