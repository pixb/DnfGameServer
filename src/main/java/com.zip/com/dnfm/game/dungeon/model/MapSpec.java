
package com.dnfm.game.dungeon.model;

public class MapSpec {
    public String type = "map";
    public int posx;
    public int posy;
    public int index;
}