/*    */
package com.dnfm.game.utils;

/*    */
/*    */

import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class MD5
        /*    */ {
    /* 12 */   private static final String[] strDigits = new String[]{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"};

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    private static String byteToArrayString(byte bByte) {
        /* 20 */
        int iRet = bByte;
        /*    */
        /* 22 */
        if (iRet < 0) {
            /* 23 */
            iRet += 256;
            /*    */
        }
        /* 25 */
        int iD1 = iRet / 16;
        /* 26 */
        int iD2 = iRet % 16;
        /* 27 */
        return strDigits[iD1] + strDigits[iD2];
        /*    */
    }

    /*    */
    /*    */
    /*    */
    private static String byteToString(byte[] bByte) {
        /* 32 */
        StringBuilder sBuffer = new StringBuilder();
        /* 33 */
        for (byte b : bByte) {
            /* 34 */
            sBuffer.append(byteToArrayString(b));
            /*    */
        }
        /* 36 */
        return sBuffer.toString();
        /*    */
    }

    /*    */
    /*    */
    public static String GetMD5Code(String strObj) {
        /* 40 */
        String resultString = null;
        /*    */
        try {
            /* 42 */
            resultString = strObj;
            /* 43 */
            MessageDigest md = MessageDigest.getInstance("MD5");
            /*    */
            /* 45 */
            resultString = byteToString(md.digest(strObj.getBytes()));
            /* 46 */
        } catch (NoSuchAlgorithmException ex) {
            /* 47 */
            ex.printStackTrace();
            /*    */
        }
        /* 49 */
        return resultString;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\MD5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */