/*    */
package com.dnfm.game.utils;

/*    */
/*    */

import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.mina.cache.SessionUtils;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.nutz.lang.util.NutMap;

/*    */
/*    */ public class SessionDataUtils
        /*    */ {
    /*    */
    public static NutMap getData(Role role) {
        /* 11 */
        IoSession session = SessionUtils.getSessionBy(role.getUid());
        /* 12 */
        Object object = session.getAttribute("data");
        /* 13 */
        if (object == null) {
            /* 14 */
            NutMap nutMap = new NutMap();
            /* 15 */
            session.setAttribute("data", nutMap);
            /*    */
        }
        /* 17 */
        object = session.getAttribute("data");
        /* 18 */
        return (NutMap) object;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\SessionDataUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */