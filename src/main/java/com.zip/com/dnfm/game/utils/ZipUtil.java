/*    */
package com.dnfm.game.utils;

/*    */
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Base64;
/*    */ import java.util.zip.GZIPInputStream;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZipUtil
/*    */ {
/*    */   public static String compress(String str) {
/* 16 */     if (str == null || str.length() == 0) {
/* 17 */       return str;
/*    */     }
/* 19 */     ByteArrayOutputStream out = null;
/* 20 */     GZIPOutputStream gzip = null;
/* 21 */     String compress = "";
/*    */     try {
/* 23 */       out = new ByteArrayOutputStream();
/* 24 */       gzip = new GZIPOutputStream(out);
/* 25 */       gzip.write(str.getBytes());
/* 26 */       gzip.close();
/*    */       
/* 28 */       byte[] compressed = out.toByteArray();
/* 29 */       compress = Base64.getEncoder().encodeToString(compressed);
/* 30 */     } catch (IOException iOException) {
/*    */     
/*    */     } finally {
/* 33 */       if (null != out) {
/*    */         try {
/* 35 */           out.close();
/* 36 */         } catch (IOException iOException) {}
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 41 */     return compress;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String uncompress(String str) {
/* 49 */     if (str == null || str.length() == 0) {
/* 50 */       return str;
/*    */     }
/* 52 */     ByteArrayOutputStream out = null;
/* 53 */     ByteArrayInputStream in = null;
/* 54 */     GZIPInputStream gzip = null;
/* 55 */     String uncompress = "";
/*    */     try {
/* 57 */       out = new ByteArrayOutputStream();
/*    */       
/* 59 */       byte[] compressed = Base64.getDecoder().decode(str);
/* 60 */       in = new ByteArrayInputStream(compressed);
/* 61 */       gzip = new GZIPInputStream(in);
/* 62 */       byte[] buffer = new byte[1024];
/* 63 */       int offset = -1;
/* 64 */       while ((offset = gzip.read(buffer)) != -1) {
/* 65 */         out.write(buffer, 0, offset);
/*    */       }
/* 67 */       uncompress = out.toString();
/* 68 */     } catch (IOException iOException) {
/*    */     
/*    */     } finally {
/* 71 */       if (null != gzip) {
/*    */         try {
/* 73 */           gzip.close();
/* 74 */         } catch (IOException iOException) {}
/*    */       }
/*    */ 
/*    */       
/* 78 */       if (null != in) {
/*    */         try {
/* 80 */           in.close();
/* 81 */         } catch (IOException iOException) {}
/*    */       }
/*    */ 
/*    */       
/* 85 */       if (null != out) {
/*    */         try {
/* 87 */           out.close();
/* 88 */         } catch (IOException iOException) {}
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 93 */     return uncompress;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\ZipUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */