package com.dnfm.game.utils;

public interface CommonConst {}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\CommonConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */