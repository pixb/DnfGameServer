/*    */
package com.dnfm.game.utils;

/*    */
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileUtils
/*    */ {
/*    */   public static String readText(String fileName) throws IOException {
/* 21 */     File file = new File(fileName);
/* 22 */     if (!file.exists()) {
/* 23 */       throw new FileNotFoundException();
/*    */     }
/* 25 */     FileInputStream in = new FileInputStream(file);
/* 26 */     StringBuilder result = new StringBuilder();
/*    */     
/* 28 */     try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
/*    */       String line;
/* 30 */       while ((line = br.readLine()) != null) {
/* 31 */         result.append(line).append("\n");
/*    */       }
/*    */     } 
/* 34 */     in.close();
/* 35 */     return result.toString();
/*    */   }
/*    */   
/*    */   public static List<String> readLines(String fileName) throws IOException {
/* 39 */     File file = new File(fileName);
/* 40 */     if (!file.exists()) {
/* 41 */       throw new FileNotFoundException();
/*    */     }
/* 43 */     List<String> result = new ArrayList<>();
/* 44 */     FileInputStream in = new FileInputStream(file);
/*    */     
/* 46 */     try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
/*    */       String line;
/* 48 */       while ((line = br.readLine()) != null) {
/* 49 */         result.add(line);
/*    */       }
/*    */     } 
/* 52 */     in.close();
/* 53 */     return result;
/*    */   }
/*    */   
/*    */   public static List<File> listFiles(String path) {
/* 57 */     List<File> result = new ArrayList<>();
/*    */     try {
/* 59 */       File file = new File(path);
/* 60 */       if (file.isFile()) {
/* 61 */         result.add(file);
/*    */       } else {
/* 63 */         File[] files = file.listFiles();
/* 64 */         result.addAll(Arrays.asList(files));
/*    */       } 
/* 66 */     } catch (Exception exception) {}
/*    */ 
/*    */     
/* 69 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\FileUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */