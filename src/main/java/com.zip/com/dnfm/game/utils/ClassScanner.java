/*     */
package com.dnfm.game.utils;

/*     */
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassScanner
/*     */ {
/*     */   private static final Predicate<Class<?>> EMPTY_FILTER = clazz -> true;
/*  27 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.game.utils.ClassScanner.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> getClasses(String scanPackage) {
/*  36 */     return getClasses(scanPackage, EMPTY_FILTER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> listAllSubclasses(String scanPackage, Class<?> parent) {
/*  47 */     return getClasses(scanPackage, clazz -> 
/*  48 */         (parent.isAssignableFrom(clazz) && !Modifier.isAbstract(clazz.getModifiers())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends java.lang.annotation.Annotation> Set<Class<?>> listClassesWithAnnotation(String scanPackage, Class<A> annotation) {
/*  61 */     return getClasses(scanPackage, clazz -> (clazz.getAnnotation(annotation) != null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Class<?>> getClasses(String pack, Predicate<Class<?>> filter) {
/*  74 */     PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver();
/*  75 */     SimpleMetadataReaderFactory simpleMetadataReaderFactory = new SimpleMetadataReaderFactory((ResourceLoader)pathMatchingResourcePatternResolver);
/*     */     
/*  77 */     String path = ClassUtils.convertClassNameToResourcePath(pack);
/*  78 */     String location = "classpath:" + path + "/**/*.class";
/*     */ 
/*     */     
/*  81 */     Set<Class<?>> result = new HashSet<>();
/*     */     try {
/*  83 */       Resource[] resources = pathMatchingResourcePatternResolver.getResources(location);
/*  84 */       for (Resource resource : resources) {
/*  85 */         MetadataReader metaReader = simpleMetadataReaderFactory.getMetadataReader(resource);
/*  86 */         if (resource.isReadable()) {
/*  87 */           String clazzName = metaReader.getClassMetadata().getClassName();
/*  88 */           if (!clazzName.contains("$")) {
/*     */ 
/*     */ 
/*     */             
/*  92 */             Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(clazzName);
/*  93 */             if (filter.test(clazz))
/*  94 */               result.add(clazz); 
/*     */           } 
/*     */         } 
/*     */       } 
/*  98 */     } catch (Exception e) {
/*  99 */       logger.error("", e);
/*     */     } 
/*     */     
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\ClassScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */