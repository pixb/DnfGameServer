package com.dnfm.game.utils;

public interface Const {
  public static final int DEVICE_ANDROID = 1;
  
  public static final int DEVICE_IOS = 2;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\Const.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */