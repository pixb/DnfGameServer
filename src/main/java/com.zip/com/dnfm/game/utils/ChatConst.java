package com.dnfm.game.utils;

public interface ChatConst {
  public static final short MISC = 0;
  
  public static final short CURRENT = 1;
  
  public static final short WORLD = 2;
  
  public static final short TELL = 3;
  
  public static final short TEAM = 4;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\ChatConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */