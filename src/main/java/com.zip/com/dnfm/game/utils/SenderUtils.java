/*    */
package com.dnfm.game.utils;

/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.mina.cache.DataCache;
/*    */ import com.dnfm.mina.message.MessagePusher;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class SenderUtils {
/* 10 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.game.utils.SenderUtils.class);
/*    */   
/*    */   public static void brodCastMessage(Message message, String type) {
/* 13 */     if (type.equals("npc")) {
/* 14 */       DataCache.ONLINE_ROLES.values().forEach(role -> MessagePusher.pushMessage(role, message));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void sendAllOnlinePlayers(Message message) {
/* 21 */     DataCache.ONLINE_ROLES.values().forEach(role -> MessagePusher.pushMessage(role, message));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void pushChatMessage(Message respChat) {
/* 37 */     DataCache.ONLINE_ROLES.values().forEach(role -> MessagePusher.pushMessage(role, respChat));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void pushAreaChatMessage(int town, int area, Message respChat) {
/* 46 */     DataCache.ONLINE_ROLES.values().forEach(onlineRole -> {
/*    */           int rtown = onlineRole.getPos().getTown();
/*    */           int rarea = onlineRole.getPos().getArea();
/*    */           if (rtown != town || rarea != area)
/*    */             return; 
/*    */           MessagePusher.pushMessage(onlineRole, respChat);
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\SenderUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */