/*     */
package com.dnfm.game.utils;
/*     */ 
/*     */ 
/*     */ public final class NumberUtil
/*     */ {
/*     */   public static boolean booleanValue(Object object) {
/*   7 */     return booleaneValue(object, Boolean.FALSE.booleanValue());
/*     */   }
/*     */   
/*     */   public static boolean booleaneValue(Object object, boolean defaultValue) {
/*  11 */     if (object == null) {
/*  12 */       return defaultValue;
/*     */     }
/*  14 */     if (object.getClass() == boolean.class || object.getClass() == Boolean.class) {
/*  15 */       return ((Boolean)object).booleanValue();
/*     */     }
/*     */     try {
/*  18 */       return Boolean.valueOf(object.toString()).booleanValue();
/*  19 */     } catch (Exception e) {
/*  20 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte byteValue(Object object) {
/*  25 */     return byteValue(object, Byte.valueOf("0").byteValue());
/*     */   }
/*     */   
/*     */   public static byte byteValue(Object object, byte defaultValue) {
/*  29 */     if (object == null) {
/*  30 */       return defaultValue;
/*     */     }
/*  32 */     if (object.getClass() == byte.class || object.getClass() == Byte.class) {
/*  33 */       return ((Byte)object).byteValue();
/*     */     }
/*     */     try {
/*  36 */       return Byte.valueOf(object.toString()).byteValue();
/*  37 */     } catch (Exception e) {
/*  38 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static short shortValue(Object object) {
/*  43 */     return shortValue(object, (short)0);
/*     */   }
/*     */   
/*     */   public static short shortValue(Object object, short defaultValue) {
/*  47 */     if (object == null) {
/*  48 */       return defaultValue;
/*     */     }
/*  50 */     if (object.getClass() == short.class || object.getClass() == Short.class) {
/*  51 */       return ((Short)object).shortValue();
/*     */     }
/*     */     try {
/*  54 */       return Short.valueOf(object.toString()).shortValue();
/*  55 */     } catch (Exception e) {
/*  56 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int intValue(Object object) {
/*  61 */     return intValue(object, 0);
/*     */   }
/*     */   
/*     */   public static int intValue(Object object, int defaultValue) {
/*  65 */     if (object == null) {
/*  66 */       return defaultValue;
/*     */     }
/*  68 */     if (object.getClass() == int.class || object.getClass() == Integer.class) {
/*  69 */       return ((Integer)object).intValue();
/*     */     }
/*     */     try {
/*  72 */       return Integer.valueOf(object.toString()).intValue();
/*  73 */     } catch (Exception e) {
/*  74 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long longValue(Object object) {
/*  79 */     return longValue(object, 0L);
/*     */   }
/*     */   
/*     */   public static long longValue(Object object, long defaultValue) {
/*  83 */     if (object == null) {
/*  84 */       return defaultValue;
/*     */     }
/*  86 */     if (object.getClass() == long.class || object.getClass() == Long.class) {
/*  87 */       return ((Long)object).longValue();
/*     */     }
/*     */     try {
/*  90 */       return Long.valueOf(object.toString()).longValue();
/*  91 */     } catch (Exception e) {
/*  92 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static double doubleValue(Object object) {
/*  97 */     return doubleValue(object, 0.0D);
/*     */   }
/*     */   
/*     */   public static double doubleValue(Object object, double defaultValue) {
/* 101 */     if (object == null) {
/* 102 */       return defaultValue;
/*     */     }
/* 104 */     if (object.getClass() == double.class || object.getClass() == Double.class) {
/* 105 */       return ((Long)object).longValue();
/*     */     }
/*     */     try {
/* 108 */       return Double.valueOf(object.toString()).doubleValue();
/* 109 */     } catch (Exception e) {
/* 110 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\NumberUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */