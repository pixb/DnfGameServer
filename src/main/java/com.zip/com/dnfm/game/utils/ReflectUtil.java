/*    */
package com.dnfm.game.utils;

/*    */
/*    */ import java.lang.reflect.Array;
/*    */ 
/*    */ public class ReflectUtil
/*    */ {
/*    */   public static Object newArray(Class<?> clazz, Class<?> wrapper, int size) {
/*  8 */     String name = clazz.getName();
/*  9 */     switch (name) {
/*    */       case "[Z":
/* 11 */         return new boolean[size];
/*    */       case "[B":
/* 13 */         return new byte[size];
/*    */       case "[C":
/* 15 */         return new char[size];
/*    */       case "[S":
/* 17 */         return new short[size];
/*    */       case "[I":
/* 19 */         return new int[size];
/*    */       case "[J":
/* 21 */         return new long[size];
/*    */       case "[F":
/* 23 */         return new float[size];
/*    */       case "D":
/* 25 */         return new double[size];
/*    */     } 
/* 27 */     return Array.newInstance(wrapper, size);
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\ReflectUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */