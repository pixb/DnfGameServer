/*     */
package com.dnfm.game.utils;

/*     */
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class BitSet {
/*   6 */   private final long[] BV = new long[32];
/*   7 */   private final Boolean[] bit = new Boolean[32];
/*     */   
/*     */   public BitSet(long i32) {
/*  10 */     initiate();
/*     */ 
/*     */ 
/*     */     
/*  14 */     set(i32);
/*     */   }
/*     */   
/*     */   public static com.dnfm.game.utils.BitSet NEW() {
/*  18 */     return new com.dnfm.game.utils.BitSet(0L);
/*     */   }
/*     */   
/*     */   private void initiate() {
/*  22 */     for (int i = 1; i <= 32; i++) {
/*  23 */       this.BV[i - 1] = (long)Math.pow(2.0D, (i - 1));
/*     */     }
/*     */   }
/*     */   
/*     */   private void setI32(int startPos, long i32) {
/*  28 */     for (int j = 1; j <= 32; j++) {
/*  29 */       int i = 33 - j - 1;
/*  30 */       if (i32 >= this.BV[i]) {
/*  31 */         this.bit[startPos + i] = Boolean.valueOf(true);
/*  32 */         i32 -= this.BV[i];
/*     */       } else {
/*  34 */         this.bit[startPos + i] = Boolean.valueOf(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set(long i32) {
/*  40 */     long[] nums = { i32 };
/*  41 */     int startPos = 0;
/*  42 */     for (long num : nums) {
/*  43 */       setI32(startPos, num);
/*  44 */       startPos += 32;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBit(int index, Boolean value) {
/*  50 */     if (index >= 32) {
/*  51 */       index -= 32;
/*     */     }
/*  53 */     if (index < 0 || index > this.bit.length) {
/*     */       return;
/*     */     }
/*  56 */     this.bit[index] = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBit(int index) {
/*  63 */     index--;
/*  64 */     if (index >= 32) {
/*  65 */       index -= 32;
/*     */     }
/*  67 */     if (index < 0 || index > this.bit.length) {
/*     */       return;
/*     */     }
/*  70 */     this.bit[index] = Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSet(int index) {
/*  75 */     if (index < 0 || index > this.bit.length) {
/*  76 */       return false;
/*     */     }
/*  78 */     return this.bit[index].booleanValue();
/*     */   }
/*     */   
/*     */   public int getI32() {
/*  82 */     int i32 = 0;
/*  83 */     int i = 0;
/*  84 */     for (Boolean boo : this.bit) {
/*  85 */       if (boo != null && 
/*  86 */         boo.booleanValue()) {
/*  87 */         i32 = (int)(i32 + this.BV[i]);
/*     */       }
/*     */       
/*  90 */       i++;
/*     */     } 
/*  92 */     return i32;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  97 */     if (this == o) return true; 
/*  98 */     if (o == null || getClass() != o.getClass()) return false; 
/*  99 */     com.dnfm.game.utils.BitSet bitSet = (com.dnfm.game.utils.BitSet)o;
/* 100 */     return Arrays.equals(this.BV, bitSet.BV);
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\BitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */