/*    */
package com.dnfm.game.utils;

/*    */
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringUtil
/*    */ {
/*    */   public static final String Empty = "";
/*    */   
/*    */   public static boolean isEmpty(String... args) {
/* 16 */     if (args != null && args.length > 0) {
/* 17 */       for (String s : args) {
/* 18 */         if (s == null || s.trim().length() < 1) {
/* 19 */           return true;
/*    */         }
/*    */       } 
/*    */       
/* 23 */       return false;
/*    */     } 
/*    */     
/* 26 */     return true;
/*    */   }
/*    */   
/*    */   public static String RandomString(int length) {
/* 30 */     String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/* 31 */     Random random = new Random();
/* 32 */     StringBuilder builder = new StringBuilder();
/* 33 */     for (int i = 0; i < length; i++) {
/* 34 */       int num = random.nextInt(62);
/* 35 */       builder.append(str.charAt(num));
/*    */     } 
/* 37 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\StringUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */