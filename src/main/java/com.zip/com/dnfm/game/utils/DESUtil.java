/*     */
package com.dnfm.game.utils;

/*     */
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DESUtil
/*     */ {
/*     */   private static final String ASCII = "ASCII";
/*     */   private static final String UTF8 = "UTF-8";
/*     */   private String keys;
/*     */   
/*     */   public DESUtil() {}
/*     */   
/*     */   public DESUtil(String keys) {
/*  19 */     this.keys = keys;
/*     */   }
/*     */   
/*     */   public String getKeys() {
/*  23 */     return this.keys;
/*     */   }
/*     */   
/*     */   public void setKeys(String keys) {
/*  27 */     this.keys = keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] desEncrypt(byte[] plainText) throws Exception {
/*  40 */     IvParameterSpec zeroIv = new IvParameterSpec(this.keys.getBytes(StandardCharsets.US_ASCII));
/*  41 */     SecretKeySpec key = new SecretKeySpec(this.keys.getBytes(StandardCharsets.US_ASCII), "DES");
/*  42 */     Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
/*  43 */     cipher.init(1, key, zeroIv);
/*  44 */     return cipher.doFinal(plainText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] desDecrypt(byte[] encryptText) throws Exception {
/*  57 */     IvParameterSpec zeroIv = new IvParameterSpec(this.keys.getBytes(StandardCharsets.US_ASCII));
/*  58 */     SecretKeySpec skey = new SecretKeySpec(this.keys.getBytes(StandardCharsets.US_ASCII), "DES");
/*  59 */     Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
/*  60 */     cipher.init(2, skey, zeroIv);
/*  61 */     return cipher.doFinal(encryptText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encrypt(String input) throws Exception {
/*  72 */     return parseByte2HexStr(desEncrypt(input.getBytes(StandardCharsets.UTF_8)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decrypt(String input) throws Exception {
/*  83 */     byte[] result = parseHexStr2Byte(input);
/*  84 */     return new String(desDecrypt(result), StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] parseHexStr2Byte(String hexStr) {
/*  94 */     if (hexStr.length() < 1) {
/*  95 */       return null;
/*     */     }
/*  97 */     byte[] result = new byte[hexStr.length() / 2];
/*  98 */     for (int i = 0; i < hexStr.length() / 2; i++) {
/*  99 */       int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
/* 100 */       int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
/* 101 */       result[i] = (byte)(high * 16 + low);
/*     */     } 
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parseByte2HexStr(byte[] buf) {
/* 113 */     StringBuilder sb = new StringBuilder();
/* 114 */     for (byte b : buf) {
/* 115 */       String hex = Integer.toHexString(b & 0xFF);
/* 116 */       if (hex.length() == 1) {
/* 117 */         hex = '0' + hex;
/*     */       }
/* 119 */       sb.append(hex.toUpperCase());
/*     */     } 
/* 121 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\DESUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */