/*     */
package com.dnfm.game.utils;

/*     */

import com.dnfm.game.utils.TimeUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;

/*     */
/*     */ public class DateUtils {
    /*     */
    public static String dayForWeek(Date tmpDate) {
        /*   9 */
        Calendar cal = Calendar.getInstance();
        /*  10 */
        String[] weekDays = {"7", "1", "2", "3", "4", "5", "6"};
        /*     */
        try {
            /*  12 */
            cal.setTime(tmpDate);
            /*  13 */
        } catch (Exception exception) {
        }
        /*     */
        /*     */
        /*  16 */
        int w = cal.get(7) - 1;
        /*  17 */
        if (w < 0)
            /*  18 */ w = 0;
        /*  19 */
        return weekDays[w];
        /*     */
    }

    /*     */
    /*     */
    public static String formatDate(Date date) {
        /*  23 */
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        /*  24 */
        return simpleDateFormat.format(date);
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static Date getAfterDayEndDate(int days) {
        /*  33 */
        Calendar canlendar = Calendar.getInstance();
        /*  34 */
        canlendar.add(5, days);
        /*  35 */
        canlendar.set(11, 23);
        /*  36 */
        canlendar.set(12, 59);
        /*  37 */
        canlendar.set(13, 59);
        /*  38 */
        Date date = canlendar.getTime();
        /*     */
        /*  40 */
        return date;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static int getDaysBetween(long beginTime) {
        /*  50 */
        Calendar aCalendar = Calendar.getInstance();
        /*     */
        /*  52 */
        aCalendar.set(11, 0);
        /*  53 */
        aCalendar.set(12, 0);
        /*  54 */
        aCalendar.set(13, 0);
        /*  55 */
        aCalendar.set(14, 0);
        /*     */
        /*     */
        /*  58 */
        Calendar bCalendar = Calendar.getInstance();
        /*  59 */
        bCalendar.setTime(new Date(beginTime));
        /*  60 */
        bCalendar.set(11, 0);
        /*  61 */
        bCalendar.set(12, 0);
        /*  62 */
        bCalendar.set(13, 0);
        /*  63 */
        bCalendar.set(14, 0);
        /*     */
        /*     */
        /*  66 */
        int days = 0;
        /*  67 */
        while (aCalendar.before(bCalendar)) {
            /*  68 */
            days--;
            /*  69 */
            aCalendar.add(6, 1);
            /*     */
        }
        /*  71 */
        while (bCalendar.before(aCalendar)) {
            /*  72 */
            days++;
            /*  73 */
            bCalendar.add(6, 1);
            /*     */
        }
        /*     */
        /*  76 */
        return days;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static Date getToDaySixDate() {
        /*  84 */
        Calendar canlendar = Calendar.getInstance();
        /*  85 */
        canlendar.set(11, 6);
        /*  86 */
        canlendar.set(12, 0);
        /*  87 */
        canlendar.set(13, 0);
        /*  88 */
        Date date = canlendar.getTime();
        /*     */
        /*  90 */
        return date;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static Date getYesterdaySixDate() {
        /*  98 */
        Calendar canlendar = Calendar.getInstance();
        /*  99 */
        canlendar.add(5, -1);
        /* 100 */
        canlendar.set(11, 6);
        /* 101 */
        canlendar.set(12, 0);
        /* 102 */
        canlendar.set(13, 0);
        /* 103 */
        Date date = canlendar.getTime();
        /*     */
        /* 105 */
        return date;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    /*     */
    public static Date getToDayBeginDate() {
        /* 113 */
        Calendar canlendar = Calendar.getInstance();
        /* 114 */
        canlendar.set(11, 0);
        /* 115 */
        canlendar.set(12, 0);
        /* 116 */
        canlendar.set(13, 0);
        /* 117 */
        Date date = canlendar.getTime();
        /*     */
        /* 119 */
        return date;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public static void main(String[] args) {
        /* 124 */
        System.out.println(getAfterDayEndDate(30).getTime());
        /*     */
        /* 126 */
        System.out.println(getDaysBetween(1681658377000L));
        /*     */
        /* 128 */
        System.out.println(getToDayBeginDate().getTime() / 1000L);
        /*     */
        /* 130 */
        long toDaySixTime = getToDaySixDate().getTime() / 1000L;
        /* 131 */
        long YesterDaySixDate = getYesterdaySixDate().getTime() / 1000L;
        /* 132 */
        System.out.println(YesterDaySixDate);
        /* 133 */
        long lastLogoutTime = 1680020034L;
        /* 134 */
        if (lastLogoutTime < YesterDaySixDate || (TimeUtil.currS() > toDaySixTime && toDaySixTime > lastLogoutTime))
            /* 135 */ System.out.println("重置");
        /*     */
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\DateUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */