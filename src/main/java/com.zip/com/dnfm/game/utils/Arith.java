/*     */
package com.dnfm.game.utils;

/*     */
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Arith
/*     */ {
/*     */   private static final int DEF_DIV_SCALE = 20;
/*     */   
/*     */   public static double add(double v1, double v2) {
/*  34 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/*     */     
/*  36 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/*     */     
/*  38 */     return b1.add(b2).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double sub(double v1, double v2) {
/*  52 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/*     */     
/*  54 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/*     */     
/*  56 */     return b1.subtract(b2).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double mul(double v1, double v2) {
/*  70 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/*     */     
/*  72 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/*     */     
/*  74 */     return b1.multiply(b2).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double div(double v1, double v2) {
/*  91 */     return div(v1, v2, 20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double div(double v1, double v2, int scale) {
/* 109 */     if (scale < 0)
/*     */     {
/* 111 */       throw new IllegalArgumentException("The scale must be a positive integer or zero");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     BigDecimal b1 = new BigDecimal(Double.toString(v1));
/*     */     
/* 119 */     BigDecimal b2 = new BigDecimal(Double.toString(v2));
/*     */     
/* 121 */     return b1.divide(b2, scale, 4).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double round(double v, int scale) {
/* 136 */     if (scale < 0)
/*     */     {
/* 138 */       throw new IllegalArgumentException("The scale must be a positive integer or zero");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     BigDecimal b = new BigDecimal(Double.toString(v));
/*     */     
/* 146 */     BigDecimal one = new BigDecimal("1");
/*     */     
/* 148 */     return b.divide(one, scale, 4).doubleValue();
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\Arith.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */