package com.dnfm.game.utils;

public interface PrivilegeConst {
  public static final int admin = 1000;
  
  public static final int GM = 200;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\gam\\utils\PrivilegeConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */