package com.dnfm.game.utils;

import java.util.HashSet;
import java.util.Set;

public interface ProtocalSet {
    Set<Integer> loginSet = new HashSet<>();
    Set<Integer> ignoreSet = new HashSet<>();
}