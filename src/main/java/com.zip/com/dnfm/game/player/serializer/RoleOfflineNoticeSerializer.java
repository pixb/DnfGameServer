package com.dnfm.game.player.serializer;

import com.dnfm.game.player.serializer.IPlayerPropSerializer;
import com.dnfm.game.role.model.Role;

public class RoleOfflineNoticeSerializer implements IPlayerPropSerializer {
  public void serialize(Role player) {}
  
  public void deserialize(Role player) {}
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\player\serializer\RoleOfflineNoticeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */