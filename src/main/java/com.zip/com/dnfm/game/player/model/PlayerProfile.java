package com.dnfm.game.player.model;

import com.dnfm.game.role.model.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlayerProfile implements Serializable {
    private String openid;
    private int roleId;
    private long uid;
    private String name;
    private String distName;
    private int exp;
    private int level;
    private int job;
    private int fatigue;

    public PlayerProfile(Role role) {
        this.openid = role.getOpenid();
        this.roleId = role.getRoleId();
        this.uid = role.getUid();
        this.name = role.getName();
        this.distName = role.getDistName();
        this.exp = role.getExp();
        this.level = role.getLevel();
        this.job = role.getJob();
        this.fatigue = role.getFatigue();
    }
}