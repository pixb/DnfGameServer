package com.dnfm.game.player.model;

import lombok.Data;

import java.util.List;
@Data
public class AccountProfile {
    private String sid;
    private List<PlayerProfile> players;
}