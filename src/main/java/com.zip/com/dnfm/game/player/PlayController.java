/*    */
package com.dnfm.game.player;

/*    */
/*    */ import com.dnfm.game.player.PlayerService;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.EventType;
/*    */ import com.dnfm.listener.annotation.EventHandler;
/*    */ import com.dnfm.listener.event.LoginEvent;
/*    */ import com.dnfm.listener.event.LogoutEvent;
/*    */ import com.dnfm.listener.event.RoleLevelUpEvent;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Controller;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Controller
/*    */ public class PlayController
/*    */ {
/*    */   @Autowired
/*    */   PlayerService playerService;
/*    */   
/*    */   @EventHandler({EventType.ROLE_LEVEL_UP})
/*    */   public void handleRoleLevelUpEvent(RoleLevelUpEvent roleLevelUpEvent) {
/* 23 */     Role role = roleLevelUpEvent.getRole();
/* 24 */     this.playerService.updateRoleLevel(role);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler({EventType.LOGIN})
/*    */   public void handleLoginEvent(LoginEvent loginEvent) {
/* 32 */     Role role = loginEvent.getRole();
/* 33 */     this.playerService.updateRoleEnterTime(role);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler({EventType.LOGOUT})
/*    */   public void handleLogoutEvent(LogoutEvent logoutEvent) {
/* 41 */     Role role = logoutEvent.getRole();
/* 42 */     this.playerService.updatePlayerProfile(role);
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\player\PlayController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */