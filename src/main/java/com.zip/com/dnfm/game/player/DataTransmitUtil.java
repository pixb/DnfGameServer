/*    */
package com.dnfm.game.player;

/*    */
/*    */ import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.game.player.model.PlayerProfile;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.logs.LoggerUtils;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataTransmitUtil
/*    */ {
/*    */   public static void transmitPlayer(Role role) {
/* 16 */     LoggerUtils.error("数据迁移玩家[{}]=[{}]", new Object[] { Long.valueOf(role.getUid()), role.getName() });
/* 17 */     role.save();
/*    */   }
/*    */   
/*    */   public static void beginTransmit() {
/*    */     try {
/* 22 */       for (Map.Entry<Long, PlayerProfile> entry : (Iterable<Map.Entry<Long, PlayerProfile>>)SpringUtils.getPlayerService().getAllPlayerProfiles().entrySet()) {
/* 23 */         long playerId = ((Long)entry.getKey()).longValue();
/* 24 */         Role role = SpringUtils.getPlayerService().getPlayerBy(playerId);
/* 25 */         transmitPlayer(role);
/* 26 */         Thread.sleep(100L);
/*    */       } 
/* 28 */     } catch (Exception e) {
/* 29 */       LoggerUtils.error("", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\player\DataTransmitUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */