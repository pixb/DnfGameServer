/*    */
package com.dnfm.game.player.serializer;

/*    */
/*    */ import com.dnfm.game.player.serializer.IPlayerPropSerializer;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.game.utils.ClassScanner;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class PlayerSerializerUtil
/*    */ {
/*    */   private static final String SCAN_PATH = "com.dnfm.game";
/* 13 */   private static final List<IPlayerPropSerializer> propSerializers = new ArrayList<>();
/*    */   
/*    */   static {
/* 16 */     Set<Class<?>> handler = ClassScanner.listAllSubclasses("com.dnfm.game", IPlayerPropSerializer.class);
/* 17 */     for (Class<?> clazz : handler) {
/*    */       try {
/* 19 */         propSerializers.add((IPlayerPropSerializer)clazz.newInstance());
/* 20 */       } catch (Exception e) {
/*    */         
/* 22 */         System.exit(1);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void serialize(Role player) {
/* 28 */     for (IPlayerPropSerializer handler : propSerializers) {
/* 29 */       handler.serialize(player);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void deserialize(Role player) {
/* 34 */     for (IPlayerPropSerializer handler : propSerializers)
/* 35 */       handler.deserialize(player); 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\player\serializer\PlayerSerializerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */