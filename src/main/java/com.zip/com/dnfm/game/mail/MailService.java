/*    */
package com.dnfm.game.mail;

/*    */
/*    */ import com.dnfm.game.bag.service.BagService;
/*    */ import com.dnfm.game.equip.service.EquipService;
/*    */ import com.dnfm.game.role.service.RoleService;
/*    */ import com.dnfm.listener.EventType;
/*    */ import com.dnfm.listener.annotation.EventHandler;
/*    */ import com.dnfm.listener.event.LoginEvent;
/*    */ import com.dnfm.logs.LoggerFunction;
/*    */ import java.util.ArrayList;
/*    */ import org.nutz.dao.Dao;
/*    */ import org.nutz.lang.util.NutMap;
/*    */ import org.slf4j.Logger;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service
/*    */ public class MailService
/*    */ {
/*    */   @Autowired
/*    */   Dao dao;
/*    */   @Autowired
/*    */   RoleService roleService;
/*    */   @Autowired
/*    */   BagService bagService;
/*    */   @Autowired
/*    */   EquipService equipService;
/* 33 */   private final Logger logger = LoggerFunction.MAIL.getLogger();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler({EventType.LOGIN})
/*    */   public void handleLoginEvent(LoginEvent loginEvent) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String getMailItemString(ArrayList<NutMap> maps) {
/* 80 */     StringBuilder stringBuilder = new StringBuilder();
/* 81 */     if (maps != null) {
/* 82 */       for (NutMap nutMap : maps) {
/* 83 */         stringBuilder.append(nutMap.getString("data"));
/*    */       }
/*    */     }
/* 86 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\mail\MailService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */