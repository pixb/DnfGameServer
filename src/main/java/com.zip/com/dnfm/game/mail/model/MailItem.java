package com.dnfm.game.mail.model;

public class MailItem {
    public Integer index;

    public Integer cnt;
}