/*    */
package com.dnfm.game.mail.model;

/*    */
/*    */ import com.dnfm.mina.protobuf.PT_POST_ALL_LIST;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.nutz.lang.util.NutMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mails
/*    */ {
/*    */   private int count;
/*    */   private List<PT_POST_ALL_LIST> postallist;
/*    */   private ArrayList<NutMap> datas;
/*    */   
/*    */   public int getCount() {
/* 18 */     return this.count;
/*    */   }
/*    */   
/*    */   public void setCount(int count) {
/* 22 */     this.count = count;
/*    */   }
/*    */   
/*    */   public List<PT_POST_ALL_LIST> getPostallist() {
/* 26 */     return this.postallist;
/*    */   }
/*    */   
/*    */   public void setPostallist(List<PT_POST_ALL_LIST> postallist) {
/* 30 */     this.postallist = postallist;
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<NutMap> getDatas() {
/* 35 */     return this.datas;
/*    */   }
/*    */   
/*    */   public void setDatas(ArrayList<NutMap> datas) {
/* 39 */     this.datas = datas;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\mail\model\Mails.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */