package com.dnfm.game.chat;

import com.alibaba.fastjson.JSON;
import com.dnfm.common.utils.Util;
import com.dnfm.game.chat.model.ChatCache;
import com.dnfm.game.chat.service.ChatService;
import com.dnfm.game.mail.model.MailItem;
import com.dnfm.game.role.model.Account;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.AccountService;
import com.dnfm.game.utils.TimeUtil;
import com.dnfm.mina.annotation.RequestMapping;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.Message;
import com.dnfm.mina.protobuf.PT_CHAT;
import com.dnfm.mina.protobuf.PT_CHAT_SYNC;
import com.dnfm.mina.protobuf.PT_CHAT_SYNC_INFO;
import com.dnfm.mina.protobuf.PT_SKIN_CHAT_INFO;
import com.dnfm.mina.protobuf.REQ_NOTE_MESSENGER_ADD_USER;
import com.dnfm.mina.protobuf.REQ_TOWN_CHAT;
import com.dnfm.mina.protobuf.REQ_TOWN_CHAT_LIST;
import com.dnfm.mina.protobuf.RES_NOTE_MESSENGER_ADD_USER;
import com.dnfm.mina.protobuf.RES_TOWN_CHAT;
import com.dnfm.mina.protobuf.RES_TOWN_CHAT_LIST;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {
    private static final Logger log = LoggerFactory.getLogger(com.dnfm.game.chat.ChatController.class);

    @Autowired
    AccountService accountService;

    @Autowired
    ChatService chatService;

    @RequestMapping
    public void ReqTownChat(IoSession session, REQ_TOWN_CHAT reqTownChat) {
        String chatText = reqTownChat.voice;
        Role role = SessionUtils.getRoleBySession(session);
        if (role.getWordTime() > 0L) {
            RES_TOWN_CHAT res_town_chat = new RES_TOWN_CHAT();
            res_town_chat.error = Integer.valueOf(1);
            res_town_chat.transId = reqTownChat.transId;
            MessagePusher.pushMessage(session, (Message)res_town_chat);
            return;
        }
        Account account = SessionUtils.getAccountBySession(session);
        int type = 0;
        if (reqTownChat.type != null)
            type = reqTownChat.type.intValue();
        log.error("account.getUserID====={}", account.getUserID() + "");
        if (chatText.contains("@") && account.getPrivilege() >= 10) {
            String errorText = null;
            if (chatText.contains("==")) {
                String[] itemStrArr = chatText.split("==");
                String title = "发送单个物品[测试专用]";
                String msg = "发送单个物品[测试专用]--请查收";
                List<MailItem> list = new ArrayList<>();
                String userID = null;
                for (String itemStr : itemStrArr) {
                    String[] itemArr = itemStr.split("@");
                    if (userID == null)
                        userID = itemArr[0];
                    int index = Integer.parseInt(itemArr[1]);
                    int count = Integer.parseInt(itemArr[2]);
                    MailItem mailItem = new MailItem();
                    mailItem.index = Integer.valueOf(index);
                    mailItem.cnt = Integer.valueOf(count);
                    list.add(mailItem);
                }
                role.getMailBox().addMail(title, msg, list);
                role.save();
            } else {
                String title = "批量发送物品[测试专用]";
                String msg = "批量发送物品[测试专用]--请查收";
                String[] itemArr = chatText.split("@");
                String userID = account.getUserID();
                int index = Integer.parseInt(itemArr[1]);
                int count = Integer.parseInt(itemArr[2]);
                List<MailItem> list = new ArrayList<>();
                MailItem mailItem = new MailItem();
                mailItem.index = Integer.valueOf(index);
                mailItem.cnt = Integer.valueOf(count);
                log.error("add==userID=={}==mailItem=={}", userID, JSON.toJSON(mailItem));
                list.add(mailItem);
                role.getMailBox().addMail(title, msg, list);
                role.save();
            }
            RES_TOWN_CHAT res_town_chat = new RES_TOWN_CHAT();
            res_town_chat.charguid = Long.valueOf(role.getUid());
            if (role.getJob() != 0)
                res_town_chat.job = Integer.valueOf(role.getJob());
            if (role.getGrowtype() != 0)
                res_town_chat.growtype = Integer.valueOf(role.getGrowtype());
            if (role.getSecgrowtype() != 0)
                res_town_chat.secgrowtype = Integer.valueOf(role.getSecgrowtype());
            res_town_chat.level = Integer.valueOf(role.getLevel());
            res_town_chat.sender = role.getName();
            if (Util.isEmpty(errorText)) {
                res_town_chat.chat = chatText;
            } else {
                res_town_chat.chat = errorText;
            }
            res_town_chat.skinchatinfo = new PT_SKIN_CHAT_INFO();
            res_town_chat.date = Long.valueOf(TimeUtil.currS());
            res_town_chat.creditscore = Integer.valueOf(351);
            res_town_chat.transId = reqTownChat.transId;
            MessagePusher.pushMessage(session, (Message)res_town_chat);
        } else if (type == 0) {
            PT_CHAT pt_chat = ChatCache.addTownChat(chatText, role);
            RES_TOWN_CHAT res_town_chat = new RES_TOWN_CHAT();
            res_town_chat.charguid = pt_chat.charguid;
            res_town_chat.job = pt_chat.job;
            res_town_chat.growtype = pt_chat.growtype;
            res_town_chat.secgrowtype = pt_chat.secgrowtype;
            res_town_chat.level = pt_chat.level;
            res_town_chat.sender = pt_chat.sender;
            res_town_chat.chat = pt_chat.chat;
            res_town_chat.skinchatinfo = pt_chat.skinchatinfo;
            res_town_chat.date = pt_chat.date;
            res_town_chat.creditscore = pt_chat.creditscore;
            res_town_chat.transId = reqTownChat.transId;
            MessagePusher.pushMessage(session, (Message)res_town_chat);
        } else {
            PT_CHAT pt_chat = ChatCache.addChat(type, chatText, role);
            RES_TOWN_CHAT res_town_chat = new RES_TOWN_CHAT();
            res_town_chat.type = Integer.valueOf(type);
            res_town_chat.charguid = pt_chat.charguid;
            res_town_chat.job = pt_chat.job;
            res_town_chat.growtype = pt_chat.growtype;
            res_town_chat.secgrowtype = pt_chat.secgrowtype;
            res_town_chat.level = pt_chat.level;
            res_town_chat.sender = pt_chat.sender;
            res_town_chat.chat = pt_chat.chat;
            res_town_chat.skinchatinfo = pt_chat.skinchatinfo;
            res_town_chat.date = pt_chat.date;
            res_town_chat.creditscore = pt_chat.creditscore;
            res_town_chat.transId = reqTownChat.transId;
            if (type == 5);
            MessagePusher.pushMessage(session, (Message)res_town_chat);
        }
    }

    @RequestMapping
    public void ReqTownChatList(IoSession session, REQ_TOWN_CHAT_LIST reqTownChatList) {
        List<PT_CHAT_SYNC> chat = reqTownChatList.chat;
        Role role = SessionUtils.getRoleBySession(session);
        if (chat != null) {
            int type = ((PT_CHAT_SYNC)chat.get(0)).type.intValue();
            long index = 0L;
            if (((PT_CHAT_SYNC)chat.get(0)).index != null)
                index = ((PT_CHAT_SYNC)chat.get(0)).index.longValue();
            if (type == 1) {
                RES_TOWN_CHAT_LIST resTownChatList = new RES_TOWN_CHAT_LIST();
                resTownChatList.chat = new ArrayList();
                PT_CHAT_SYNC_INFO ptChatSyncInfo = new PT_CHAT_SYNC_INFO();
                ptChatSyncInfo.type = Integer.valueOf(1);
                List<PT_CHAT> chatMsg = (List<PT_CHAT>)((Map)ChatCache.chatMsgMap.get(Integer.valueOf(1))).get(Long.valueOf(index));
                if (!Util.isEmpty(chatMsg)) {
                    ptChatSyncInfo.totalcount = Long.valueOf(chatMsg.size());
                    ptChatSyncInfo.chatmsg = chatMsg;
                    ptChatSyncInfo.lastindex = Long.valueOf(((Long)ChatCache.lastIndexMap.get(Integer.valueOf(1))).longValue() + chatMsg.size());
                    ChatCache.lastIndexMap.put(Integer.valueOf(1), ptChatSyncInfo.lastindex);
                } else {
                    ptChatSyncInfo.lastindex = (Long)ChatCache.lastIndexMap.get(Integer.valueOf(1));
                }
                resTownChatList.chat.add(ptChatSyncInfo);
                resTownChatList.interval = Integer.valueOf(3000);
                resTownChatList.transId = reqTownChatList.transId;
                MessagePusher.pushMessage(session, (Message)resTownChatList);
            } else if (type == 2) {
                RES_TOWN_CHAT_LIST resTownChatList = new RES_TOWN_CHAT_LIST();
                resTownChatList.chat = new ArrayList();
                PT_CHAT_SYNC_INFO ptChatSyncInfo = new PT_CHAT_SYNC_INFO();
                ptChatSyncInfo.type = Integer.valueOf(2);
                String key = role.getPos().getTown() + "_" + role.getPos().getArea();
                Map<Long, List<PT_CHAT>> chatMsgMap = (Map<Long, List<PT_CHAT>>)ChatCache.townChatMsgMap.get(key);
                if (chatMsgMap == null)
                    chatMsgMap = new ConcurrentHashMap<>();
                List<PT_CHAT> chatMsg = chatMsgMap.get(Long.valueOf(index));
                if (!Util.isEmpty(chatMsg)) {
                    ptChatSyncInfo.totalcount = Long.valueOf(chatMsg.size());
                    ptChatSyncInfo.chatmsg = chatMsg;
                    ptChatSyncInfo.lastindex = Long.valueOf(((Long)ChatCache.lastIndexMap.get(Integer.valueOf(2))).longValue() + chatMsg.size());
                    ChatCache.lastIndexMap.put(Integer.valueOf(2), ptChatSyncInfo.lastindex);
                } else {
                    ptChatSyncInfo.lastindex = (Long)ChatCache.lastIndexMap.get(Integer.valueOf(2));
                }
                resTownChatList.chat.add(ptChatSyncInfo);
                resTownChatList.interval = Integer.valueOf(3000);
                resTownChatList.transId = reqTownChatList.transId;
                MessagePusher.pushMessage(session, (Message)resTownChatList);
                RES_TOWN_CHAT_LIST resTownChatList2 = new RES_TOWN_CHAT_LIST();
                resTownChatList2.chat = new ArrayList();
                PT_CHAT_SYNC_INFO ptChatSyncInfo2 = new PT_CHAT_SYNC_INFO();
                ptChatSyncInfo2.type = Integer.valueOf(2);
                List<PT_CHAT> chatNoticeList = (List<PT_CHAT>)((Map)ChatCache.chatMsgMap.get(Integer.valueOf(200))).get(Long.valueOf(index));
                if (!Util.isEmpty(chatNoticeList)) {
                    ptChatSyncInfo2.totalcount = Long.valueOf(chatNoticeList.size());
                    ptChatSyncInfo2.chatmsg = chatNoticeList;
                    ptChatSyncInfo2.lastindex = Long.valueOf(((Long)ChatCache.lastIndexMap.get(Integer.valueOf(200))).longValue() + chatNoticeList.size());
                    ChatCache.lastIndexMap.put(Integer.valueOf(200), ptChatSyncInfo2.lastindex);
                } else {
                    ptChatSyncInfo2.lastindex = (Long)ChatCache.lastIndexMap.get(Integer.valueOf(200));
                    return;
                }
                resTownChatList2.chat.add(ptChatSyncInfo2);
                resTownChatList2.interval = Integer.valueOf(3000);
                resTownChatList2.transId = reqTownChatList.transId;
                MessagePusher.pushMessage(session, (Message)resTownChatList2);
            } else if (type == 4) {
                RES_TOWN_CHAT_LIST resTownChatList = new RES_TOWN_CHAT_LIST();
                resTownChatList.chat = new ArrayList();
                PT_CHAT_SYNC_INFO ptChatSyncInfo = new PT_CHAT_SYNC_INFO();
                ptChatSyncInfo.lastindex = Long.valueOf(1L);
                ptChatSyncInfo.type = Integer.valueOf(4);
                resTownChatList.chat.add(ptChatSyncInfo);
                resTownChatList.interval = Integer.valueOf(3000);
                resTownChatList.transId = reqTownChatList.transId;
                MessagePusher.pushMessage(session, (Message)resTownChatList);
            }
        }
    }

    @RequestMapping
    public void reqNoteMessengerAddUser(IoSession session, REQ_NOTE_MESSENGER_ADD_USER reqNoteMessengerAddUser) {
        Role role = SessionUtils.getRoleBySession(session);
        RES_NOTE_MESSENGER_ADD_USER resNoteMessengerAddUser = this.chatService.userMsg(role, reqNoteMessengerAddUser.targetguid.longValue());
        MessagePusher.pushMessage(session, (Message)resNoteMessengerAddUser);
    }
}
