/*     */
package com.dnfm.game.chat.model;

/*     */
/*     */

import com.dnfm.game.role.model.Role;
/*     */ import com.dnfm.game.utils.TimeUtil;
/*     */ import com.dnfm.mina.protobuf.PT_CHAT;
/*     */ import com.dnfm.mina.protobuf.PT_EQUIP;
/*     */ import com.dnfm.mina.protobuf.PT_HYPERLINK_SYSTEMMESSAGE_SUB;
/*     */ import com.dnfm.mina.protobuf.PT_SKIN_CHAT_INFO;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;

/*     */
/*     */ public class ChatCache
        /*     */ {
    /*  18 */   private static final Logger log = LoggerFactory.getLogger(com.dnfm.game.chat.model.ChatCache.class);
    /*     */
    /*     */   public static final int CHAT_WORLD = 1;
    /*     */
    /*     */   public static final int CHAT_TOWN = 2;
    /*     */
    /*     */   public static final int CHAT_NOTICE = 200;
    /*  25 */   public static Map<Integer, Map<Long, List<PT_CHAT>>> chatMsgMap = new ConcurrentHashMap<>();
    /*     */
    /*     */
    /*  28 */   public static Map<String, Map<Long, List<PT_CHAT>>> townChatMsgMap = new ConcurrentHashMap<>();
    /*     */
    /*  30 */   public static Map<Integer, Long> lastIndexMap = new ConcurrentHashMap<>();

    /*     */
    /*     */   static {
        /*  33 */
        chatMsgMap.put(Integer.valueOf(1), new ConcurrentHashMap<>());
        /*  34 */
        chatMsgMap.put(Integer.valueOf(200), new ConcurrentHashMap<>());
        /*     */
        /*  36 */
        lastIndexMap.put(Integer.valueOf(1), Long.valueOf(0L));
        /*  37 */
        lastIndexMap.put(Integer.valueOf(2), Long.valueOf(0L));
        /*  38 */
        lastIndexMap.put(Integer.valueOf(200), Long.valueOf(0L));
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public static PT_CHAT addTownChat(String text, Role role) {
        /*  43 */
        long index = ((Long) lastIndexMap.get(Integer.valueOf(2))).longValue();
        /*  44 */
        int town = role.getPos().getTown();
        /*  45 */
        int area = role.getPos().getArea();
        /*  46 */
        String key = town + "_" + area;
        /*  47 */
        PT_CHAT pt_chat = new PT_CHAT();
        /*  48 */
        pt_chat.charguid = Long.valueOf(role.getUid());
        /*  49 */
        if (role.getJob() != 0) {
            /*  50 */
            pt_chat.job = Integer.valueOf(role.getJob());
            /*     */
        }
        /*  52 */
        if (role.getGrowtype() != 0) {
            /*  53 */
            pt_chat.growtype = Integer.valueOf(role.getGrowtype());
            /*     */
        }
        /*  55 */
        if (role.getSecgrowtype() != 0) {
            /*  56 */
            pt_chat.secgrowtype = Integer.valueOf(role.getSecgrowtype());
            /*     */
        }
        /*  58 */
        pt_chat.level = Integer.valueOf(role.getLevel());
        /*  59 */
        pt_chat.sender = role.getName();
        /*  60 */
        pt_chat.chat = text;
        /*     */
        /*  62 */
        pt_chat.skinchatinfo = new PT_SKIN_CHAT_INFO();
        /*  63 */
        pt_chat.date = Long.valueOf(TimeUtil.currS());
        /*  64 */
        pt_chat.creditscore = Integer.valueOf(351);
        /*     */
        /*  66 */
        Map<Long, List<PT_CHAT>> listMap = townChatMsgMap.get(key);
        /*  67 */
        if (listMap == null) {
            /*  68 */
            listMap = new ConcurrentHashMap<>();
            /*     */
        }
        /*  70 */
        List<PT_CHAT> list = listMap.get(Long.valueOf(index));
        /*  71 */
        if (list == null) {
            /*  72 */
            list = new ArrayList<>();
            /*     */
        }
        /*  74 */
        list.add(pt_chat);
        /*  75 */
        listMap.put(Long.valueOf(index), list);
        /*  76 */
        townChatMsgMap.put(key, listMap);
        /*     */
        /*  78 */
        return pt_chat;
        /*     */
    }

    /*     */
    /*     */
    public static PT_CHAT addChat(int type, String text, Role role) {
        /*  82 */
        if (type == 0) {
            /*  83 */
            log.error("UNREACH==addChat.type=" + type);
            /*  84 */
            return null;
            /*  85 */
        }
        if (type == 5) {
            /*  86 */
            long index = ((Long) lastIndexMap.get(Integer.valueOf(1))).longValue();
            /*     */
            /*  88 */
            PT_CHAT pt_chat = new PT_CHAT();
            /*  89 */
            pt_chat.type = Integer.valueOf(5);
            /*  90 */
            pt_chat.charguid = Long.valueOf(role.getUid());
            /*  91 */
            if (role.getJob() != 0) {
                /*  92 */
                pt_chat.job = Integer.valueOf(role.getJob());
                /*     */
            }
            /*  94 */
            if (role.getGrowtype() != 0) {
                /*  95 */
                pt_chat.growtype = Integer.valueOf(role.getGrowtype());
                /*     */
            }
            /*  97 */
            if (role.getSecgrowtype() != 0) {
                /*  98 */
                pt_chat.secgrowtype = Integer.valueOf(role.getSecgrowtype());
                /*     */
            }
            /* 100 */
            pt_chat.level = Integer.valueOf(role.getLevel());
            /* 101 */
            pt_chat.sender = role.getName();
            /* 102 */
            pt_chat.chat = text;
            /*     */
            /* 104 */
            pt_chat.skinchatinfo = new PT_SKIN_CHAT_INFO();
            /* 105 */
            pt_chat.date = Long.valueOf(TimeUtil.currS());
            /* 106 */
            pt_chat.creditscore = Integer.valueOf(351);
            /*     */
            /* 108 */
            Map<Long, List<PT_CHAT>> listMap = chatMsgMap.get(Integer.valueOf(1));
            /* 109 */
            if (listMap == null) {
                /* 110 */
                listMap = new ConcurrentHashMap<>();
                /*     */
            }
            /* 112 */
            List<PT_CHAT> list = listMap.get(Long.valueOf(index));
            /* 113 */
            if (list == null) {
                /* 114 */
                list = new ArrayList<>();
                /*     */
            }
            /* 116 */
            list.add(pt_chat);
            /* 117 */
            listMap.put(Long.valueOf(index), list);
            /* 118 */
            chatMsgMap.put(Integer.valueOf(1), listMap);
            /*     */
            /* 120 */
            return pt_chat;
            /*     */
        }
        /*     */
        /* 123 */
        log.error("UNREACH==addChat.type=" + type);
        /* 124 */
        return null;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public static void addNoticeMake(String roleName, String equipName, PT_EQUIP pt_equip) {
        /* 129 */
        long index = ((Long) lastIndexMap.get(Integer.valueOf(200))).longValue();
        /* 130 */
        PT_CHAT pt_chat = new PT_CHAT();
        /* 131 */
        pt_chat.type = Integer.valueOf(2);
        /* 132 */
        pt_chat.chat = "{0} 모험가가 {1} 에픽 장비 제작에 성공하였습니다.";
        /* 133 */
        pt_chat.hyperlinktype = Integer.valueOf(6);
        /* 134 */
        pt_chat.hyperlinksubtype = Integer.valueOf(15);
        /* 135 */
        pt_chat.sub = new ArrayList();
        /* 136 */
        PT_HYPERLINK_SYSTEMMESSAGE_SUB sub1 = new PT_HYPERLINK_SYSTEMMESSAGE_SUB();
        /* 137 */
        PT_HYPERLINK_SYSTEMMESSAGE_SUB sub2 = new PT_HYPERLINK_SYSTEMMESSAGE_SUB();
        /* 138 */
        sub1.msg = roleName;
        /* 139 */
        sub2.msg = equipName;
        /* 140 */
        pt_chat.sub.add(sub1);
        /* 141 */
        pt_chat.sub.add(sub2);
        /* 142 */
        pt_chat.equip = pt_equip;
        /* 143 */
        Map<Long, List<PT_CHAT>> chatNoticeListMap = chatMsgMap.get(Integer.valueOf(200));
        /* 144 */
        if (chatNoticeListMap == null) {
            /* 145 */
            chatNoticeListMap = new ConcurrentHashMap<>();
            /*     */
        }
        /* 147 */
        List<PT_CHAT> chatNoticeList = chatNoticeListMap.get(Long.valueOf(index));
        /* 148 */
        if (chatNoticeList == null) {
            /* 149 */
            chatNoticeList = new ArrayList<>();
            /*     */
        }
        /* 151 */
        chatNoticeList.add(pt_chat);
        /* 152 */
        chatNoticeListMap.put(Long.valueOf(index), chatNoticeList);
        /* 153 */
        chatMsgMap.put(Integer.valueOf(200), chatNoticeListMap);
        /*     */
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\chat\model\ChatCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */