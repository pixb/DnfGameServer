/*    */
package com.dnfm.game.chat.service;

/*    */ 
/*    */ import com.dnfm.common.utils.LimitedCacheMap;
/*    */ import com.dnfm.game.ServerService;
/*    */ import com.dnfm.game.equip.service.EquipService;
/*    */ import com.dnfm.game.friend.service.FriendService;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.game.role.service.RoleService;
/*    */ import com.dnfm.game.skill.service.SkillService;
/*    */ import com.dnfm.game.utils.TimeUtil;
/*    */ import com.dnfm.mina.protobuf.PT_CHAT;
/*    */ import com.dnfm.mina.protobuf.PT_SKIN_CHAT_INFO;
/*    */ import com.dnfm.mina.protobuf.RES_NOTE_MESSENGER_ADD_USER;
/*    */ import java.util.ArrayList;
/*    */ import org.nutz.lang.util.NutMap;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Service;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Service
/*    */ public class ChatService
/*    */ {
/*    */   public boolean chatForbid = true;
/*    */   @Autowired
/*    */   EquipService equipService;
/*    */   @Autowired
/*    */   SkillService skillService;
/*    */   @Autowired
/*    */   ServerService serverService;
/*    */   @Autowired
/*    */   RoleService roleService;
/*    */   @Autowired
/*    */   FriendService friendService;
/* 41 */   private final Logger logger = LoggerFactory.getLogger(com.dnfm.game.chat.service.ChatService.class);
/* 42 */   private final LimitedCacheMap<String, NutMap> chatCache = new LimitedCacheMap(500, 900L);
/*    */   
/*    */   public RES_NOTE_MESSENGER_ADD_USER userMsg(Role role, long targetguid) {
/* 45 */     Role targetRole = this.roleService.getPlayerBy(targetguid);
/* 46 */     RES_NOTE_MESSENGER_ADD_USER resNoteMessengerAddUser = new RES_NOTE_MESSENGER_ADD_USER();
/* 47 */     if (targetRole != null) {
/* 48 */       PT_SKIN_CHAT_INFO pt_skin_chat_info = new PT_SKIN_CHAT_INFO();
/* 49 */       pt_skin_chat_info.chatframe = Integer.valueOf(900);
/* 50 */       pt_skin_chat_info.characterframe = Integer.valueOf(1920000);
/*    */       
/* 52 */       resNoteMessengerAddUser.charguid = Long.valueOf(targetRole.getUid());
/* 53 */       ArrayList<Long> deleteguids = new ArrayList<>();
/* 54 */       deleteguids.add(Long.valueOf(0L));
/* 55 */       resNoteMessengerAddUser.deleteguids = deleteguids;
/* 56 */       resNoteMessengerAddUser.name = targetRole.getName();
/* 57 */       resNoteMessengerAddUser.job = Integer.valueOf(targetRole.getJob());
/* 58 */       resNoteMessengerAddUser.growtype = Integer.valueOf(targetRole.getGrowtype());
/* 59 */       resNoteMessengerAddUser.level = Integer.valueOf(targetRole.getLevel());
/* 60 */       resNoteMessengerAddUser.count = Integer.valueOf(0);
/* 61 */       resNoteMessengerAddUser.date = Long.valueOf(TimeUtil.currS());
/* 62 */       resNoteMessengerAddUser.creditscore = Integer.valueOf(351);
/* 63 */       resNoteMessengerAddUser.skinchatinfo = pt_skin_chat_info;
/* 64 */       ArrayList<PT_CHAT> pt_chats = new ArrayList<>();
/* 65 */       PT_CHAT pt_chat = new PT_CHAT();
/* 66 */       pt_chat.charguid = Long.valueOf(targetRole.getUid());
/* 67 */       if (targetRole.getJob() != 0) {
/* 68 */         pt_chat.job = Integer.valueOf(targetRole.getJob());
/*    */       }
/* 70 */       if (targetRole.getGrowtype() != 0) {
/* 71 */         pt_chat.growtype = Integer.valueOf(targetRole.getGrowtype());
/*    */       }
/* 73 */       if (targetRole.getSecgrowtype() != 0) {
/* 74 */         pt_chat.secgrowtype = Integer.valueOf(targetRole.getSecgrowtype());
/*    */       }
/* 76 */       pt_chat.level = Integer.valueOf(targetRole.getLevel());
/* 77 */       pt_chat.sender = targetRole.getName();
/* 78 */       pt_chat.chat = "112112";
/*    */       
/* 80 */       PT_SKIN_CHAT_INFO pt_skin_chat_info2 = new PT_SKIN_CHAT_INFO();
/* 81 */       pt_skin_chat_info2.chatframe = Integer.valueOf(900);
/* 82 */       pt_skin_chat_info2.characterframe = Integer.valueOf(1920000);
/* 83 */       pt_chat.skinchatinfo = pt_skin_chat_info2;
/* 84 */       pt_chat.date = Long.valueOf(TimeUtil.currS());
/* 85 */       pt_chat.creditscore = Integer.valueOf(351);
/* 86 */       pt_chats.add(pt_chat);
/* 87 */       resNoteMessengerAddUser.list = pt_chats;
/* 88 */       resNoteMessengerAddUser.error = Integer.valueOf(0);
/*    */     } else {
/* 90 */       resNoteMessengerAddUser.error = Integer.valueOf(1);
/*    */     } 
/* 92 */     return resNoteMessengerAddUser;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\game\chat\service\ChatService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */