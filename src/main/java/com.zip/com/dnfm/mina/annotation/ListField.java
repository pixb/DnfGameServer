package com.dnfm.mina.annotation;


import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface ListField {
  int value() default 0;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\annotation\ListField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */