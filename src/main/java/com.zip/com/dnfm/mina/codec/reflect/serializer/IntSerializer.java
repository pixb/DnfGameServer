/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */ import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ 
/*    */ public class IntSerializer
/*    */   extends Serializer {
/*    */   public Integer decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
/* 10 */     return Integer.valueOf(ByteBuffUtil.readInt(in));
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper) {
/* 15 */     if (value instanceof Short) {
/* 16 */       ByteBuffUtil.writeInt(out, ((Short)value).intValue());
/* 17 */     } else if (value instanceof Long) {
/* 18 */       ByteBuffUtil.writeInt(out, ((Long)value).intValue());
/* 19 */     } else if (value instanceof Byte) {
/* 20 */       ByteBuffUtil.writeInt(out, ((Byte)value).intValue());
/*    */     } else {
/* 22 */       ByteBuffUtil.writeInt(out, ((Integer)value).intValue());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void encodeUnsignedShort(IoBuffer out, Object value, Class<?> wrapper) {
/* 27 */     if (value instanceof Short) {
/* 28 */       ByteBuffUtil.writeUnsignedShort(out, ((Short)value).intValue());
/* 29 */     } else if (value instanceof Long) {
/* 30 */       ByteBuffUtil.writeUnsignedShort(out, ((Long)value).intValue());
/* 31 */     } else if (value instanceof Byte) {
/* 32 */       ByteBuffUtil.writeUnsignedShort(out, ((Byte)value).intValue());
/*    */     } else {
/* 34 */       ByteBuffUtil.writeUnsignedShort(out, ((Integer)value).intValue());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\IntSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */