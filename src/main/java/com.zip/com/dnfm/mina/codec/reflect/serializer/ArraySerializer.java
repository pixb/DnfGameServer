/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */ import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.game.utils.ReflectUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import java.lang.reflect.Array;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArraySerializer
/*    */   extends Serializer
/*    */ {
/*    */   public Object decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
/* 17 */     int size = ByteBuffUtil.readShort(in);
/* 18 */     Object array = ReflectUtil.newArray(type, wrapper, size);
/*    */     
/* 20 */     for (int i = 0; i < size; i++) {
/* 21 */       Serializer fieldCodec = getSerializer(wrapper);
/* 22 */       Object eleValue = fieldCodec.decode(in, wrapper, null);
/* 23 */       Array.set(array, i, eleValue);
/*    */     } 
/*    */     
/* 26 */     return array;
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper) {
/* 31 */     if (value == null) {
/* 32 */       ByteBuffUtil.writeShort(out, (short)0);
/*    */       return;
/*    */     } 
/* 35 */     int size = Array.getLength(value);
/* 36 */     ByteBuffUtil.writeShort(out, (short)size);
/* 37 */     encodeObject(out, value, wrapper, size);
/*    */   }
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper, int type) {
/* 41 */     if (value == null) {
/* 42 */       if (type == 1) {
/* 43 */         ByteBuffUtil.writeByte(out, (byte)0);
/* 44 */       } else if (type != 2) {
/* 45 */         if (type == 3) {
/* 46 */           ByteBuffUtil.writeInt(out, 0);
/*    */         } else {
/* 48 */           ByteBuffUtil.writeShort(out, (short)0);
/*    */         } 
/*    */       }  return;
/*    */     } 
/* 52 */     int size = Array.getLength(value);
/* 53 */     if (type == 1) {
/* 54 */       ByteBuffUtil.writeByte(out, (byte)size);
/* 55 */     } else if (type != 2) {
/* 56 */       if (type == 3) {
/* 57 */         ByteBuffUtil.writeInt(out, size);
/*    */       } else {
/* 59 */         ByteBuffUtil.writeShort(out, (short)size);
/*    */       } 
/* 61 */     }  encodeObject(out, value, wrapper, size);
/*    */   }
/*    */   
/*    */   private void encodeObject(IoBuffer out, Object value, Class<?> wrapper, int size) {
/* 65 */     for (int i = 0; i < size; i++) {
/* 66 */       Object elem = Array.get(value, i);
/* 67 */       Class<?> clazz = elem.getClass();
/* 68 */       Serializer fieldCodec = getSerializer(clazz);
/* 69 */       fieldCodec.encode(out, elem, wrapper);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\ArraySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */