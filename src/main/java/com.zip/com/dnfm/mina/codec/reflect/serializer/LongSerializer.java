/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */ import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ 
/*    */ public class LongSerializer
/*    */   extends Serializer
/*    */ {
/*    */   public Long decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
/* 11 */     return Long.valueOf(ByteBuffUtil.readLong(in));
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper) {
/* 16 */     ByteBuffUtil.writeLong(out, ((Long)value).longValue());
/*    */   }
/*    */   
/*    */   public void encodeUnsignedInt(IoBuffer out, Object value, Class<?> wrapper) {
/* 20 */     ByteBuffUtil.writeUnsignedInt(out, ((Long)value).longValue());
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\LongSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */