/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */

import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;

/*    */
/*    */ public class ShortSerializer
        /*    */ extends Serializer {
    /*    */
    public Short decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
        /* 10 */
        return Short.valueOf(ByteBuffUtil.readShort(in));
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void encode(IoBuffer out, Object value, Class<?> wrapper) {
        /* 15 */
        if (value instanceof Long) {
            /* 16 */
            ByteBuffUtil.writeShort(out, ((Long) value).shortValue());
            /* 17 */
        } else if (value instanceof Integer) {
            /* 18 */
            ByteBuffUtil.writeShort(out, ((Integer) value).shortValue());
            /* 19 */
        } else if (value instanceof Byte) {
            /* 20 */
            ByteBuffUtil.writeShort(out, ((Byte) value).shortValue());
            /*    */
        } else {
            /* 22 */
            ByteBuffUtil.writeShort(out, ((Short) value).shortValue());
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    public void encodeUnsignedByte(IoBuffer out, Object value, Class<?> wrapper) {
        /* 27 */
        if (value instanceof Long) {
            /* 28 */
            ByteBuffUtil.writeUnsignedByte(out, ((Long) value).shortValue());
            /* 29 */
        } else if (value instanceof Integer) {
            /* 30 */
            ByteBuffUtil.writeUnsignedByte(out, ((Integer) value).shortValue());
            /* 31 */
        } else if (value instanceof Byte) {
            /* 32 */
            value = Short.valueOf(((Byte) value).shortValue());
            /* 33 */
            ByteBuffUtil.writeUnsignedByte(out, ((Byte) value).shortValue());
            /*    */
        } else {
            /* 35 */
            ByteBuffUtil.writeUnsignedByte(out, ((Short) value).shortValue());
            /*    */
        }
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\ShortSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */