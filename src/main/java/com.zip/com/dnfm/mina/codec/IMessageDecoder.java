package com.dnfm.mina.codec;

import com.dnfm.mina.protobuf.Message;

public interface IMessageDecoder {
    Message readMessage(int module, int cmd, byte[] body);
}