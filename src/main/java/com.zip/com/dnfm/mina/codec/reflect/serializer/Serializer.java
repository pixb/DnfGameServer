package com.dnfm.mina.codec.reflect.serializer;

import com.dnfm.mina.codec.reflect.serializer.ArraySerializer;
import com.dnfm.mina.codec.reflect.serializer.BooleanSerializer;
import com.dnfm.mina.codec.reflect.serializer.ByteSerializer;
import com.dnfm.mina.codec.reflect.serializer.CollectionSerializer;
import com.dnfm.mina.codec.reflect.serializer.DoubleSerializer;
import com.dnfm.mina.codec.reflect.serializer.FieldCodecMeta;
import com.dnfm.mina.codec.reflect.serializer.FloatSerializer;
import com.dnfm.mina.codec.reflect.serializer.IntSerializer;
import com.dnfm.mina.codec.reflect.serializer.LongSerializer;
import com.dnfm.mina.codec.reflect.serializer.MessageSerializer;
import com.dnfm.mina.codec.reflect.serializer.ShortSerializer;
import com.dnfm.mina.codec.reflect.serializer.StringSerializer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mina.core.buffer.IoBuffer;

public abstract class Serializer {
    private static final Map<Class<?>, com.dnfm.mina.codec.reflect.serializer.Serializer> class2Serializers = new ConcurrentHashMap<>();

    static {
        register(boolean.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new BooleanSerializer());
        register(Boolean.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new BooleanSerializer());
        register(byte.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new ByteSerializer());
        register(Byte.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new ByteSerializer());
        register(short.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new ShortSerializer());
        register(Short.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new ShortSerializer());
        register(int.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new IntSerializer());
        register(Integer.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new IntSerializer());
        register(float.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new FloatSerializer());
        register(Float.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new FloatSerializer());
        register(double.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new DoubleSerializer());
        register(Double.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new DoubleSerializer());
        register(long.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new LongSerializer());
        register(Long.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new LongSerializer());
        register(String.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new StringSerializer());
        register(List.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new CollectionSerializer());
        register(Set.class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new CollectionSerializer());
        register(Object[].class, (com.dnfm.mina.codec.reflect.serializer.Serializer)new ArraySerializer());
    }

    private static void register(Class<?> clazz, com.dnfm.mina.codec.reflect.serializer.Serializer serializer) {
        class2Serializers.put(clazz, serializer);
    }

    public static Serializer getSerializer(Class<?> clazz) {
        if (class2Serializers.containsKey(clazz))
            return class2Serializers.get(clazz);
        if (clazz.isArray())
            return class2Serializers.get(Object[].class);
        Field[] fields = clazz.getDeclaredFields();
        LinkedHashMap<Field, Class<?>> sortedFields = new LinkedHashMap<>();
        List<FieldCodecMeta> fieldsMeta = new ArrayList<>();
        for (Field field : fields) {
            int modifier = field.getModifiers();
            if (!Modifier.isFinal(modifier) && !Modifier.isStatic(modifier) && !Modifier.isTransient(modifier)) {
                field.setAccessible(true);
                sortedFields.put(field, field.getType());
                Class<?> type = field.getType();
                com.dnfm.mina.codec.reflect.serializer.Serializer serializer = getSerializer(type);
                fieldsMeta.add(FieldCodecMeta.valueOf(field, serializer));
            }
        }
        MessageSerializer messageSerializer = MessageSerializer.valueOf(fieldsMeta);
        register(clazz, (com.dnfm.mina.codec.reflect.serializer.Serializer)messageSerializer);
        return (com.dnfm.mina.codec.reflect.serializer.Serializer)messageSerializer;
    }

    public abstract Object decode(IoBuffer paramIoBuffer, Class<?> paramClass1, Class<?> paramClass2);

    public abstract void encode(IoBuffer paramIoBuffer, Object paramObject, Class<?> paramClass);
}
