/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */

import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;

/*    */
/*    */
/*    */
/*    */ public class StringSerializer
        /*    */ extends Serializer
        /*    */ {
    /*    */
    public String decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
        /* 13 */
        return ByteBuffUtil.readByteString(in);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public String decodeShort(IoBuffer in) {
        /* 20 */
        return ByteBuffUtil.readShortString(in);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void encodeShort(IoBuffer out, String msg) {
        /* 27 */
        ByteBuffUtil.writeShortString(out, msg);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void encode(IoBuffer out, Object value, Class<?> wrapper) {
        /* 36 */
        ByteBuffUtil.writeByteString(out, (String) value);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\StringSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */