/*     */
package com.dnfm.mina.codec;

/*     */
/*     */ import org.apache.mina.core.buffer.IoBuffer;
/*     */ 
/*     */ 
/*     */ public class CodecUtils
/*     */ {
/*     */   public static byte[] unsignedShortToByte2(int s) {
/*   9 */     byte[] targets = new byte[2];
/*  10 */     targets[0] = (byte)(s >> 8 & 0xFF);
/*  11 */     targets[1] = (byte)(s & 0xFF);
/*  12 */     return targets;
/*     */   }
/*     */   
/*     */   public static byte[] unsignedIntToByte4(long s) {
/*  16 */     byte[] targets = new byte[4];
/*  17 */     targets[0] = (byte)(int)(s >> 24L & 0xFFL);
/*  18 */     targets[1] = (byte)(int)(s >> 16L & 0xFFL);
/*  19 */     targets[2] = (byte)(int)(s >> 8L & 0xFFL);
/*  20 */     targets[3] = (byte)(int)(s & 0xFFL);
/*  21 */     return targets;
/*     */   }
/*     */   
/*     */   public static byte[] intToBytes(int value) {
/*  25 */     byte[] src = new byte[4];
/*  26 */     src[0] = (byte)(value & 0xFF);
/*  27 */     src[1] = (byte)(value >> 8 & 0xFF);
/*  28 */     src[2] = (byte)(value >> 16 & 0xFF);
/*  29 */     src[3] = (byte)(value >> 24 & 0xFF);
/*  30 */     return src;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToHex(byte[] bytes) {
/*  40 */     StringBuffer sb = new StringBuffer();
/*  41 */     for (int i = 0; i < bytes.length; i++) {
/*  42 */       String hex = Integer.toHexString(bytes[i] & 0xFF);
/*  43 */       if (hex.length() < 2) {
/*  44 */         sb.append(0);
/*     */       }
/*  46 */       sb.append(hex);
/*     */     } 
/*  48 */     return sb.toString().toUpperCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String byteToHex(byte b) {
/*  59 */     String hex = Integer.toHexString(b & 0xFF);
/*  60 */     if (hex.length() < 2) {
/*  61 */       hex = "0" + hex;
/*     */     }
/*  63 */     return hex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] hexToByteArray(String inHex) {
/*     */     byte[] result;
/*  74 */     int hexlen = inHex.length();
/*     */     
/*  76 */     if (hexlen % 2 == 1) {
/*     */       
/*  78 */       hexlen++;
/*  79 */       result = new byte[hexlen / 2];
/*  80 */       inHex = "0" + inHex;
/*     */     } else {
/*     */       
/*  83 */       result = new byte[hexlen / 2];
/*     */     } 
/*  85 */     int j = 0;
/*  86 */     for (int i = 0; i < hexlen; i += 2) {
/*  87 */       result[j] = hexToByte(inHex.substring(i, i + 2));
/*  88 */       j++;
/*     */     } 
/*  90 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte hexToByte(String inHex) {
/* 100 */     return (byte)Integer.parseInt(inHex, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] ioBufferToByte(Object message) {
/* 109 */     if (!(message instanceof IoBuffer)) {
/* 110 */       return null;
/*     */     }
/* 112 */     IoBuffer ioBuffer = (IoBuffer)message;
/* 113 */     byte[] b = new byte[ioBuffer.limit()];
/* 114 */     ioBuffer.get(b);
/* 115 */     return b;
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\CodecUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */