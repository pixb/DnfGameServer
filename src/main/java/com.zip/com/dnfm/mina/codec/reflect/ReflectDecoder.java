/*    */
package com.dnfm.mina.codec.reflect;

/*    */
/*    */ import com.dnfm.mina.codec.IMessageDecoder;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import com.dnfm.mina.message.MessageFactory;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ReflectDecoder
/*    */   implements IMessageDecoder
/*    */ {
/* 14 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.mina.codec.reflect.ReflectDecoder.class);
/*    */ 
/*    */   
/*    */   public Message readMessage(int module, int cmd, byte[] body) {
/* 18 */     IoBuffer in = IoBuffer.allocate(body.length);
/* 19 */     in.put(body);
/* 20 */     in.flip();
/*    */     
/* 22 */     Class<?> msgClazz = MessageFactory.INSTANCE.getMessage(module, cmd);
/* 23 */     if (msgClazz == null) {
/* 24 */       return null;
/*    */     }
/*    */     try {
/* 27 */       Serializer messageCodec = Serializer.getSerializer(msgClazz);
/* 28 */       return (Message)messageCodec.decode(in, msgClazz, null);
/* 29 */     } catch (Exception e) {
/* 30 */       logger.error("读取消息出错,模块号{}，类型{},异常{}", new Object[] { Integer.valueOf(module), Integer.valueOf(cmd), e });
/*    */       
/* 32 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\ReflectDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */