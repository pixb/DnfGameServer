/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */ import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ 
/*    */ public class ByteSerializer
/*    */   extends Serializer {
/*    */   public Byte decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
/* 10 */     return Byte.valueOf(ByteBuffUtil.readByte(in));
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper) {
/* 15 */     if (value instanceof Integer) {
/* 16 */       ByteBuffUtil.writeByte(out, ((Integer)value).byteValue());
/* 17 */     } else if (value instanceof Short) {
/* 18 */       ByteBuffUtil.writeByte(out, ((Short)value).byteValue());
/* 19 */     } else if (value instanceof Long) {
/* 20 */       ByteBuffUtil.writeByte(out, ((Long)value).byteValue());
/*    */     } else {
/* 22 */       ByteBuffUtil.writeByte(out, ((Byte)value).byteValue());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\ByteSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */