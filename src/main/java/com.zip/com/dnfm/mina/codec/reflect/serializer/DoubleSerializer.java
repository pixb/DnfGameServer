/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */ import com.dnfm.game.utils.ByteBuffUtil;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ 
/*    */ public class DoubleSerializer
/*    */   extends Serializer {
/*    */   public Double decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
/* 10 */     return Double.valueOf(ByteBuffUtil.readDouble(in));
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(IoBuffer out, Object value, Class<?> wrapper) {
/* 15 */     ByteBuffUtil.writeDouble(out, ((Double)value).doubleValue());
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\DoubleSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */