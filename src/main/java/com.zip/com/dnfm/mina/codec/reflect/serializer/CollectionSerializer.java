/*     */
package com.dnfm.mina.codec.reflect.serializer;

/*     */
/*     */

import com.dnfm.game.utils.ByteBuffUtil;
/*     */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.mina.core.buffer.IoBuffer;

/*     */
/*     */
/*     */ public class CollectionSerializer
        /*     */ extends Serializer
        /*     */ {
    /*     */
    public Object decode(IoBuffer in, Class<?> type, Class<?> wrapper) {
        /*  18 */
        int size = ByteBuffUtil.readShort(in);
        /*  19 */
        return getObject(in, type, wrapper, size);
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public Object decodeByte(IoBuffer in, Class<?> type, Class<?> wrapper) {
        /*  24 */
        int size = ByteBuffUtil.readByte(in);
        /*  25 */
        return getObject(in, type, wrapper, size);
        /*     */
    }

    /*     */
    /*     */
    private Object getObject(IoBuffer in, Class<?> type, Class<?> wrapper, int size) {
        /*  29 */
        int modifier = type.getModifiers();
        /*  30 */
        Collection<Object> result = null;
        /*     */
        /*  32 */
        if (Modifier.isAbstract(modifier) || Modifier.isInterface(modifier)) {
            /*  33 */
            if (List.class.isAssignableFrom(type)) {
                /*  34 */
                result = new ArrayList();
                /*  35 */
            } else if (Set.class.isAssignableFrom(type)) {
                /*  36 */
                result = new HashSet();
                /*     */
            }
            /*     */
        } else {
            /*     */
            try {
                /*  40 */
                result = (Collection<Object>) type.newInstance();
                /*  41 */
            } catch (Exception e) {
                /*     */
                /*  43 */
                result = new ArrayList();
                /*     */
            }
            /*     */
        }
        /*     */
        /*  47 */
        for (int i = 0; i < size; i++) {
            /*  48 */
            Serializer fieldCodec = Serializer.getSerializer(wrapper);
            /*  49 */
            Object eleValue = fieldCodec.decode(in, wrapper, null);
            /*  50 */
            result.add(eleValue);
            /*     */
        }
        /*     */
        /*  53 */
        return result;
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public void encode(IoBuffer out, Object value, Class<?> wrapper) {
        /*  58 */
        if (value == null) {
            /*  59 */
            ByteBuffUtil.writeShort(out, (short) 0);
            /*     */
            return;
            /*     */
        }
        /*  62 */
        Collection<Object> collection = (Collection<Object>) value;
        /*  63 */
        int size = collection.size();
        /*  64 */
        ByteBuffUtil.writeShort(out, (short) size);
        /*     */
        /*  66 */
        for (Object elem : collection) {
            /*  67 */
            Class<?> clazz = elem.getClass();
            /*  68 */
            Serializer fieldCodec = Serializer.getSerializer(clazz);
            /*  69 */
            fieldCodec.encode(out, elem, wrapper);
            /*     */
        }
        /*     */
    }

    /*     */
    /*     */
    /*     */
    public void encode(IoBuffer out, Object value, Class<?> wrapper, int type) {
        /*  75 */
        if (value == null) {
            /*  76 */
            if (type == 1) {
                /*  77 */
                ByteBuffUtil.writeByte(out, (byte) 0);
                /*  78 */
            } else if (type != 2) {
                /*  79 */
                if (type == 3) {
                    /*  80 */
                    ByteBuffUtil.writeInt(out, 0);
                    /*     */
                } else {
                    /*  82 */
                    ByteBuffUtil.writeShort(out, (short) 0);
                    /*     */
                }
                /*     */
            }
            return;
            /*     */
        }
        /*  86 */
        Collection<Object> collection = (Collection<Object>) value;
        /*  87 */
        int size = collection.size();
        /*  88 */
        if (type == 1) {
            /*  89 */
            ByteBuffUtil.writeByte(out, (byte) size);
            /*  90 */
        } else if (type != 2) {
            /*  91 */
            if (type == 3) {
                /*  92 */
                ByteBuffUtil.writeInt(out, size);
                /*     */
            } else {
                /*  94 */
                ByteBuffUtil.writeShort(out, (short) size);
                /*     */
            }
            /*     */
        }
        /*  97 */
        for (Object elem : collection) {
            /*  98 */
            Class<?> clazz = elem.getClass();
            /*  99 */
            Serializer fieldCodec = Serializer.getSerializer(clazz);
            /* 100 */
            fieldCodec.encode(out, elem, wrapper);
            /*     */
        }
        /*     */
    }
    /*     */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\CollectionSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */