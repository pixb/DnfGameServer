/*    */
package com.dnfm.mina.codec.reflect.serializer;

/*    */
/*    */

import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.util.Collection;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class FieldCodecMeta
        /*    */ {
    /*    */   private Field field;
    /*    */   private Class<?> type;
    /*    */   private Serializer serializer;
    /*    */   private Class<?> wrapper;

    /*    */
    /*    */
    public static com.dnfm.mina.codec.reflect.serializer.FieldCodecMeta valueOf(Field field, Serializer serializer) {
        /* 20 */
        com.dnfm.mina.codec.reflect.serializer.FieldCodecMeta meta = new com.dnfm.mina.codec.reflect.serializer.FieldCodecMeta();
        /* 21 */
        meta.field = field;
        /* 22 */
        Class<?> type = field.getType();
        /* 23 */
        meta.type = type;
        /* 24 */
        meta.serializer = serializer;
        /*    */
        /* 26 */
        if (Collection.class.isAssignableFrom(type)) {
            /* 27 */
            meta.wrapper = (Class) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
            /* 28 */
        } else if (type.isArray()) {
            /* 29 */
            meta.wrapper = type.getComponentType();
            /*    */
        }
        /* 31 */
        return meta;
        /*    */
    }

    /*    */
    /*    */
    public Field getField() {
        /* 35 */
        return this.field;
        /*    */
    }

    /*    */
    /*    */
    public Class<?> getType() {
        /* 39 */
        return this.type;
        /*    */
    }

    /*    */
    /*    */
    public Serializer getSerializer() {
        /* 43 */
        return this.serializer;
        /*    */
    }

    /*    */
    /*    */
    public Class<?> getWrapper() {
        /* 47 */
        return this.wrapper;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public String toString() {
        /* 52 */
        return "FieldCodecMeta [field=" + this.field + ", type=" + this.type + ", serializer=" + this.serializer + ", wrapper=" + this.wrapper + "]";
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\serializer\FieldCodecMeta.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */