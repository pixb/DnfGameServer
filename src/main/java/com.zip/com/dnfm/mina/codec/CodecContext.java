/*    */
package com.dnfm.mina.codec;

/*    */
/*    */

import org.apache.mina.core.buffer.IoBuffer;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class CodecContext
        /*    */ {
    /* 17 */   private final IoBuffer buffer = IoBuffer.allocate(32).setAutoExpand(true).setAutoShrink(true);

    /*    */
    /*    */
    /*    */
    public IoBuffer append(IoBuffer in) {
        /* 21 */
        this.buffer.put(in);
        /* 22 */
        return this.buffer;
        /*    */
    }

    /*    */
    /*    */
    public IoBuffer getBuffer() {
        /* 26 */
        return this.buffer;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\CodecContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */