/*    */
package com.dnfm.mina.codec.reflect;

/*    */
/*    */ import com.dnfm.mina.codec.IMessageEncoder;
/*    */ import com.dnfm.mina.codec.reflect.serializer.Serializer;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ReflectEncoder
/*    */   implements IMessageEncoder {
/* 12 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.mina.codec.reflect.ReflectEncoder.class);
/*    */ 
/*    */   
/*    */   public byte[] writeMessageBody(Message message) {
/* 16 */     IoBuffer out = IoBuffer.allocate(32).setAutoShrink(true).setAutoExpand(true);
/*    */     
/*    */     try {
/* 19 */       Serializer messageCodec = Serializer.getSerializer(message.getClass());
/* 20 */       messageCodec.encode(out, message, null);
/* 21 */     } catch (Exception e) {
/* 22 */       logger.error("读取消息出错,模块号{}，类型{},异常{}", Integer.valueOf(message.getModule()), e);
/*    */     } 
/* 24 */     out.flip();
/* 25 */     byte[] body = new byte[out.remaining()];
/* 26 */     out.get(body);
/* 27 */     return body;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\codec\reflect\ReflectEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */