package com.dnfm.mina.message;

import lombok.Getter;

import java.lang.reflect.Method;

@Getter
public class CmdExecutor {
    private Method method;
    private Class<?>[] params;
    private Object handler;

    public static CmdExecutor valueOf(Method method, Class<?>[] params, Object handler) {
        CmdExecutor executor = new CmdExecutor();
        executor.method = method;
        executor.params = params;
        executor.handler = handler;
        return executor;
    }

}