package com.dnfm.mina.message;

import com.dnfm.game.role.model.Role;
import com.dnfm.mina.cache.SessionUtils;
import com.dnfm.mina.protobuf.Message;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 消息推送器。
 * 提供静态方法用于向指定角色或会话推送消息。
 */
public class MessagePusher {

    private static final Logger logger = LoggerFactory.getLogger(MessagePusher.class);

    /**
     * 向指定角色推送单条消息。
     * 如果角色为 null，则直接返回。
     *
     * @param role    目标角色
     * @param message 要推送的消息
     */
    public static void pushMessage(Role role, Message message) {
        if (role == null) {
            return;
        }
        // 使用角色的 UID 而不是 ID 来获取会话
        pushMessage(role.getUid(), message);
    }

    /**
     * 向指定角色推送多条消息。
     * 如果角色为 null，则直接返回。
     *
     * @param role     目标角色
     * @param messages 要推送的消息数组
     */
    public static void pushMessages(Role role, Message... messages) {
        if (role == null) {
            return;
        }
        for (Message message : messages) {
            // 使用角色的 UID 而不是 ID 来获取会话
            pushMessage(role.getUid(), message);
        }
    }

    /**
     * 根据用户 UID 向其会话推送消息。
     * 如果找不到对应的会话，则直接返回。
     *
     * @param uid     用户 UID
     * @param message 要推送的消息
     */
    private static void pushMessage(long uid, Message message) {
        IoSession session = SessionUtils.getSessionBy(uid);
        if (session != null) {
            pushMessage(session, message);
        }
    }

    /**
     * 向指定的 MINA 会话推送消息。
     * 如果会话为 null、消息为 null 或会话正在关闭，则直接返回。
     *
     * @param session MINA 会话
     * @param message 要推送的消息
     */
    public static void pushMessage(IoSession session, Message message) {
        if (session == null || message == null || session.isClosing()) {
            // 可以选择在此处记录日志，例如当会话关闭时
            // if (session != null && session.isClosing()) {
            //     logger.debug("Session is closing, cannot push message: {}", session);
            // }
            return;
        }
        session.write(message);
    }
}