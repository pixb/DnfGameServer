// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina;

import org.springframework.context.annotation.Configuration;

@Configuration
public class MinaConfig {
    public MinaConfig() {
    }
}
