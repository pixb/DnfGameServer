package com.dnfm.mina.cache;

import com.dnfm.common.utils.ConcurrentHashSet;
import com.dnfm.game.activity.model.Dugeon;
import com.dnfm.game.auction.model.AuctionModel;
import com.dnfm.game.bag.model.ClearDungeonBox;
import com.dnfm.game.config.NPC;
import com.dnfm.game.config.OnlineMall;
import com.dnfm.game.config.Server;
import com.dnfm.game.dungeon.model.Dungeon;
import com.dnfm.game.dungeon.model.DungeonMap;
import com.dnfm.game.dungeon.model.MapSpec;
import com.dnfm.game.dungeon.model.Monster;
import com.dnfm.game.dungeon.model.PartyBoard;
import com.dnfm.game.dungeon.model.TowerRewardItem;
import com.dnfm.game.item.model.GiftContentMap;
import com.dnfm.game.make.model.AvatarCompoundRes;
import com.dnfm.game.make.model.MakeModel;
import com.dnfm.game.make.model.StackableModel;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.skill.bean.SkillObject;
import com.dnfm.game.skill.model.SkillBox;
import com.dnfm.game.skill.model.SkillslotBox;
import com.dnfm.game.task.model.TaskInfo;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;

public interface DataCache {
    public static final ConcurrentHashMap<Integer, TowerRewardItem> towerRewardItemMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Long, Role> AUCTION_ROLES = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> dungeonNormalLevelMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> dungeonExpertLevelMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> dungeonMasterLevelMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> dungeonKingLevelMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> dungeonSplayerLevelMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, List<Integer>> CARD_RARITY_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> auctionCategoryType = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, List<AuctionModel>> auctionCategoryMap = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, StackableModel> RECIPE_INDEX = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, MakeModel> MAKE_EQU_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, MakeModel> MAKE_OTHER_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, GiftContentMap> GIFT_CONTENT_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResSwordman = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResSwordman2 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResFighter = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResFighter2 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResGunner = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResGunner2 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResMage = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResMage2 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResPriest = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<AvatarCompoundRes>> avatarCompoundResPriest2 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<PartyBoard>> partyBoardMap1 = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<PartyBoard>> partyBoardMap1_backup = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<PartyBoard>> partyBoardMap1s = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, List<PartyBoard>> partyBoardMap1s_backup = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, ClearDungeonBox> lv28ClearDungeonBox = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, SkillBox> lv28SkillBox = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, SkillslotBox> lv28SkillslotBox = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> QUEST_INDEX2ID_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Integer> ROLE_EXP_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, OnlineMall> NUM_MALL = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, OnlineMall> NAME_MALL = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Server> ID_SERVER = new ConcurrentHashMap<>();

    public static final Map<Integer, Dungeon> DUNGEON_MAP = new ConcurrentHashMap<>();

    public static final Map<Integer, List<MapSpec>> DUNGEON_MAP_SPEC = new ConcurrentHashMap<>();

    public static final Map<Integer, List<Monster>> DMAP_MONSTER = new ConcurrentHashMap<>();

    public static final Map<Integer, DungeonMap> DMAP_MAP = new ConcurrentHashMap<>();

    public static final Map<Integer, TaskInfo> TASK_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Long, Role> PVP_ROLE_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLATDEMONICLANCER = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLATFIGHTER = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLATPRIEST = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLATSWORDMAN = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLFIGHTER = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLGUNNER = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLMAGE = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLPRIEST = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, SkillObject> SKILLSWORDMAN = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, Short> NAME_ICON = new ConcurrentHashMap<>();

    public static final Set<String> MOUNTS = new HashSet<>();

    public static final Set<String> VARIATION = new HashSet<>();

    public static final ConcurrentHashMap<Integer, Integer> ICON_FASION = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, NPC> ID_NPC = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Set<Integer>> MAP_NPCIDS = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, Integer> NAME_NPCID = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, NPC> TASK_NPCS = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, Set<Integer>> TASK_MAP_NPC = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Integer, NPC> BOSS_NPC = new ConcurrentHashMap<>();

    public static final Map<Integer, NPC> GROUP_NPC = new ConcurrentHashMap<>();

    public static final Map<Integer, Map<Serializable, Set<Integer>>> GROUP_MAP_NPCIDS = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Long, Role> ONLINE_ROLES = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<String, Long> ONLINE_ACC_MAP = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Long, Role> ONLINE_GM = new ConcurrentHashMap<>();

    public static final ConcurrentHashMap<Long, Role> OFFLINE_ROLES = new ConcurrentHashMap<>();

    public static final ConcurrentHashSet<Long> ONLINE_GMS_ID = new ConcurrentHashSet();

    public static final ConcurrentHashMap<Long, Lock> UID_LOCK_MAP = new ConcurrentHashMap<>(2048);

    public static final Map<Long, Dugeon> DUGEON_MAP = new ConcurrentHashMap<>();

    public static final Map<Long, Long> ROLE_DUGEON = new ConcurrentHashMap<>();
}
