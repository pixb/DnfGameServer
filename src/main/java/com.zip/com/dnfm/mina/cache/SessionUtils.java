package com.dnfm.mina.cache;

import com.dnfm.common.spring.SpringUtils;
import com.dnfm.common.start.GameServer;
import com.dnfm.game.role.model.Account;
import com.dnfm.game.role.model.Role;
import com.dnfm.mina.session.SessionManager;
import com.dnfm.mina.session.SessionProperties;

import java.util.HashMap;
import java.util.Map;

import org.apache.mina.core.session.IoSession;

/**
 * 会话工具类。
 * 提供静态方法用于从 MINA 会话中获取相关数据，如角色、账户、事务ID等。
 */
public class SessionUtils {

    /**
     * 获取并递增会话的事务ID。
     * 该ID用于通知消息的事务追踪。
     *
     * @param session MINA 会话
     * @return 递增前的事务ID
     */
    public static Integer getNotiTransId(IoSession session) {
        Integer res = SessionManager.INSTANCE.getSessionAttr(session, SessionProperties.NOTIFY_TRANS_ID, Integer.class);
        if (res == null) {
            // 如果没有找到事务ID，初始化为0
            res = 0;
        }
        // 递增ID并存回会话属性
        session.setAttribute(SessionProperties.NOTIFY_TRANS_ID, res + 1);
        return res;
    }

    /**
     * 根据用户UID获取对应的MINA会话。
     *
     * @param uid 用户UID
     * @return 对应的MINA会话，如果未找到则返回 null
     */
    public static IoSession getSession(long uid) {
        return SessionManager.INSTANCE.getSessionBy(uid);
    }

    /**
     * 根据用户UID获取对应的MINA会话。
     * 此方法是 getSession 的别名。
     *
     * @param uid 用户UID
     * @return 对应的MINA会话，如果未找到则返回 null
     */
    public static IoSession getSessionBy(long uid) {
        return getSession(uid);
    }

    /**
     * 获取所有活动的会话列表。
     *
     * @return 会话ID到会话对象的映射
     */
    public static Map<Long, IoSession> getSessionList() {
        GameServer gameServer = SpringUtils.getBean(GameServer.class);
        if (gameServer.getAcceptor() == null) {
            // 如果Acceptor未初始化，返回空Map
            return new HashMap<>();
        }
        return gameServer.getAcceptor().getManagedSessions();
    }

    /**
     * 从会话中获取关联的角色对象。
     *
     * @param session MINA 会话
     * @return 会话关联的角色对象，如果会话为 null 或未设置角色，则返回 null
     */
    public static Role getRoleBySession(IoSession session) {
        if (session == null) {
            return null;
        }
        return SessionManager.INSTANCE.getSessionAttr(session, SessionProperties.PLAYER, Role.class);
    }

    /**
     * 从会话中获取关联的账户对象。
     *
     * @param session MINA 会话
     * @return 会话关联的账户对象，如果会话为 null 或未设置账户，则返回 null
     */
    public static Account getAccountBySession(IoSession session) {
        if (session == null) {
            return null;
        }
        return SessionManager.INSTANCE.getSessionAttr(session, SessionProperties.ACCOUNT, Account.class);
    }
}