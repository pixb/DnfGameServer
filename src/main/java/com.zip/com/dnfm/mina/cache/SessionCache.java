/*    */
package com.dnfm.mina.cache;

/*    */
/*    */ import com.dnfm.common.utils.ConcurrentHashSet;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SessionCache
/*    */ {
/* 14 */   public static final ConcurrentHashMap<Integer, ConcurrentHashSet<Integer>> MAPID_ROLEIDS = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 19 */   public static final Map<Integer, Map<Serializable, ConcurrentHashSet<Integer>>> GROUP_MAPID_ROLEIDS = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public static final ConcurrentHashMap<Integer, Integer> ROLE_TEAM = new ConcurrentHashMap<>();
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\cache\SessionCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */