/*     */
package com.dnfm.mina.filter;

/*     */
/*     */ import com.dnfm.common.utils.ConcurrentHashSet;
/*     */ import com.dnfm.mina.ModuleCounter;
/*     */ import com.dnfm.mina.ModuleCounterSchedule;
/*     */ import com.dnfm.mina.protobuf.Message;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.validation.constraints.NotNull;
/*     */ import org.apache.mina.core.filterchain.IoFilter;
/*     */ import org.apache.mina.core.filterchain.IoFilterAdapter;
/*     */ import org.apache.mina.core.session.IoSession;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class ModuleCounterFilter
/*     */   extends IoFilterAdapter {
/*  21 */   private static final Logger log = LoggerFactory.getLogger(com.dnfm.mina.filter.ModuleCounterFilter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  26 */   public static final Integer G_IDLE_TIME = Integer.valueOf(3000);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String BAN_SHELL = "iptables -I INPUT -s %s -j DROP";
/*     */ 
/*     */   
/*  33 */   public static final Set<String> G_BAN_IP = (Set<String>)new ConcurrentHashSet(100000);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static final AtomicInteger G_UNCHECKED_PLAYER = new AtomicInteger(0);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final Integer G_MAX_UNCHECKED_CONN = Integer.valueOf(100);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final Integer G_MAX_WAIT_TIME = Integer.valueOf(30000);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final Integer G_MIN_PACKET_COUNT = Integer.valueOf(5);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final Integer G_JUMP_HEARTBEAT_CHECK = Integer.valueOf(7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final Integer R_MIN_MODULE_COUNT = Integer.valueOf(2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final Set<Integer> R_MUST_CMD = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void banIp(@NotNull IoSession session) {
/*  80 */     String clientIP = ((InetSocketAddress)session.getRemoteAddress()).getAddress().getHostAddress();
/*  81 */     ModuleCounterSchedule.disconnected(session);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void execShell(String shell) {
/*     */     try {
/*  89 */       Runtime.getRuntime().exec(shell);
/*  90 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpUnchecked() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void dumpAll() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int count(int cmd, ModuleCounter counter) {
/* 160 */     counter.setLastPackTime(System.currentTimeMillis());
/* 161 */     counter.getCount().getAndIncrement();
/* 162 */     Map<Integer, AtomicInteger> counterMap = counter.getCounterMap();
/* 163 */     if (!counterMap.containsKey(Integer.valueOf(cmd))) {
/* 164 */       synchronized (counterMap) {
/* 165 */         if (!counterMap.containsKey(Integer.valueOf(cmd))) {
/* 166 */           counterMap.put(Integer.valueOf(cmd), new AtomicInteger(0));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 171 */     return ((AtomicInteger)counterMap.get(Integer.valueOf(cmd))).incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean rule(ModuleCounter counter) {
/* 178 */     Map<Integer, AtomicInteger> counterMap = counter.getCounterMap();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (counterMap.size() < R_MIN_MODULE_COUNT.intValue()) {
/* 184 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (counter.getCount().get() < G_MIN_PACKET_COUNT.intValue()) {
/* 191 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     long cmdCount = R_MUST_CMD.parallelStream().filter(e -> !counterMap.containsKey(e)).count();
/*     */     
/* 199 */     return (cmdCount == 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canConnect() {
/* 206 */     return (G_UNCHECKED_PLAYER.get() < G_MAX_UNCHECKED_CONN.intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void messageReceived(IoFilter.NextFilter nextFilter, IoSession session, Object packet) {
/* 211 */     Message message = (Message)packet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     nextFilter.messageReceived(session, message);
/*     */   }
/*     */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\filter\ModuleCounterFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */