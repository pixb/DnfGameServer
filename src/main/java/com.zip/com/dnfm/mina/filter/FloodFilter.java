/*    */
package com.dnfm.mina.filter;

/*    */
/*    */ import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.game.utils.NumberUtil;
/*    */ import com.dnfm.mina.FireWallConfig;
/*    */ import com.dnfm.mina.FloodRecord;
/*    */ import com.dnfm.mina.session.SessionManager;
/*    */ import com.dnfm.mina.session.SessionProperties;
/*    */ import org.apache.mina.core.filterchain.IoFilter;
/*    */ import org.apache.mina.core.filterchain.IoFilterAdapter;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ public class FloodFilter
/*    */   extends IoFilterAdapter
/*    */ {
/* 19 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.mina.filter.FloodFilter.class);
/*    */   
/*    */   private static FloodRecord getFloodRecordBy(IoSession session) {
/* 22 */     SessionManager sessionMgr = SessionManager.INSTANCE;
/* 23 */     FloodRecord record = (FloodRecord)sessionMgr.getSessionAttr(session, SessionProperties.FLOOD, FloodRecord.class);
/*    */     
/* 25 */     if (record == null) {
/* 26 */       record = new FloodRecord();
/* 27 */       session.setAttribute(SessionProperties.FLOOD, record);
/*    */     } 
/*    */     
/* 30 */     return record;
/*    */   }
/*    */   
/*    */   private static void tryToResetFloodTimes(long now, FloodRecord record) {
/* 34 */     FireWallConfig config = (FireWallConfig)SpringUtils.getBean(FireWallConfig.class);
/* 35 */     long diffTime = now - record.getLastFloodTime();
/* 36 */     if (NumberUtil.intValue(Long.valueOf(diffTime / 1L)) > config.getFloodWindowSeconds()) {
/* 37 */       record.setFloodTimes(0);
/*    */     }
/*    */   }
/*    */   
/*    */   private static boolean isMessageTooFast(int packageSum) {
/* 42 */     FireWallConfig config = (FireWallConfig)SpringUtils.getBean(FireWallConfig.class);
/* 43 */     return (packageSum >= config.getMaxPackagePerSecond());
/*    */   }
/*    */   
/*    */   private static boolean isMeetFloodStandard(int floodTimes) {
/* 47 */     FireWallConfig config = (FireWallConfig)SpringUtils.getBean(FireWallConfig.class);
/* 48 */     return (floodTimes > config.getMaxFloodTimes());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void messageReceived(IoFilter.NextFilter nextFilter, IoSession session, Object message) throws Exception {
/* 54 */     FloodRecord record = getFloodRecordBy(session);
/*    */ 
/*    */     
/* 57 */     long now = System.currentTimeMillis();
/* 58 */     long currSecond = NumberUtil.intValue(Long.valueOf(now / 1L));
/* 59 */     long lastTime = record.getLastReceivedTime();
/* 60 */     int lastSecond = NumberUtil.intValue(Long.valueOf(lastTime / 1L));
/*    */     
/* 62 */     tryToResetFloodTimes(now, record);
/*    */     
/* 64 */     if (currSecond == lastSecond) {
/* 65 */       int packageSum = record.addSecondReceivedPackage();
/* 66 */       if (isMessageTooFast(packageSum)) {
/* 67 */         int floodTimes = record.addFloodTimes();
/* 68 */         if (isMeetFloodStandard(floodTimes));
/*    */ 
/*    */ 
/*    */         
/* 72 */         record.setLastFloodTime(now);
/*    */         
/* 74 */         record.setReceivedPacksLastSecond(0);
/*    */       } 
/*    */     } else {
/* 77 */       record.setReceivedPacksLastSecond(0);
/*    */     } 
/*    */     
/* 80 */     record.setLastReceivedTime(now);
/*    */     
/* 82 */     nextFilter.messageReceived(session, message);
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\filter\FloodFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */