/*    */
package com.dnfm.mina.filter;

/*    */
/*    */

import com.dnfm.common.utils.ConcurrentHashSet;

/*    */
/*    */
/*    */ public class ProtocolFilter
        /*    */ {
    /*  8 */   private static final com.dnfm.mina.filter.ProtocolFilter instance = new com.dnfm.mina.filter.ProtocolFilter();
    /*    */
    /*    */
    /*    */
    /*    */
    /* 13 */   private final ConcurrentHashSet<String> bannedList = new ConcurrentHashSet();

    /*    */
    /*    */
    public static com.dnfm.mina.filter.ProtocolFilter getInstance() {
        /* 16 */
        return instance;
        /*    */
    }

    /*    */
    /*    */
    public void openProcotol(String messageId) {
        /* 20 */
        this.bannedList.add(messageId);
        /*    */
    }

    /*    */
    /*    */
    public void closeProcotol(String messageId) {
        /* 24 */
        this.bannedList.add(messageId);
        /*    */
    }

    /*    */
    /*    */
    public boolean canVisit(String messageId) {
        /* 28 */
        return !this.bannedList.contains(messageId);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\filter\ProtocolFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */