/*    */
package com.dnfm.mina.filter;

/*    */
/*    */

import org.apache.mina.core.filterchain.IoFilter;
/*    */ import org.apache.mina.core.filterchain.IoFilterAdapter;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;

/*    */
/*    */ public class TestFilter
        /*    */ extends IoFilterAdapter {
    /* 11 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.mina.filter.TestFilter.class);

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void messageReceived(IoFilter.NextFilter nextFilter, IoSession session, Object message) throws Exception {
        /* 18 */
        nextFilter.messageReceived(session, message);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\filter\TestFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */