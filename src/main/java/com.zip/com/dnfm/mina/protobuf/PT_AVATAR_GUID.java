// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina.protobuf;

import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;

import javax.annotation.PostConstruct;

@ProtobufClass
public class PT_AVATAR_GUID {
   @Protobuf(
      fieldType = FieldType.UINT64,
      order = 1,
      required = false
   )
   public Long guid;

   public PT_AVATAR_GUID() {
   }
}
