// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina.protobuf;

import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;
import com.dnfm.mina.annotation.MessageMeta;

@MessageMeta(
   module = 10036,
   cmd = 1
)
@ProtobufClass
public class NOTIFY_LOAD_SERVER_SIMPLE_DATA extends Message {
   @Protobuf(
      fieldType = FieldType.INT32,
      order = 1,
      required = false
   )
   public Integer error;
   @Protobuf(
      fieldType = FieldType.INT32,
      order = 2,
      required = false
   )
   public Integer type;
   @Protobuf(
      fieldType = FieldType.INT32,
      order = 3,
      required = false
   )
   public Integer enumvalue;
   @Protobuf(
      fieldType = FieldType.STRING,
      order = 4,
      required = false
   )
   public String value;

   public NOTIFY_LOAD_SERVER_SIMPLE_DATA() {
   }
}
