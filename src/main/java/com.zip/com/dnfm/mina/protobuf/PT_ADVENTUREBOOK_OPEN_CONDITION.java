package com.dnfm.mina.protobuf;


import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;

@ProtobufClass
public class PT_ADVENTUREBOOK_OPEN_CONDITION {
  @Protobuf(fieldType = FieldType.INT32, order = 1, required = false)
  public Integer cindex;
  
  @Protobuf(fieldType = FieldType.INT32, order = 2, required = false)
  public Integer cstate;
}
