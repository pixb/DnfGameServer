package com.dnfm.mina.protobuf;


import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;

@ProtobufClass
public class AchievementBonusPacketData {
  @Protobuf(fieldType = FieldType.INT32, order = 1, required = false)
  public Integer completecount;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\protobuf\AchievementBonusPacketData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */