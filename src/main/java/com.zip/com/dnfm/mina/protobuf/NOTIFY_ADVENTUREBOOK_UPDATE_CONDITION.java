// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina.protobuf;

import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;
import com.dnfm.mina.annotation.MessageMeta;
import java.util.List;

@MessageMeta(
   module = 10216,
   cmd = 1
)
@ProtobufClass
public class NOTIFY_ADVENTUREBOOK_UPDATE_CONDITION extends Message {
   @Protobuf(
      fieldType = FieldType.INT32,
      order = 1,
      required = false
   )
   public Integer error;
   @Protobuf(
      order = 2
   )
   public List<PT_ADVENTUREBOOK_OPEN_CONDITION> conditioninfos;

   public NOTIFY_ADVENTUREBOOK_UPDATE_CONDITION() {
   }
}
