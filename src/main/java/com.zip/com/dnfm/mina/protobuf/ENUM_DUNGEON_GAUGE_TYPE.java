package com.dnfm.mina.protobuf;


import com.dnfm.mina.annotation.MessageMeta;
import com.dnfm.mina.protobuf.Message;

@MessageMeta
public class ENUM_DUNGEON_GAUGE_TYPE extends Message {
    public enum T {
        EPIC,
        RANDOMHELL;

        private T() {
        }
    }

}
