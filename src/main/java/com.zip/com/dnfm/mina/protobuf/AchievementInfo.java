package com.dnfm.mina.protobuf;


import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.Codec;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;
import com.baidu.bjf.remoting.protobuf.code.CodedConstant;
import com.dnfm.mina.protobuf.AchievementInfo;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors;
import com.google.protobuf.InvalidProtocolBufferException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;

@ProtobufClass
public class AchievementInfo {
  @Protobuf(fieldType = FieldType.INT32, order = 1, required = false)
  public Integer number;
  
  @Protobuf(fieldType = FieldType.INT32, order = 2, required = false)
  public Integer value;
  
  @Protobuf(fieldType = FieldType.INT32, order = 3, required = false)
  public Integer num;
  
  @Protobuf(fieldType = FieldType.INT32, order = 4, required = false)
  public Integer conditionsetindex;

}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\protobuf\AchievementInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */