package com.dnfm.mina.protobuf;


import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;

@ProtobufClass
public class AchievementCheck {
  @Protobuf(fieldType = FieldType.INT32, order = 1, required = false)
  public Integer index;
  
  @Protobuf(fieldType = FieldType.INT32, order = 2, required = false)
  public Integer number;
  
  @Protobuf(fieldType = FieldType.INT32, order = 3, required = false)
  public Integer value;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\protobuf\AchievementCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */