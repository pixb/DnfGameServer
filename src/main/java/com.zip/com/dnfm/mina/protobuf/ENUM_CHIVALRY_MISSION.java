// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina.protobuf;

import com.baidu.bjf.remoting.protobuf.EnumReadable;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;

@ProtobufClass
public class ENUM_CHIVALRY_MISSION {
    public ENUM_CHIVALRY_MISSION() {
    }
    public enum T implements EnumReadable {
        CLEAR(0),
        TIME_ATTACK(1),
        ATTACK_DAMAGE(2),
        HIT_DAMAGE(3),
        CLEAR_WITHOUT_SENIOR(4),
        CLEAR_WITH_JUNIOR(5);

        private final int value;

        private T(int value) {
            this.value = value;
        }

        public int value() {
            return this.value;
        }
    }
}
