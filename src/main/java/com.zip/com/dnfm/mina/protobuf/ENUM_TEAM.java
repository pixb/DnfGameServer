// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.mina.protobuf;

import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;
import com.dnfm.mina.annotation.MessageMeta;

@MessageMeta
@ProtobufClass
public class ENUM_TEAM extends Message {
   public ENUM_TEAM() {
   }
   public enum T {
      PLAYER,
      RED,
      BLUE,
      YELLOW,
      GREEN,
      BLACK,
      PINK,
      GRAY,
      ORANGE,
      PURPLE,
      BROWN,
      ENEMY,
      ENEMY_END,
      NEUTRAL,
      NEUTRAL_END,
      OBSERVER,
      OBSERVER_END;

      private T() {
      }
   }
}
