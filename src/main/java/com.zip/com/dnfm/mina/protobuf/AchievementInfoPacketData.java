package com.dnfm.mina.protobuf;


import com.baidu.bjf.remoting.protobuf.FieldType;
import com.baidu.bjf.remoting.protobuf.annotation.Protobuf;
import com.baidu.bjf.remoting.protobuf.annotation.ProtobufClass;
import com.dnfm.mina.protobuf.AchievementInfo;
import java.util.List;
@ProtobufClass
public class AchievementInfoPacketData {
  @Protobuf(fieldType = FieldType.INT32, order = 1, required = false)
  public Integer index;
  
  @Protobuf(fieldType = FieldType.INT32, order = 2, required = false)
  public Integer count;
  
  @Protobuf(fieldType = FieldType.INT32, order = 3, required = false)
  public Integer clear;
  
  @Protobuf(fieldType = FieldType.INT32, order = 4, required = false)
  public Integer rewardcount;
  
  @Protobuf(fieldType = FieldType.INT64, order = 5, required = false)
  public Long cleartime;
  
  @Protobuf(order = 6)
  public List<AchievementInfo> values;


}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\protobuf\AchievementInfoPacketData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */