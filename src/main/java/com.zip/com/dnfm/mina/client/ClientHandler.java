/*    */
package com.dnfm.mina.client;

/*    */
/*    */

import com.dnfm.mina.message.IMessageDispatcher;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import com.dnfm.mina.session.SessionManager;
/*    */ import com.dnfm.mina.session.SessionProperties;
/*    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;

/*    */
/*    */ public class ClientHandler
        /*    */ extends IoHandlerAdapter {
    /* 14 */ Logger logger = LoggerFactory.getLogger(com.dnfm.mina.client.ClientHandler.class);
    /*    */
    /*    */
    /*    */
    /*    */   private final IMessageDispatcher messageDispatcher;

    /*    */
    /*    */
    /*    */
    /*    */
    public ClientHandler(IMessageDispatcher messageDispatcher) {
        /* 23 */
        this.messageDispatcher = messageDispatcher;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void sessionClosed(IoSession session) throws Exception {
        /* 28 */
        super.sessionClosed(session);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void sessionCreated(IoSession session) throws Exception {
        /* 33 */
        session.setAttributeIfAbsent(SessionProperties.DISTRIBUTE_KEY, Integer.valueOf(SessionManager.INSTANCE.getNextDistributeKey()));
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void messageReceived(IoSession session, Object data) throws Exception {
        /* 38 */
        Message message = (Message) data;
        /* 39 */
        this.messageDispatcher.dispatch(session, message);
        /* 40 */
        this.logger.info("收到消息");
        /*    */
    }

    /*    */
    /*    */
    public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
    }

    /*    */
    /*    */
    public void messageSent(IoSession session, Object message) throws Exception {
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\mina\client\ClientHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */