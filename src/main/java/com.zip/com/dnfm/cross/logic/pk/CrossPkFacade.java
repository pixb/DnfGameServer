package com.dnfm.cross.logic.pk;


import org.springframework.stereotype.Controller;

@Controller
public class CrossPkFacade {
}
