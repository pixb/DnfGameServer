package com.dnfm.cross.logic.pk;


import org.springframework.stereotype.Service;

@Service
public class CrossPkService {
}
