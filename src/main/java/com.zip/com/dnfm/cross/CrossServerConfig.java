package com.dnfm.cross;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import lombok.Getter;

@Service
@PropertySource("classpath:cross.properties")
@Getter
public class CrossServerConfig {
    @Value("${cross.center.ip}")
    private String centerIp;

    @Value("${cross.center.rpcPort}")
    private int centerPort;

    @Value("${cross.center.gamePort}")
    private int gamePort;

    @Value("${cross.center}")
    private int isCenter;

    public boolean isCenterServer() {
        return this.isCenter > 0;
    }
}