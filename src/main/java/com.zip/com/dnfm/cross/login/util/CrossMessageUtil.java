/*    */
package com.dnfm.cross.login.util;
/*    */
/*    */

import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.cross.CrossServerConfig;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.mina.protobuf.Message;

/*    */
/*    */ public class CrossMessageUtil
        /*    */ {
    /*    */
    public static void send(Role role, Message message) {
        /* 11 */
        if (!((CrossServerConfig) SpringUtils.getBean(CrossServerConfig.class)).isCenterServer()) {
            /*    */
            return;
            /*    */
        }
        /* 14 */
        if (message.getModule() > 0)
            /* 15 */ throw new IllegalStateException("跨服状态不允许发送协议" + message.getClass().getSimpleName());
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\logi\\util\CrossMessageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */