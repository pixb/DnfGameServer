package com.dnfm.cross.login.service;


import org.springframework.stereotype.Service;

@Service
public class PlayerRemoteTransferService {
    public void receiverPlayerData(String fromIp, int fromServer, String playerJson, String authJson) {
    }
}
