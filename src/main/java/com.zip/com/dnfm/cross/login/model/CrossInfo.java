package com.dnfm.cross.login.model;

public class CrossInfo {
    private int fromServer;

    private String fromIp;

    private boolean isCross;

    private int crossType;

    public void setFromServer(int fromServer) {
        this.fromServer = fromServer;
    }

    public void setFromIp(String fromIp) {
        this.fromIp = fromIp;
    }

    public void setCross(boolean isCross) {
        this.isCross = isCross;
    }

    public void setCrossType(int crossType) {
        this.crossType = crossType;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof com.dnfm.cross.login.model.CrossInfo))
            return false;
        com.dnfm.cross.login.model.CrossInfo other = (com.dnfm.cross.login.model.CrossInfo) o;
        if (!other.canEqual(this))
            return false;
        if (getFromServer() != other.getFromServer())
            return false;
        Object this$fromIp = getFromIp(), other$fromIp = other.getFromIp();
        return ((this$fromIp == null) ? (other$fromIp != null) : !this$fromIp.equals(other$fromIp)) ? false : ((isCross() != other.isCross()) ? false : (!(getCrossType() != other.getCrossType())));
    }

    protected boolean canEqual(Object other) {
        return other instanceof com.dnfm.cross.login.model.CrossInfo;
    }

    public int hashCode() {
        int PRIME = 59;
        int result = 1;
        result = result * 59 + getFromServer();
        Object $fromIp = getFromIp();
        result = result * 59 + (($fromIp == null) ? 43 : $fromIp.hashCode());
        result = result * 59 + (isCross() ? 79 : 97);
        return result * 59 + getCrossType();
    }

    public String toString() {
        return "CrossInfo(fromServer=" + getFromServer() + ", fromIp=" + getFromIp() + ", isCross=" + isCross() + ", crossType=" + getCrossType() + ")";
    }

    public int getFromServer() {
        return this.fromServer;
    }

    public String getFromIp() {
        return this.fromIp;
    }

    public boolean isCross() {
        return this.isCross;
    }

    public int getCrossType() {
        return this.crossType;
    }
}
