/*    */
package com.dnfm.cross.core;

/*    */
/*    */

import com.dnfm.common.thread.NamedThreadFactory;
/*    */ import com.dnfm.cross.core.client.CCSession;
/*    */ import com.dnfm.cross.core.server.SCSession;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ThreadFactory;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class CrossCmdExecutor
        /*    */ {
    /*    */   private static volatile com.dnfm.cross.core.CrossCmdExecutor self;
    /* 17 */   private final int DEFAULT_CORE_SUM = Runtime.getRuntime().availableProcessors() - 2;
    /*    */
    /*    */   private ExecutorService[] services;

    /*    */
    /*    */
    /*    */
    public static com.dnfm.cross.core.CrossCmdExecutor getInstance() {
        /* 23 */
        if (self != null) {
            /* 24 */
            return self;
            /*    */
        }
        /* 26 */
        synchronized (com.dnfm.cross.core.CrossCmdExecutor.class) {
            /* 27 */
            if (self == null) {
                /* 28 */
                com.dnfm.cross.core.CrossCmdExecutor instance = new com.dnfm.cross.core.CrossCmdExecutor();
                /* 29 */
                instance.init();
                /* 30 */
                self = instance;
                /*    */
            }
            /*    */
        }
        /* 33 */
        return self;
        /*    */
    }

    /*    */
    /*    */
    private void init() {
        /* 37 */
        this.services = new ExecutorService[this.DEFAULT_CORE_SUM];
        /* 38 */
        for (int i = 0; i < this.DEFAULT_CORE_SUM; i++) {
            /* 39 */
            this.services[i] = Executors.newSingleThreadExecutor((ThreadFactory) new NamedThreadFactory("cross-service-" + i));
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    public void addTask(SCSession session, Runnable task) {
        /* 44 */
        int sessionId = session.getId();
        /* 45 */
        int index = sessionId % this.services.length;
        /* 46 */
        this.services[index].submit(task);
        /*    */
    }

    /*    */
    /*    */
    public void addTask(CCSession session, Runnable task) {
        /* 50 */
        int sessionId = session.getId();
        /* 51 */
        int index = sessionId % this.services.length;
        /* 52 */
        this.services[index].submit(task);
        /*    */
    }

    /*    */
    /*    */
    public void shutDown() {
        /* 56 */
        for (int i = 0; i < this.DEFAULT_CORE_SUM; i++)
            /* 57 */
            this.services[i].shutdown();
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\CrossCmdExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */