/*    */
package com.dnfm.cross.core;

/*    */
/*    */

import com.dnfm.cross.core.server.CMessageDispatcher;
/*    */ import com.dnfm.cross.core.server.SCSession;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import org.apache.mina.core.service.IoHandlerAdapter;
/*    */ import org.apache.mina.core.session.AttributeKey;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;

/*    */
/*    */
/*    */
/*    */ public class Game2GameIoHandler
        /*    */ extends IoHandlerAdapter
        /*    */ {
    /* 17 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.cross.core.Game2GameIoHandler.class);
    /*    */
    /*    */
    /*    */
    /*    */   private final CMessageDispatcher messageDispatcher;
    /*    */
    /*    */
    /* 24 */   private final AttributeKey attrKey = new AttributeKey(AttributeKey.class, "SESSION_CONTAINER");

    /*    */
    /*    */
    public Game2GameIoHandler(CMessageDispatcher messageDispatcher) {
        /* 27 */
        this.messageDispatcher = messageDispatcher;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void sessionCreated(IoSession session) {
        /* 32 */
        System.out.println(session.getRemoteAddress().toString());
        /* 33 */
        SCSession sessionContainer = SCSession.valueOf(session);
        /* 34 */
        session.setAttributeIfAbsent(this.attrKey, sessionContainer);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void messageReceived(IoSession session, Object data) throws Exception {
        /* 39 */
        SCSession sessionContainer = (SCSession) session.getAttribute(this.attrKey);
        /* 40 */
        Message message = (Message) data;
        /*    */
        /* 42 */
        this.messageDispatcher.serverDispatch(sessionContainer, message);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void sessionClosed(IoSession session) throws Exception {
        /* 47 */
        logger.error("跨服session关闭");
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
        /* 52 */
        if (!(cause instanceof java.io.IOException))
            /* 53 */ logger.error("server exception", cause);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\Game2GameIoHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */