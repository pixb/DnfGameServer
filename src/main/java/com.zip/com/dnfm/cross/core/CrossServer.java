/*    */
package com.dnfm.cross.core;

/*    */

import com.dnfm.cross.core.Game2GameIoHandler;
/*    */ import com.dnfm.cross.core.codec.CrossSerializerHelper;
import com.dnfm.cross.core.server.BaseCMessageDispatcher;
/*    */ import com.dnfm.cross.core.server.CMessageDispatcher;
/*    */ import org.apache.mina.core.buffer.IoBuffer;
/*    */ import org.apache.mina.core.buffer.IoBufferAllocator;
/*    */ import org.apache.mina.core.buffer.SimpleBufferAllocator;
/*    */ import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
/*    */ import org.apache.mina.core.filterchain.IoFilter;
/*    */ import org.apache.mina.core.service.IoHandler;
/*    */ import org.apache.mina.core.session.IoSessionConfig;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
/*    */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*    */ import org.apache.mina.transport.socket.DefaultSocketSessionConfig;
/*    */ import org.apache.mina.transport.socket.SocketAcceptor;
/*    */ import org.apache.mina.transport.socket.SocketSessionConfig;
/*    */ import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;

/*    */
/*    */ public class CrossServer {
    /* 20 */   private final Logger logger = LoggerFactory.getLogger(com.dnfm.cross.core.CrossServer.class);
    /*    */
    /*    */
    /*    */
    /*    */   private SocketAcceptor acceptor;

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void start(int port) throws Exception {
        /* 30 */
        IoBuffer.setUseDirectBuffer(false);
        /* 31 */
        IoBuffer.setAllocator((IoBufferAllocator) new SimpleBufferAllocator());
        /*    */
        /* 33 */
        this.acceptor = (SocketAcceptor) new NioSocketAcceptor();
        /* 34 */
        this.acceptor.setReuseAddress(true);
        /* 35 */
        this.acceptor.getSessionConfig().setAll((IoSessionConfig) getSessionConfig());
        /*    */
        /* 37 */
        this.logger.info("cross server start at port:{},正在监听服务器点对点的连接...", Integer.valueOf(port));
        /* 38 */
        DefaultIoFilterChainBuilder filterChain = this.acceptor.getFilterChain();
        /* 39 */
        filterChain.addLast("codec", (IoFilter) new ProtocolCodecFilter(
                /* 40 */           (ProtocolCodecFactory) CrossSerializerHelper.getInstance().getCodecFactory()));
        /*    */
        /* 42 */
        this.acceptor.setHandler((IoHandler) new Game2GameIoHandler((CMessageDispatcher) BaseCMessageDispatcher.getInstance()));
        /*    */
        /* 44 */
        this.acceptor.setDefaultLocalAddress(new InetSocketAddress(port));
        /*    */
        /* 46 */
        this.acceptor.bind();
        /*    */
    }

    /*    */
    /*    */
    private SocketSessionConfig getSessionConfig() {
        /* 50 */
        DefaultSocketSessionConfig defaultSocketSessionConfig = new DefaultSocketSessionConfig();
        /* 51 */
        defaultSocketSessionConfig.setKeepAlive(true);
        /* 52 */
        defaultSocketSessionConfig.setReuseAddress(true);
        /* 53 */
        defaultSocketSessionConfig.setSoLinger(0);
        /*    */
        /* 55 */
        return (SocketSessionConfig) defaultSocketSessionConfig;
        /*    */
    }

    /*    */
    /*    */
    public void shutdown() {
        /* 59 */
        if (this.acceptor != null) {
            /* 60 */
            this.acceptor.unbind();
            /* 61 */
            this.acceptor.dispose();
            /*    */
        }
        /* 63 */
        this.logger.error("---------> cross server stop successfully");
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\CrossServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */