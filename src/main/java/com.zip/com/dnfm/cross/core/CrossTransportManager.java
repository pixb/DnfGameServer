/*    */
package com.dnfm.cross.core;

/*    */
/*    */

import com.dnfm.common.thread.NamedThreadFactory;
/*    */ import com.dnfm.cross.core.callback.CallbackTask;
/*    */ import com.dnfm.cross.core.client.C2SSessionPoolFactory;
/*    */ import com.dnfm.cross.core.client.CCSession;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.stereotype.Component;

/*    */
/*    */
@Component
/*    */ public class CrossTransportManager {
    /* 19 */   private final int defaultCoreSum = Runtime.getRuntime().availableProcessors();
    /*    */
    /*    */   private ExecutorService[] services;
    /*    */
    /*    */   private ExecutorService asynService;
    /*    */
    /*    */
    @Autowired
    /*    */ private C2SSessionPoolFactory sessionFactory;

    /*    */
    /*    */
    @PostConstruct
    /*    */ private void init() {
        /* 30 */
        this.services = new ExecutorService[this.defaultCoreSum];
        /* 31 */
        for (int i = 0; i < this.defaultCoreSum; i++) {
            /* 32 */
            this.services[i] = Executors.newSingleThreadExecutor((ThreadFactory) new NamedThreadFactory("rpc-transport" + i));
            /*    */
        }
        /*    */
        /* 35 */
        this.asynService = Executors.newFixedThreadPool(this.defaultCoreSum);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void sendMessageSync(String ip, int port, Message message) {
        /* 46 */
        CCSession session = this.sessionFactory.borrowSession(ip, port);
        /*    */
        try {
            /* 48 */
            session.sendMessage(message);
            /*    */
        } finally {
            /* 50 */
            this.sessionFactory.returnSession(session);
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void sendMessageAsync(String ip, int port, Message message) {
        /* 62 */
        String key = ip + port;
        /* 63 */
        int index = key.hashCode() % this.defaultCoreSum;
        /* 64 */
        this.services[index].submit(() -> sendMessageSync(ip, port, message));
        /*    */
        /*    */
        /* 67 */
        CCSession session = this.sessionFactory.borrowSession(ip, port);
        /* 68 */
        sendMessageAsync(session, message);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void sendMessageAsync(CCSession session, Message message) {
        /*    */
        try {
            /* 79 */
            session.sendMessage(message);
            /*    */
        } finally {
            /* 81 */
            this.sessionFactory.returnSession(session);
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    public Message callBack(CCSession session, Message message) throws ExecutionException, InterruptedException {
        /* 86 */
        CallbackTask task = CallbackTask.valueOf(session, message);
        /* 87 */
        return this.asynService.<Message>submit((Callable<Message>) task).get();
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\CrossTransportManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */