/*    */
package com.dnfm.cross.core.callback;

/*    */

import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.cross.core.callback.CReqCallBack;
/*    */ import com.dnfm.cross.core.callback.CRespCallBack;
/*    */ import com.dnfm.cross.core.callback.CallBackService;
/*    */ import com.dnfm.cross.core.callback.CallbackHandler;
/*    */ import com.dnfm.cross.core.client.CCSession;
/*    */ import com.dnfm.cross.core.server.RpcRequestMapping;
/*    */ import com.dnfm.cross.core.server.SCSession;
/*    */ import com.dnfm.game.utils.JsonUtils;
import com.dnfm.mina.protobuf.Message;
import org.springframework.stereotype.Controller;

/*    */
/*    */
@Controller
/*    */ public class CallbackController {
    /*    */
    @RpcRequestMapping
    /*    */ public void onReqCallBack(SCSession session, CReqCallBack req) {
        /* 16 */
        int cmdType = req.getCmd();
        /* 17 */
        CallbackHandler handler = CallbackHandler.queryHandler(cmdType);
        /* 18 */
        if (handler != null) {
            /* 19 */
            req.deserialize();
            /* 20 */
            handler.onRequest(session, req);
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    @RpcRequestMapping
    /*    */ public void onRespCallBack(CCSession session, CRespCallBack respCallBack) {
        /* 26 */
        String json = respCallBack.getData();
        /*    */
        try {
            /* 28 */
            Message message = (Message) JsonUtils.string2Object(json, Class.forName(respCallBack.getMsgClass()));
            /* 29 */
            ((CallBackService) SpringUtils.getBean(CallBackService.class)).fillCallBack(respCallBack.getIndex(), message);
            /* 30 */
        } catch (ClassNotFoundException classNotFoundException) {
        }
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallbackController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */