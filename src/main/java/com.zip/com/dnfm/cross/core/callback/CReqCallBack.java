/*    */
package com.dnfm.cross.core.callback;

/*    */
/*    */

import com.dnfm.game.utils.JsonUtils;
/*    */ import com.dnfm.mina.annotation.MessageMeta;
/*    */ import com.dnfm.mina.annotation.StringField;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.Base64;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;

/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
@MessageMeta(module = -3)
/*    */ public class CReqCallBack
        /*    */ extends Message
        /*    */ {
    /*    */   private int index;
    /*    */   private int cmd;
    /* 21 */   private transient Map<String, String> params = new HashMap<>();
    /*    */
    /*    */
    @StringField(100)
    /*    */ private String data;

    /*    */
    /*    */
    public void addParam(String key, String value) {
        /* 27 */
        this.params.put(key, value);
        /*    */
    }

    /*    */
    /*    */
    public int getIndex() {
        /* 31 */
        return this.index;
        /*    */
    }

    /*    */
    /*    */
    public void setIndex(int index) {
        /* 35 */
        this.index = index;
        /*    */
    }

    /*    */
    /*    */
    public int getCmd() {
        /* 39 */
        return this.cmd;
        /*    */
    }

    /*    */
    /*    */
    public void setCmd(int cmd) {
        /* 43 */
        this.cmd = cmd;
        /*    */
    }

    /*    */
    /*    */
    public String getData() {
        /* 47 */
        return this.data;
        /*    */
    }

    /*    */
    /*    */
    public void setData(String data) {
        /* 51 */
        this.data = data;
        /*    */
    }

    /*    */
    /*    */
    public void serialize() {
        /* 55 */
        String json = JsonUtils.object2String(this.params);
        /* 56 */
        this.data = Base64.getEncoder().encodeToString(json.getBytes());
        /*    */
    }

    /*    */
    /*    */
    public void deserialize() {
        /* 60 */
        byte[] json = Base64.getDecoder().decode(this.data);
        /* 61 */
        this.params = JsonUtils.string2Map(new String(json), String.class, String.class);
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public Map<String, String> getParams() {
        /* 66 */
        return this.params;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CReqCallBack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */