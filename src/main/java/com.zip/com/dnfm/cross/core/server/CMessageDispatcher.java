package com.dnfm.cross.core.server;


import com.dnfm.cross.core.client.CCSession;
import com.dnfm.cross.core.server.SCSession;
import com.dnfm.mina.protobuf.Message;

public interface CMessageDispatcher {
    void serverDispatch(SCSession paramSCSession, Message paramMessage);

    void clientDispatch(CCSession paramCCSession, Message paramMessage);
}
