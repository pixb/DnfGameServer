package com.dnfm.cross.core.callback;

public interface CallBackCommands {
    public static final int HELLO = 1;

    public static final int LOGIN = 2;

    public static final int LOGOUT = 3;
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallBackCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */