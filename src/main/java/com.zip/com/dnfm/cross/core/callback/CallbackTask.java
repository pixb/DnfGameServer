/*    */
package com.dnfm.cross.core.callback;

/*    */
/*    */

import com.dnfm.common.spring.SpringUtils;
/*    */ import com.dnfm.cross.core.callback.CReqCallBack;
/*    */ import com.dnfm.cross.core.callback.CallBack;
/*    */ import com.dnfm.cross.core.callback.CallBackService;
/*    */ import com.dnfm.cross.core.client.C2SSessionPoolFactory;
/*    */ import com.dnfm.cross.core.client.CCSession;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.locks.Condition;
/*    */ import java.util.concurrent.locks.ReentrantLock;

/*    */
/*    */ public class CallbackTask
        /*    */ implements Callable<Message> {
    /*    */   private CCSession session;
    /*    */   private Message request;

    /*    */
    /*    */
    public static com.dnfm.cross.core.callback.CallbackTask valueOf(CCSession session, Message message) {
        /* 21 */
        com.dnfm.cross.core.callback.CallbackTask task = new com.dnfm.cross.core.callback.CallbackTask();
        /* 22 */
        task.request = message;
        /* 23 */
        task.session = session;
        /* 24 */
        return task;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public Message call() throws Exception {
        /*    */
        try {
            /* 30 */
            CReqCallBack reqCallBack = (CReqCallBack) this.request;
            /* 31 */
            int index = CallBack.nextMsgId();
            /* 32 */
            reqCallBack.setIndex(index);
            /* 33 */
            reqCallBack.serialize();
            /*    */
            /* 35 */
            this.session.sendMessage((Message) reqCallBack);
            /*    */
            /* 37 */
            ReentrantLock lock = new ReentrantLock();
            /* 38 */
            Condition condition = lock.newCondition();
            /* 39 */
            long maxTimeOut = 5L;
            /* 40 */
            long startTime = System.currentTimeMillis();
            /* 41 */
            CallBackService callBackService = SpringUtils.getCallBackService();
            /* 42 */
            while (System.currentTimeMillis() - startTime <= maxTimeOut) {
                /* 43 */
                CallBack c = callBackService.removeCallBack(index);
                /* 44 */
                if (c != null) {
                    /* 45 */
                    return c.getData();
                    /*    */
                }
                /*    */
                /*    */
                try {
                    /* 49 */
                    lock.lockInterruptibly();
                    /* 50 */
                    condition.await(10L, TimeUnit.MILLISECONDS);
                    /* 51 */
                } catch (Exception exception) {
                    /*    */
                    /*    */
                } finally {
                    /* 54 */
                    lock.unlock();
                    /*    */
                }
                /*    */
            }
            /*    */
        } finally {
            /* 58 */
            ((C2SSessionPoolFactory) SpringUtils.getBean(C2SSessionPoolFactory.class)).returnSession(this.session);
            /*    */
        }
        /*    */
        /* 61 */
        return null;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallbackTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */