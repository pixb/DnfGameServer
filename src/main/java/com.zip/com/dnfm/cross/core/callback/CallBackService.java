/*    */
package com.dnfm.cross.core.callback;

/*    */
/*    */

import com.dnfm.cross.core.callback.CallBack;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.stereotype.Service;

/*    */
/*    */
@Service
/*    */ public class CallBackService
        /*    */ {
    /* 12 */   private final ConcurrentMap<Integer, CallBack> callbacks = new ConcurrentHashMap<>();

    /*    */
    /*    */
    public void fillCallBack(int index, Message message) {
        /* 15 */
        CallBack callBack = new CallBack();
        /* 16 */
        callBack.setIndex(index);
        /* 17 */
        callBack.setData(message);
        /*    */
        /* 19 */
        this.callbacks.put(Integer.valueOf(index), callBack);
        /*    */
    }

    /*    */
    /*    */
    public CallBack removeCallBack(int index) {
        /* 23 */
        return this.callbacks.remove(Integer.valueOf(index));
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallBackService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */