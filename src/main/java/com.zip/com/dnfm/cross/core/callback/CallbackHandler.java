/*    */
package com.dnfm.cross.core.callback;

/*    */
/*    */

import com.dnfm.cross.core.callback.CReqCallBack;
/*    */ import com.dnfm.cross.core.callback.CRespCallBack;
/*    */ import com.dnfm.cross.core.server.SCSession;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.annotation.PostConstruct;

/*    */
/*    */ public abstract class CallbackHandler {
    /* 12 */   private static final Map<Integer, com.dnfm.cross.core.callback.CallbackHandler> handlers = new HashMap<>();

    /*    */
    /*    */
    public static com.dnfm.cross.core.callback.CallbackHandler queryHandler(int type) {
        /* 15 */
        return handlers.get(Integer.valueOf(type));
        /*    */
    }

    /*    */
    /*    */
    @PostConstruct
    /*    */ private void init() {
        /* 20 */
        handlers.put(Integer.valueOf(cmdType()), this);
        /*    */
    }

    /*    */
    /*    */
    public abstract void onRequest(SCSession paramSCSession, CReqCallBack paramCReqCallBack);

    /*    */
    /*    */
    public void sendBack(SCSession session, CReqCallBack req, Message response) {
        /* 26 */
        CRespCallBack callBack = CRespCallBack.valueOf(response);
        /* 27 */
        callBack.setIndex(req.getIndex());
        /* 28 */
        session.sendMessage((Message) callBack);
        /*    */
    }

    /*    */
    /*    */
    public abstract int cmdType();
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallbackHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */