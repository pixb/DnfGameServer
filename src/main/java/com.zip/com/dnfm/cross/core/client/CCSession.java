/*    */
package com.dnfm.cross.core.client;
/*    */
/*    */

import com.dnfm.cross.core.codec.CrossSerializerHelper;
/*    */ import com.dnfm.cross.core.server.CMessageDispatcher;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import org.apache.mina.core.filterchain.IoFilter;
/*    */ import org.apache.mina.core.future.ConnectFuture;
/*    */ import org.apache.mina.core.service.IoHandler;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ import org.apache.mina.filter.codec.ProtocolCodecFactory;
/*    */ import org.apache.mina.filter.codec.ProtocolCodecFilter;
/*    */ import org.apache.mina.transport.socket.nio.NioSocketConnector;

/*    */
/*    */ public class CCSession {
    /* 17 */   private static final AtomicInteger idFactory = new AtomicInteger();
    /*    */
    /*    */   private int id;
    /*    */
    /*    */   private String ipAddr;
    /*    */
    /*    */   private int port;
    /*    */
    /*    */   private CMessageDispatcher dispatcher;
    /*    */
    /*    */   private IoSession wrapper;

    /*    */
    /*    */
    public static com.dnfm.cross.core.client.CCSession valueOf(String ip, int port, CMessageDispatcher dispatcher) {
        /* 30 */
        com.dnfm.cross.core.client.CCSession cSession = new com.dnfm.cross.core.client.CCSession();
        /* 31 */
        cSession.ipAddr = ip;
        /* 32 */
        cSession.port = port;
        /* 33 */
        cSession.id = idFactory.getAndIncrement();
        /* 34 */
        cSession.dispatcher = dispatcher;
        /* 35 */
        return cSession;
        /*    */
    }

    /*    */
    /*    */
    public void buildConnection() {
        /* 39 */
        NioSocketConnector connector = new NioSocketConnector();
        /* 40 */
        connector.getFilterChain().addLast("codec", (IoFilter) new ProtocolCodecFilter(
                /* 41 */           (ProtocolCodecFactory) CrossSerializerHelper.getInstance().getCodecFactory()));
        /* 42 */
        connector.setHandler((IoHandler) new Object());
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /*    */
        /* 54 */
        System.out.println("开始连接跨服服务器端口" + this.port);
        /* 55 */
        ConnectFuture future = connector.connect(new InetSocketAddress("127.0.0.1", this.port));
        /*    */
        /* 57 */
        future.awaitUninterruptibly();
        /* 58 */
        IoSession session = future.getSession();
        /* 59 */
        this.wrapper = session;
        /*    */
    }

    /*    */
    /*    */
    public String getIpAddr() {
        /* 63 */
        return this.ipAddr;
        /*    */
    }

    /*    */
    /*    */
    public int getPort() {
        /* 67 */
        return this.port;
        /*    */
    }

    /*    */
    /*    */
    public IoSession getWrapper() {
        /* 71 */
        return this.wrapper;
        /*    */
    }

    /*    */
    /*    */
    public int getId() {
        /* 75 */
        return this.id;
        /*    */
    }

    /*    */
    /*    */
    public void sendMessage(Message message) {
        /* 79 */
        this.wrapper.write(message);
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\client\CCSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */