/*    */
package com.dnfm.cross.core.callback;
/*    */ 
/*    */ import com.dnfm.logs.LoggerUtils;
/*    */ import com.dnfm.mina.protobuf.Message;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ public class CallBack
/*    */ {
/* 10 */   private static final AtomicInteger idFactory = new AtomicInteger();
/*    */   private int index;
/*    */   private Message data;
/*    */   
/*    */   public static int nextMsgId() {
/* 15 */     return idFactory.getAndIncrement();
/*    */   }
/*    */   
/*    */   protected void doTimeOut() {
/* 19 */     LoggerUtils.error("回调方法已过期", new Object[0]);
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 23 */     return this.index;
/*    */   }
/*    */   
/*    */   public void setIndex(int index) {
/* 27 */     this.index = index;
/*    */   }
/*    */   
/*    */   public Message getData() {
/* 31 */     return this.data;
/*    */   }
/*    */   
/*    */   public void setData(Message data) {
/* 35 */     this.data = data;
/*    */   }
/*    */   
/*    */   public boolean isDone() {
/* 39 */     return (this.data != null);
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CallBack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */