/*    */
package com.dnfm.cross.core.callback;

/*    */
/*    */

import com.dnfm.game.utils.JsonUtils;
/*    */ import com.dnfm.mina.annotation.MessageMeta;
/*    */ import com.dnfm.mina.protobuf.Message;

/*    */
/*    */
/*    */
/*    */
/*    */
@MessageMeta(module = -4)
/*    */ public class CRespCallBack
        /*    */ extends Message
        /*    */ {
    /*    */   private int index;
    /*    */   private String data;
    /*    */   private String msgClass;

    /*    */
    /*    */
    public static com.dnfm.cross.core.callback.CRespCallBack valueOf(Message message) {
        /* 19 */
        com.dnfm.cross.core.callback.CRespCallBack response = new com.dnfm.cross.core.callback.CRespCallBack();
        /* 20 */
        response.data = JsonUtils.object2String(message);
        /* 21 */
        response.msgClass = message.getClass().getName();
        /*    */
        /* 23 */
        return response;
        /*    */
    }

    /*    */
    /*    */
    public int getIndex() {
        /* 27 */
        return this.index;
        /*    */
    }

    /*    */
    /*    */
    public void setIndex(int index) {
        /* 31 */
        this.index = index;
        /*    */
    }

    /*    */
    /*    */
    public String getData() {
        /* 35 */
        return this.data;
        /*    */
    }

    /*    */
    /*    */
    public void setData(String data) {
        /* 39 */
        this.data = data;
        /*    */
    }

    /*    */
    /*    */
    public String getMsgClass() {
        /* 43 */
        return this.msgClass;
        /*    */
    }

    /*    */
    /*    */
    public void setMsgClass(String msgClass) {
        /* 47 */
        this.msgClass = msgClass;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\cross\core\callback\CRespCallBack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */