package com.dnfm.cross.transfer;

public interface ICrossTransfer {
}
