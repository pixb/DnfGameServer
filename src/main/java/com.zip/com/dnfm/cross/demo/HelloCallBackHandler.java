package com.dnfm.cross.demo;


import com.dnfm.cross.core.callback.CReqCallBack;
import com.dnfm.cross.core.callback.CallbackHandler;
import com.dnfm.cross.core.server.SCSession;
import com.dnfm.cross.demo.CRespCrossHeartBeat;
import com.dnfm.mina.protobuf.Message;
import org.springframework.stereotype.Component;

@Component
public class HelloCallBackHandler extends CallbackHandler {
    public void onRequest(SCSession session, CReqCallBack req) {
        CRespCrossHeartBeat resp = new CRespCrossHeartBeat();
        sendBack(session, req, (Message) resp);
    }

    public int cmdType() {
        return 1;
    }
}
