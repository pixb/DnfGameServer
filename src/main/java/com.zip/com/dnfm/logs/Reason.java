/*    */
package com.dnfm.logs;
/*    */ 
/*    */ 
/*    */ public enum Reason
/*    */ {
/*  6 */   RECHARGE(511, "充值");
/*    */ 
/*    */   
/*    */   String desc;
/*    */   
/*    */   int type;
/*    */ 
/*    */   
/*    */   Reason(int type, String desc) {
/* 15 */     this.type = type;
/* 16 */     this.desc = desc;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 20 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getDesc() {
/* 24 */     return this.desc;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\logs\Reason.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */