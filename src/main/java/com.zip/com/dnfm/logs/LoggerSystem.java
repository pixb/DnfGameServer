package com.dnfm.logs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum LoggerSystem {
    EXCEPTION,
    INFO,
    DEBUG,
    WARNING,
    HTTP_COMMAND,
    CRON_JOB,
    MONITOR;

    private LoggerSystem() {
    }

    public Logger getLogger() {
        return LoggerFactory.getLogger(this.name());
    }
}
