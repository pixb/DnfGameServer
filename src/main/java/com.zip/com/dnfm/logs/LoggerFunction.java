package com.dnfm.logs;

import com.dnfm.logs.LoggerBuilder;
import org.slf4j.Logger;

/**
 * 日志功能枚举。
 * 定义了游戏中不同模块的日志记录器。
 */
public enum LoggerFunction {

    PAY,       // 支付模块日志
    SCENE,     // 场景模块日志
    MONOIOR,   // 监控模块日志 (注意：原名为 MONOIOR，可能是 MONITOR 的笔误)
    MARKET,    // 市场模块日志
    FIGHT,     // 战斗模块日志
    MAIL;      // 邮件模块日志

    /**
     * 获取对应功能的日志记录器。
     *
     * @return SLF4J Logger 实例
     */
    public Logger getLogger() {
        // 使用枚举常量的名称（转为小写）来获取 Logger
        return (Logger) LoggerBuilder.getLogger(name().toLowerCase());
    }
}