package com.dnfm.listener;

import com.dnfm.listener.EventType;
import lombok.Getter;

/**
 * 基础游戏事件抽象类。
 * 定义了事件类型和创建时间。
 */
public abstract class BaseGameEvent {

    @Getter
    private final EventType eventType;

    @Getter
    private final long createTime;

    /**
     * 构造函数。
     * @param evtType 事件类型
     */
    protected BaseGameEvent(EventType evtType) {
        this.createTime = System.currentTimeMillis();
        this.eventType = evtType;
    }

    /**
     * 判断事件是否为同步事件。
     * @return 默认返回 true，表示同步事件
     */
    public boolean isSynchronized() {
        return true;
    }
}