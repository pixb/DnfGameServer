/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class RoleLevelUpEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final short oldLevel;
/*    */   private final short level;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/*    */   
/*    */   public short getOldLevel() {
/* 17 */     return this.oldLevel;
/*    */   }
/*    */   
/*    */   public short getLevel() {
/* 21 */     return this.level;
/*    */   }
/*    */   public RoleLevelUpEvent(EventType evtType, Role role, short oldLevel, short level) {
/* 24 */     super(evtType, role);
/* 25 */     this.oldLevel = oldLevel;
/* 26 */     this.level = level;
/* 27 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\RoleLevelUpEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */