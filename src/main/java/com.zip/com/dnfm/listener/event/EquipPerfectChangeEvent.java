/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.equip.model.RoleEquip;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class EquipPerfectChangeEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   
/* 11 */   public Role getRole() { return this.role; } private final RoleEquip roleEquip; private final int perfect; public RoleEquip getRoleEquip() {
/* 12 */     return this.roleEquip; } public int getPerfect() {
/* 13 */     return this.perfect;
/*    */   }
/*    */   public EquipPerfectChangeEvent(EventType evtType, Role role, RoleEquip roleEquip, int perfect) {
/* 16 */     super(evtType, role);
/* 17 */     this.role = role;
/* 18 */     this.roleEquip = roleEquip;
/* 19 */     this.perfect = perfect;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\EquipPerfectChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */