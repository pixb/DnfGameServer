/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class RoleExpireEvent
/*    */   extends BasePlayerEvent {
/*    */   public Role getRole() {
/* 10 */     return this.role;
/*    */   } private final Role role;
/*    */   public RoleExpireEvent(EventType evtType, Role role) {
/* 13 */     super(evtType, role);
/* 14 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\RoleExpireEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */