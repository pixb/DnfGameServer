/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class OnEquipEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   private final Role role;
/*    */   private final String equipName;
/*    */   
/*    */   public Role getRole() {
/* 14 */     return this.role;
/*    */   }
/*    */   
/*    */   public String getEquipName() {
/* 18 */     return this.equipName;
/*    */   }
/*    */   public OnEquipEvent(EventType evtType, Role role, String equipName) {
/* 21 */     super(evtType, role);
/* 22 */     this.equipName = equipName;
/* 23 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\OnEquipEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */