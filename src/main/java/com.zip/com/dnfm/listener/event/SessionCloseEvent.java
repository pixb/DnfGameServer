/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ import org.apache.mina.core.session.IoSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionCloseEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   private final Role role;
/*    */   private final IoSession session;
/*    */   
/*    */   public SessionCloseEvent(EventType evtType, Role role, IoSession session) {
/* 18 */     super(evtType, role);
/* 19 */     this.role = role;
/* 20 */     this.session = session;
/*    */   }
/*    */   
/*    */   public Role getRole() {
/* 24 */     return this.role;
/*    */   }
/*    */   
/*    */   public IoSession getSession() {
/* 28 */     return this.session;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\SessionCloseEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */