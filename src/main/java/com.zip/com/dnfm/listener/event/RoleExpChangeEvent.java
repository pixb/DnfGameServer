/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class RoleExpChangeEvent
/*    */   extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final int change;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/*    */   
/*    */   public int getChange() {
/* 17 */     return this.change;
/*    */   }
/*    */   public RoleExpChangeEvent(EventType evtType, Role role, int change) {
/* 20 */     super(evtType, role);
/* 21 */     this.role = role;
/* 22 */     this.change = change;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\RoleExpChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */