package com.dnfm.listener.event;

import com.dnfm.game.equip.model.RoleEquip;
import com.dnfm.game.role.model.Role;
import com.dnfm.listener.BasePlayerEvent;
import com.dnfm.listener.EventType;
import lombok.Getter;

/**
 * 更换装备事件。
 * 继承自 BasePlayerEvent，携带了触发事件的角色和装备信息。
 */
// 使用 @Getter 为 final 字段生成 getter 方法
public class ChangeEquipEvent extends BasePlayerEvent {

    @Getter
    private final Role role;

    @Getter
    private final RoleEquip roleEquip;

    /**
     * 构造函数。
     * @param evtType 事件类型
     * @param role 触发事件的角色
     * @param roleEquip 更换的装备
     */
    public ChangeEquipEvent(EventType evtType, Role role, RoleEquip roleEquip) {
        super(evtType, role);
        this.role = role;
        this.roleEquip = roleEquip;
    }
}