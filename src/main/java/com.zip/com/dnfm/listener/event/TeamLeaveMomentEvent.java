/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class TeamLeaveMomentEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   private final Role role;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/*    */   public TeamLeaveMomentEvent(EventType evtType, Role role) {
/* 16 */     super(evtType, role);
/* 17 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\TeamLeaveMomentEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */