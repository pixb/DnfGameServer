/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class SwitchChangeEvent extends BasePlayerEvent {
/*    */   Role role;
/*    */   
/* 10 */   public Role getRole() { return this.role; } private final String key; private final boolean open; public String getKey() {
/* 11 */     return this.key; } public boolean isOpen() {
/* 12 */     return this.open;
/*    */   }
/*    */   public SwitchChangeEvent(EventType evtType, Role role, String key, boolean open) {
/* 15 */     super(evtType, role);
/* 16 */     this.role = role;
/* 17 */     this.key = key;
/* 18 */     this.open = open;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\SwitchChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */