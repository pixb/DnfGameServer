/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class TalkEndEvent
/*    */   extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final int talkId;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/*    */   
/*    */   public int getTalkId() {
/* 17 */     return this.talkId;
/*    */   }
/*    */   public TalkEndEvent(EventType evtType, Role role, int talkId) {
/* 20 */     super(evtType, role);
/* 21 */     this.role = role;
/* 22 */     this.talkId = talkId;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\TalkEndEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */