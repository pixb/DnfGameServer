/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class ConfirmEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final int taskId;
/*    */   private final String select;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/* 15 */   public int getTaskId() { return this.taskId; } public String getSelect() {
/* 16 */     return this.select;
/*    */   }
/*    */   public ConfirmEvent(EventType evtType, Role role, int taskId, String select) {
/* 19 */     super(evtType, role);
/*    */     
/* 21 */     this.taskId = taskId;
/* 22 */     this.select = select;
/* 23 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\ConfirmEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */