/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class PaySuccessEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   
/* 10 */   public Role getRole() { return this.role; } private final int money; private final int addDq; public int getMoney() {
/* 11 */     return this.money; } public int getAddDq() {
/* 12 */     return this.addDq;
/*    */   }
/*    */   public PaySuccessEvent(EventType evtType, Role role, int money, int addDq) {
/* 15 */     super(evtType, role);
/* 16 */     this.role = role;
/* 17 */     this.money = money;
/* 18 */     this.addDq = addDq;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\PaySuccessEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */