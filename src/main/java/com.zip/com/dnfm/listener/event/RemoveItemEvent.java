/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.equip.model.RoleEquip;
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class RemoveItemEvent
/*    */   extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final RoleEquip roleEquip;
/*    */   
/*    */   public Role getRole() {
/* 14 */     return this.role; } public RoleEquip getRoleEquip() {
/* 15 */     return this.roleEquip;
/*    */   }
/*    */   public RemoveItemEvent(EventType evtType, Role role, RoleEquip roleEquip) {
/* 18 */     super(evtType, role);
/* 19 */     this.role = role;
/* 20 */     this.roleEquip = roleEquip;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\RemoveItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */