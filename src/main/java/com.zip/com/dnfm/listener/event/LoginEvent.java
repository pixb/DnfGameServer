package com.dnfm.listener.event;

import com.dnfm.game.role.model.Role;
import com.dnfm.listener.BasePlayerEvent;
import com.dnfm.listener.EventType;
import lombok.Getter;

/**
 * 登录事件。
 * 继承自 BasePlayerEvent，携带了触发事件的角色信息。
 */
public class LoginEvent extends BasePlayerEvent {

    @Getter
    private final Role role;

    /**
     * 构造函数。
     * @param evtType 事件类型 (LOGIN)
     * @param role 登录的角色
     */
    public LoginEvent(EventType evtType, Role role) {
        super(evtType, role);
        this.role = role;
    }
}