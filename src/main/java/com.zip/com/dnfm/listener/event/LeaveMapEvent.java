/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeaveMapEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   private final int mapId;
/*    */   private final Role role;
/*    */   
/*    */   public int getMapId() {
/* 16 */     return this.mapId; } public Role getRole() {
/* 17 */     return this.role;
/*    */   }
/*    */   
/*    */   public LeaveMapEvent(EventType evtType, Role role, int mapId) {
/* 21 */     super(evtType, role);
/* 22 */     this.mapId = mapId;
/* 23 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\LeaveMapEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */