/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class StudySkillEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   private final int skillId;
/*    */   private final short skillLevel;
/*    */   
/*    */   public Role getRole() {
/* 13 */     return this.role;
/*    */   }
/*    */   
/*    */   public int getSkillId() {
/* 17 */     return this.skillId;
/*    */   }
/*    */   
/*    */   public short getSkillLevel() {
/* 21 */     return this.skillLevel;
/*    */   }
/*    */   
/*    */   public StudySkillEvent(EventType evtType, Role role, int skillId, short skillLevel) {
/* 25 */     super(evtType, role);
/* 26 */     this.role = role;
/* 27 */     this.skillId = skillId;
/* 28 */     this.skillLevel = skillLevel;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\StudySkillEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */