/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ 
/*    */ public class FetchEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   public static final byte FETCH_PET = 1;
/*    */   private final Role role;
/*    */   private final byte fetchType;
/*    */   
/*    */   public Role getRole() {
/* 16 */     return this.role;
/*    */   } public byte getFetchType() {
/* 18 */     return this.fetchType;
/*    */   }
/*    */   public FetchEvent(EventType evtType, Role role, byte fetchType) {
/* 21 */     super(evtType, role);
/* 22 */     this.role = role;
/* 23 */     this.fetchType = fetchType;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\FetchEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */