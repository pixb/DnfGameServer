/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class RoleNameChangeEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   
/* 10 */   public Role getRole() { return this.role; } private final String prevName; private final String currName; public String getPrevName() {
/* 11 */     return this.prevName; } public String getCurrName() {
/* 12 */     return this.currName;
/*    */   }
/*    */   public RoleNameChangeEvent(EventType evtType, Role role, String prevName, String currName) {
/* 15 */     super(evtType, role);
/* 16 */     this.role = role;
/* 17 */     this.prevName = prevName;
/* 18 */     this.currName = currName;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\RoleNameChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */