/*    */
package com.dnfm.listener.event;

/*    */
/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangeEquipPageEvent
/*    */   extends BasePlayerEvent
/*    */ {
/*    */   private final Role role;
/*    */   
/*    */   public Role getRole() {
/* 15 */     return this.role;
/*    */   }
/*    */   public ChangeEquipPageEvent(EventType evtType, Role role) {
/* 18 */     super(evtType, role);
/* 19 */     this.role = role;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\ChangeEquipPageEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */