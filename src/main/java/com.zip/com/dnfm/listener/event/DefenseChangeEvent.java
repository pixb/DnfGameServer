/*    */
package com.dnfm.listener.event;

/*    */ import com.dnfm.game.role.model.Role;
/*    */ import com.dnfm.listener.BasePlayerEvent;
/*    */ import com.dnfm.listener.EventType;
/*    */ 
/*    */ public class DefenseChangeEvent extends BasePlayerEvent {
/*    */   private final Role role;
/*    */   
/*    */   public Role getRole() {
/* 10 */     return this.role;
/*    */   }
/*    */   private final int defense;
/*    */   public int getDefense() {
/* 14 */     return this.defense;
/*    */   }
/*    */   public DefenseChangeEvent(EventType evtType, Role role, int defense) {
/* 17 */     super(evtType, role);
/* 18 */     this.role = role;
/* 19 */     this.defense = defense;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\event\DefenseChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */