/*    */
package com.dnfm.listener;

/*    */
/*    */

import com.dnfm.listener.BaseGameEvent;
/*    */ import com.dnfm.listener.EventDispatcher;
/*    */ import com.dnfm.listener.EventType;
/*    */ import com.dnfm.listener.annotation.EventHandler;
/*    */ import com.dnfm.logs.LoggerUtils;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.ReflectionUtils;

/*    */
/*    */
/*    */ public enum ListenerManager
        /*    */ {
    /* 16 */   INSTANCE;

    /*    */   ListenerManager() {
        /* 18 */
        this.map = new HashMap<>();
        /*    */
    }

    /*    */   private final Map<String, Method> map;

    /*    */
    public void registerEventHandler(Object handler) {
        /* 22 */
        Method[] methods = handler.getClass().getDeclaredMethods();
        /* 23 */
        for (Method method : methods) {
            /* 24 */
            EventHandler mapperAnnotation = method.<EventHandler>getAnnotation(EventHandler.class);
            /* 25 */
            if (mapperAnnotation != null) {
                /* 26 */
                EventType[] eventTypes = mapperAnnotation.value();
                /* 27 */
                for (EventType eventType : eventTypes) {
                    /* 28 */
                    EventDispatcher.getInstance().registerEvent(eventType, handler);
                    /* 29 */
                    this.map.put(getKey(handler, eventType), method);
                    /*    */
                }
                /*    */
            }
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    /*    */
    public void fireEvent(Object handler, BaseGameEvent event) {
        /*    */
        try {
            /* 43 */
            Method method = this.map.get(getKey(handler, event.getEventType()));
            /* 44 */
            ReflectionUtils.makeAccessible(method);
            /* 45 */
            ReflectionUtils.invokeMethod(method, handler, new Object[]{event});
            /* 46 */
        } catch (Exception e) {
            /* 47 */
            LoggerUtils.error("监听器执行异常,handler[{}] event[{}] error{}", new Object[]{handler
/* 48 */.getClass().getSimpleName(), event.getEventType(), e});
            /*    */
        }
        /*    */
    }

    /*    */
    /*    */
    private String getKey(Object handler, EventType eventType) {
        /* 53 */
        return handler.getClass().getName() + "-" + eventType.toString();
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\ListenerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */