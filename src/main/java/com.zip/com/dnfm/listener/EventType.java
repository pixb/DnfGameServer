package com.dnfm.listener;

/**
 * 事件类型枚举。
 * 定义了游戏中各种事件的类型。
 */
public enum EventType {
    LOGIN,
    LOGOUT,
    LOGOUT_SELF,
    ROLE_EXPIRE,
    ROLE_LEVEL_UP,
    CREATE_ROLE,
    ENTER_MAP,
    TALK_END,
    ON_EQUIP,
    CHANGE_EQUIP,
    FETCH,
    FIGHT_END,
    MOVE,
    CONFIRM,
    STUDY_SKILL,
    TEAM_LEAVE,
    TEAM_LEAVE_MOMENT,
    TEAM_CHANGE_LEADER,
    HEART_BEAT,
    GATHER_END,
    LEAVE_MAP,
    UPGRADE_EQUIP,
    DEFENSE_CHANGE,
    SPEED_CHANGE,
    EQUIP_UPGRADE_LEVEL_CHANGE,
    CHANGE_EQUIP_PAGE,
    TASK_END,
    REMOVE_PET,
    PAY_SUCESS,
    ROLE_NAME_CHANGE,
    REMOVE_ITEM,
    SWITCH_CHANGE,
    ROLE_EXP_CHANGE
}