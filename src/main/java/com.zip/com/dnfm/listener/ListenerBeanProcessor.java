/*    */
package com.dnfm.listener;

/*    */
/*    */

import com.dnfm.listener.ListenerManager;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.stereotype.Component;

/*    */
/*    */
@Component
/*    */ public class ListenerBeanProcessor
        /*    */ implements BeanPostProcessor, ApplicationContextAware, Ordered {
    /*    */
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        /* 15 */
        ListenerManager.INSTANCE.registerEventHandler(o);
        /* 16 */
        return o;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    public Object postProcessAfterInitialization(Object o, String s) throws BeansException {
        /* 21 */
        return o;
        /*    */
    }

    /*    */
    /*    */
    /*    */
    /*    */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    }

    /*    */
    /*    */
    /*    */
    /*    */
    public int getOrder() {
        /* 31 */
        return Integer.MAX_VALUE;
        /*    */
    }
    /*    */
}


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\listener\ListenerBeanProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */