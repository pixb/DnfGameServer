package com.dnfm.listener;

import com.dnfm.game.role.model.Role;
import com.dnfm.listener.BaseGameEvent;
import com.dnfm.listener.EventType;
import lombok.Getter;

/**
 * 基础玩家事件抽象类。
 * 继承自 BaseGameEvent，并持有关联玩家的 UID。
 */
public abstract class BasePlayerEvent extends BaseGameEvent {

    @Getter
    private final long playerUid;

    /**
     * 构造函数。
     * @param evtType 事件类型
     * @param role 关联的角色对象，用于提取玩家 UID
     */
    protected BasePlayerEvent(EventType evtType, Role role) {
        super(evtType);
        this.playerUid = role.getUid();
    }
}