/*    */
package com.dnfm.http;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpResult
/*    */ {
/*    */   private String status;
/*    */   private String msg;
/*    */   
/*    */   public static com.dnfm.http.HttpResult valueOfOk(String msg) {
/* 11 */     com.dnfm.http.HttpResult reply = new com.dnfm.http.HttpResult();
/* 12 */     reply.status = "success";
/* 13 */     reply.msg = msg;
/* 14 */     return reply;
/*    */   }
/*    */   
/*    */   public static com.dnfm.http.HttpResult valueOfFail(String msg) {
/* 18 */     com.dnfm.http.HttpResult reply = new com.dnfm.http.HttpResult();
/* 19 */     reply.status = "error";
/* 20 */     reply.msg = msg;
/* 21 */     return reply;
/*    */   }
/*    */   
/*    */   public String getStatus() {
/* 25 */     return this.status;
/*    */   }
/*    */   
/*    */   public void setStatus(String status) {
/* 29 */     this.status = status;
/*    */   }
/*    */   
/*    */   public String getMsg() {
/* 33 */     return this.msg;
/*    */   }
/*    */   
/*    */   public void setMsg(String msg) {
/* 37 */     this.msg = msg;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\http\HttpResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */