package com.dnfm.common.mysql;

import java.util.ArrayList;
import java.util.List;

/**
 * 这段代码定义了一个名为`DynamicDataSourceContextHolder`的类，
 * 该类的主要作用是管理多数据源环境下的数据源切换
 */
public class DynamicDataSourceContextHolder {
    private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();
    public static List<String> dataSourceIds = new ArrayList<>();

    public static String getDataSourceType() {
        return contextHolder.get();
    }

    public static void setDataSourceType(String dataSourceType) {
        contextHolder.set(dataSourceType);
    }

    public static void clearDataSourceType() {
        contextHolder.remove();
    }

    public static boolean containsDataSource(String dataSourceId) {
        return dataSourceIds.contains(dataSourceId);
    }
}