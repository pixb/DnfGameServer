package com.dnfm.common.bean;

import java.util.Date;
import org.nutz.dao.entity.annotation.Column;
import org.nutz.dao.entity.annotation.Id;
import org.nutz.dao.entity.annotation.Table;

@Table("pay_gateway")
public class PayGateWay {
  @Id
  private long id;
  
  @Column
  private String account;
  
  @Column
  private long money;
  
  @Column
  private int rmb;
  
  @Column
  private Date create_time;
  
  @Column
  private Date update_time;
  
  @Column
  private int state;
  
  @Column
  private String orderid;
  
  public void setId(long id) {
    this.id = id;
  }
  
  public void setAccount(String account) {
    this.account = account;
  }
  
  public void setMoney(long money) {
    this.money = money;
  }
  
  public void setRmb(int rmb) {
    this.rmb = rmb;
  }
  
  public void setCreate_time(Date create_time) {
    this.create_time = create_time;
  }
  
  public void setUpdate_time(Date update_time) {
    this.update_time = update_time;
  }
  
  public void setState(int state) {
    this.state = state;
  }
  
  public void setOrderid(String orderid) {
    this.orderid = orderid;
  }
  
  public boolean equals(Object o) {
    if (o == this)
      return true; 
    if (!(o instanceof PayGateWay))
      return false; 
    PayGateWay other = (PayGateWay)o;
    if (!other.canEqual(this))
      return false; 
    if (getId() != other.getId())
      return false; 
    Object this$account = getAccount(), other$account = other.getAccount();
    if ((this$account == null) ? (other$account != null) : !this$account.equals(other$account))
      return false;
    if (getMoney() != other.getMoney())
      return false;
    if (getRmb() != other.getRmb())
      return false;
    Object this$create_time = getCreate_time(), other$create_time = other.getCreate_time();
    if ((this$create_time == null) ? (other$create_time != null) : !this$create_time.equals(other$create_time))
      return false;
    Object this$update_time = getUpdate_time(), other$update_time = other.getUpdate_time();
    if ((this$update_time == null) ? (other$update_time != null) : !this$update_time.equals(other$update_time))
      return false;
    if (getState() != other.getState())
      return false;
    Object this$orderid = getOrderid(), other$orderid = other.getOrderid();
    return !((this$orderid == null) ? (other$orderid != null) : !this$orderid.equals(other$orderid));
  }

  protected boolean canEqual(Object other) {
    return other instanceof PayGateWay;
  }

  public int hashCode() {
    int PRIME = 59;
    int result = 1;
    result = result * 59 + (int)(id >>> 32L ^ id);
    result = result * 59 + ((account == null) ? 43 : account.hashCode());
    result = result * 59 + (int)(money >>> 32L ^ money);
    result = result * 59 + getRmb();
    result = result * 59 + ((create_time == null) ? 43 : create_time.hashCode());
    result = result * 59 + ((update_time == null) ? 43 : update_time.hashCode());
    result = result * 59 + getState();
    return result * 59 + ((orderid == null) ? 43 : orderid.hashCode());
  }
  
  public String toString() {
    return "PayGateWay(id=" + getId() + ", account=" + getAccount() + ", money=" + getMoney() + ", rmb=" + getRmb() + ", create_time=" + getCreate_time() + ", update_time=" + getUpdate_time() + ", state=" + getState() + ", orderid=" + getOrderid() + ")";
  }
  
  public long getId() {
    return this.id;
  }
  
  public String getAccount() {
    return this.account;
  }
  
  public long getMoney() {
    return this.money;
  }
  
  public int getRmb() {
    return this.rmb;
  }
  
  public Date getCreate_time() {
    return this.create_time;
  }
  
  public Date getUpdate_time() {
    return this.update_time;
  }
  
  public int getState() {
    return this.state;
  }
  
  public String getOrderid() {
    return this.orderid;
  }
}
