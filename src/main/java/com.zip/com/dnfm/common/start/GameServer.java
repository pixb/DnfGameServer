package com.dnfm.common.start;

import com.dnfm.common.spring.ScheduledService;
import com.dnfm.common.thread.NamedThreadFactory;
import com.dnfm.game.ServerService;
import com.dnfm.mina.MessageDispatcher;
import com.dnfm.mina.ServerSocketIoHandler;
import com.dnfm.mina.codec.SerializerHelper;
import com.dnfm.mina.message.IMessageDispatcher;
import com.dnfm.mina.message.MessageFactory;
import com.dnfm.mina.task.TaskHandlerContext;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.buffer.SimpleBufferAllocator;
import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
import org.apache.mina.core.service.IoProcessor;
import org.apache.mina.core.service.SimpleIoProcessorPool;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSessionConfig;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.DefaultSocketSessionConfig;
import org.apache.mina.transport.socket.SocketAcceptor;
import org.apache.mina.transport.socket.nio.NioProcessor;
import org.apache.mina.transport.socket.nio.NioSession;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * 游戏服务器启动类。
 * 实现 CommandLineRunner 接口，在 Spring Boot 应用启动后初始化 MINA 网络服务器。
 */
@Component
public class GameServer implements CommandLineRunner {

    private static SocketAcceptor acceptor;

    private final Logger logger = LoggerFactory.getLogger(GameServer.class);

    @Autowired
    private ServerService serverService;

    @Autowired
    private ScheduledService scheduledService;

    /**
     * Spring Boot 启动后执行的主方法。
     * 调用 initGameServer 方法初始化服务器。
     *
     * @param args 命令行参数
     * @throws Exception 初始化过程中的异常
     */
    @Override
    public void run(String... args) throws Exception {
        initGameServer();
    }

    /**
     * 初始化游戏服务器。
     * 配置 MINA 的各种参数，包括缓冲区、处理器、会话配置、过滤器链和处理器。
     *
     * @throws Exception 初始化过程中的异常
     */
    private void initGameServer() throws Exception {
        logger.info("GameServer.initGameServer... 开始初始化");

        // 初始化消息池和任务处理上下文
        MessageFactory.INSTANCE.initMessagePool("com.dnfm.mina.protobuf");
        TaskHandlerContext.INSTANCE.initialize();

        // 配置 MINA 缓冲区
        IoBuffer.setUseDirectBuffer(false); // 使用堆内存缓冲区
        IoBuffer.setAllocator(new SimpleBufferAllocator()); // 使用简单缓冲区分配器

        // 创建 IO 处理线程池
        int coreSize = Runtime.getRuntime().availableProcessors();
        Executor executor = Executors.newCachedThreadPool(new NamedThreadFactory("SOCKET-IO-PROCESSOR"));
        SimpleIoProcessorPool<NioSession> processor = new SimpleIoProcessorPool<>(NioProcessor.class, executor, coreSize, null);

        // 创建 NIO Socket 接收器
        acceptor = new NioSocketAcceptor(processor);
        acceptor.setReuseAddress(true); // 允许地址重用

        // 配置会话参数
        DefaultSocketSessionConfig defaultSocketSessionConfig = new DefaultSocketSessionConfig();
        defaultSocketSessionConfig.setKeepAlive(false); // 关闭 TCP Keep-Alive
        defaultSocketSessionConfig.setTcpNoDelay(true); // 启用 TCP No-Delay (Nagle's Algorithm)
        defaultSocketSessionConfig.setReuseAddress(true); // 允许地址重用 (会话级别，通常由 acceptor.setReuseAddress 控制)
        defaultSocketSessionConfig.setReadBufferSize(2048); // 设置读缓冲区大小
        defaultSocketSessionConfig.setIdleTime(IdleStatus.BOTH_IDLE, 30000); // 设置读写空闲时间 (30秒)
        defaultSocketSessionConfig.setSoLinger(0); // 设置 SO_LINGER 为 0，强制关闭时立即发送 RST 包

        // 将配置应用到接收器
        acceptor.getSessionConfig().setAll(defaultSocketSessionConfig);

        // 配置过滤器链 (添加编解码器)
        DefaultIoFilterChainBuilder filterChain = acceptor.getFilterChain();
        filterChain.addLast("codec", new ProtocolCodecFilter(SerializerHelper.getInstance().getCodecFactory()));

        // 设置业务逻辑处理器
        acceptor.setHandler(new ServerSocketIoHandler(MessageDispatcher.getInstance()));

        // 设置连接队列大小
        acceptor.setBacklog(3000);

        // 绑定到指定的 IP 和端口
        acceptor.setDefaultLocalAddress(new InetSocketAddress(serverService.getInetIp(), serverService.getPort()));
        acceptor.bind();

        logger.info("GameServer started at ip {}, port: {}", serverService.getInetIp(), serverService.getPort());
        logger.info("GameServer initialization completed successfully.");
    }

    /**
     * 获取 MINA Socket 接收器实例。
     *
     * @return SocketAcceptor 实例，如果服务器未初始化则可能为 null
     */
    public SocketAcceptor getAcceptor() {
        return acceptor;
    }
}