package com.dnfm.common.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Pos {
    private int x = 474;

    private int y = 234;

    private int town = 1;

    private int area = 3;

}
