package com.dnfm.common.spring;

import com.dnfm.common.start.GameServer;
import com.dnfm.game.ServerService;
import com.dnfm.game.equip.service.EquipService;
import com.dnfm.game.player.PlayerService;
import com.dnfm.game.role.model.Role;
import com.dnfm.game.role.service.RoleService;
import com.dnfm.mina.cache.DataCache;
import com.dnfm.mina.message.MessagePusher;
import com.dnfm.mina.protobuf.Message;
import com.dnfm.mina.protobuf.RES_PING;
import com.dnfm.mina.session.SessionManager;
import com.dnfm.mina.task.ThreadLocalUtil;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.mina.core.session.IoSession;
import org.nutz.dao.Dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * 定时任务服务类。
 * 使用 Spring 的 @Scheduled 注解来执行定时任务，如每日重置、发送心跳、打印在线人数等。
 */
@Component
public class ScheduledService {

    // 临时索引，可能用于某些内部计数或标识（当前代码中未使用）
    static int tmpIndex = 1;

    private final Logger logger = LoggerFactory.getLogger(ScheduledService.class);

    @Autowired
    private Dao dao;

    @Autowired
    private ServerService serverService;

    @Autowired
    private EquipService equipService;

    @Autowired
    private GameServer gameServer;

    @Autowired
    private RoleService roleService;

    @Autowired
    private PlayerService playerService;

    /**
     * 每日重置任务。
     * 在每天早上 6 点执行，重置玩家的每日数据。
     * 使用 StopWatch 记录执行时间。
     */
    @Scheduled(cron = "0 0 6 * * ?") // 每天 06:00:00 执行
    public void dailyReset() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        Collection<Role> roles = DataCache.ONLINE_ROLES.values();
        for (Role role : roles) {
            // 将任务添加到线程本地队列中异步执行
            ThreadLocalUtil.addLocalTask(role, () -> this.roleService.doDailyFiveReset(role));
        }

        stopWatch.stop();
        logger.warn("6点重置玩家数据，用时{}毫秒", stopWatch.getTime());
    }

    /**
     * 发送心跳任务。
     * 每 2 秒执行一次，向所有在线玩家的会话发送心跳消息。
     */
    @Scheduled(cron = "*/2 * * * * ?") // 每 2 秒执行一次
    public void sendHeartbeat() {
        Collection<IoSession> sessions = SessionManager.INSTANCE.player2sessions.values();
        for (IoSession session : sessions) {
            RES_PING resPing = new RES_PING();
            resPing.responsetime = 90; // 设置响应时间
            MessagePusher.pushMessage(session, resPing);
        }
    }

    /**
     * 打印在线玩家数量任务。
     * 每分钟执行一次，将当前在线玩家数量打印到日志中。
     */
    @Scheduled(cron = "*/60 * * * * ?") // 每分钟执行一次 (等同于 "0 * * * * ?")
    public void printOnlineRole() {
        logger.info("========在线玩家人数-开始========");
        logger.info("========{}========", DataCache.ONLINE_ROLES.size());
        logger.info("========在线玩家人数-结束========");
    }
}