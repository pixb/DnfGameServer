package com.dnfm.common.thread;

public @interface ThreadSafe {}