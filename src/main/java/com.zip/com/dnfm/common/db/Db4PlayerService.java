package com.dnfm.common.db;

import com.dnfm.common.thread.NamedThreadFactory;
import com.dnfm.common.utils.BlockingUniqueQueue;
import com.dnfm.cross.CrossServerConfig;
import com.dnfm.game.player.PlayerService;
import com.dnfm.game.role.model.Role;
import com.dnfm.logs.LoggerUtils;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.apache.commons.lang3.time.StopWatch;
import org.nutz.dao.Dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Db4PlayerService {
    private static volatile Db4PlayerService instance;
    private final Logger logger = LoggerFactory.getLogger(Db4PlayerService.class);
    private final AtomicBoolean run = new AtomicBoolean(true);
    @Autowired
    CrossServerConfig crossServerConfig;
    @Autowired
    PlayerService playerService;
    @Autowired
    private Dao dao;
    private final BlockingQueue<Role> queue = new BlockingUniqueQueue();

    public Db4PlayerService() {
    }

    // 使用双重检查锁定（DCL）确保单例线程安全
    public static Db4PlayerService getInstance() {
        if (instance == null) {
            synchronized (Db4PlayerService.class) {
                if (instance == null) {
                    instance = new Db4PlayerService();
                }
            }
        }
        return instance;
    }

    @PostConstruct
    private void init() {
        this.logger.error("init Db4PlayerService");
        (new NamedThreadFactory("db-player-save-service")).newThread(new Worker(this)).start();
        instance = this;
    }

    public void add2Queue(Role entity) {
        if (entity == null) return;
        entity.setExp(Math.min(entity.getExp(), 107836272)); // 简化数值校验
        if (!crossServerConfig.isCenterServer() && !queue.contains(entity)) {
            queue.offer(entity);
            playerService.saveToCache(entity);
        }
    }


    public int size() {
        return this.queue.size();
    }

    private void saveToDb(Role entity) {
        this.playerService.saveToCache(entity);
        entity.doBeforeSave();
        if (entity.isDelete()) {
            this.dao.delete(entity);
        } else {
            this.dao.insertOrUpdate(entity);
        }

    }

    @PreDestroy
    public void shutDown() {
        this.run.getAndSet(false);

        while(!this.queue.isEmpty()) {
            this.saveAllBeforeShutDown();
        }

        LoggerUtils.error("[db4Player] 执行全部命令后关闭", new Object[0]);
    }

    private void saveAllBeforeShutDown() {
        while (!queue.isEmpty()) {
            Role player = queue.poll(); // 直接取队首元素
            if (player != null) {
                saveToDb(player);
            }
        }
    }

    class Worker implements Runnable {
        private Worker(Db4PlayerService var1) {
            instance = var1;
        }

        public void run() {
            while(run.get()) {
                Role entity = null;

                try {
                    entity = queue.take();
                    StopWatch stopWatch = new StopWatch();
                    stopWatch.start();
                    saveToDb(entity);
                    stopWatch.stop();
                    if (stopWatch.getTime() > 500L) {
                        LoggerUtils.error("玩家数据持久化消耗毫秒：" + stopWatch.getTime(), new Object[0]);
                        LoggerUtils.error("玩家数据持久化队列长度：" + queue.size(), new Object[0]);
                    }
                } catch (Exception var3) {
                    LoggerUtils.error("", var3);
                    add2Queue(entity);
                }
            }

        }
    }
}