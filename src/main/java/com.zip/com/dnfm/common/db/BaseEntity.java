package com.dnfm.common.db;

import java.io.Serializable;

public abstract class BaseEntity<PK extends Comparable<PK> & Serializable> implements Serializable {
  protected boolean delete = false;
  
  public abstract PK getId();
  
  public void doAfterInit() {}
  
  public void doBeforeSave() {}

  public boolean equals(Object obj) {
    if (this == obj)
      return true; 
    if (obj == null)
      return false; 
    if (getClass() != obj.getClass())
      return false; 
    BaseEntity<PK> other = (BaseEntity)obj;
    return (getId() == other.getId());
  }
  
  public boolean isDelete() {
    return this.delete;
  }
  
  public void setDelete(boolean delete) {
    this.delete = delete;
  }
}
