/*    */
package com.dnfm.common.utils;

/*    */
/*    */ import java.util.Random;
/*    */ 
/*    */ public class PasswordUtils
/*    */ {
/*  7 */   public static final String[] LOWER_CASES = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
/*  8 */   public static final String[] UPPER_CASES = new String[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
/*  9 */   public static final String[] NUMS_LIST = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
/* 10 */   public static final String[] SYMBOLS_ARRAY = new String[] { "!", "~", "^", "_", "*" };
/*    */   
/*    */   public static void main(String[] args) {
/* 13 */     System.out.println(genRandomPwd(12));
/*    */   }
/*    */   
/*    */   public static String genRandomPwd(int pwd_len) {
/* 17 */     if (pwd_len < 6 || pwd_len > 20) {
/* 18 */       return "";
/*    */     }
/* 20 */     int lower = pwd_len / 2;
/*    */     
/* 22 */     int upper = (pwd_len - lower) / 2;
/*    */     
/* 24 */     int num = (pwd_len - lower) / 2;
/*    */     
/* 26 */     int symbol = pwd_len - lower - upper - num;
/*    */     
/* 28 */     StringBuffer pwd = new StringBuffer();
/* 29 */     Random random = new Random();
/* 30 */     int position = 0;
/* 31 */     while (lower + upper + num + symbol > 0) {
/* 32 */       if (lower > 0) {
/* 33 */         position = random.nextInt(pwd.length() + 1);
/*    */         
/* 35 */         pwd.insert(position, LOWER_CASES[random.nextInt(LOWER_CASES.length)]);
/* 36 */         lower--;
/*    */       } 
/* 38 */       if (upper > 0) {
/* 39 */         position = random.nextInt(pwd.length() + 1);
/*    */         
/* 41 */         pwd.insert(position, UPPER_CASES[random.nextInt(UPPER_CASES.length)]);
/* 42 */         upper--;
/*    */       } 
/* 44 */       if (num > 0) {
/* 45 */         position = random.nextInt(pwd.length() + 1);
/*    */         
/* 47 */         pwd.insert(position, NUMS_LIST[random.nextInt(NUMS_LIST.length)]);
/* 48 */         num--;
/*    */       } 
/* 50 */       if (symbol > 0) {
/* 51 */         position = random.nextInt(pwd.length() + 1);
/*    */         
/* 53 */         pwd.insert(position, SYMBOLS_ARRAY[random.nextInt(SYMBOLS_ARRAY.length)]);
/* 54 */         symbol--;
/*    */       } 
/*    */       
/* 57 */       System.out.println(pwd);
/*    */     } 
/* 59 */     return pwd.toString();
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\commo\\utils\PasswordUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */