/*    */
package com.dnfm.common.utils;

/*    */
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.springframework.core.io.ClassPathResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesUtils
/*    */ {
/* 18 */   private static final Logger logger = LoggerFactory.getLogger(com.dnfm.common.utils.PropertiesUtils.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String readJsonFile(String fileName) {
/* 27 */     ClassPathResource classPathResource = new ClassPathResource(fileName);
/* 28 */     BufferedReader bufferedReader = null;
/* 29 */     InputStreamReader read = null;
/* 30 */     InputStream io = null;
/*    */     
/* 32 */     try { io = classPathResource.getInputStream();
/* 33 */       read = new InputStreamReader(io);
/* 34 */       bufferedReader = new BufferedReader(read);
/*    */       
/* 36 */       StringBuilder sb = new StringBuilder(); int ch;
/* 37 */       while ((ch = bufferedReader.read()) != -1) {
/* 38 */         sb.append((char)ch);
/*    */       }
/* 40 */       return sb.toString(); }
/* 41 */     catch (IOException iOException)
/*    */     
/*    */     { 
/*    */       
/* 45 */       try { io.close();
/* 46 */         read.close();
/* 47 */         bufferedReader.close(); }
/* 48 */       catch (IOException e)
/* 49 */       { e.printStackTrace(); }  } finally { try { io.close(); read.close(); bufferedReader.close(); } catch (IOException e) { e.printStackTrace(); }
/*    */        }
/*    */ 
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\commo\\utils\PropertiesUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */