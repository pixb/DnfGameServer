// Source code is decompiled from a .class file using FernFlower decompiler.
package com.dnfm.common.utils;

import java.util.LinkedHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class LimitedCacheMap<K, V> {
    private final LinkedHashMap<K, Element<V>> data;
    private final int capacity;
    private final long aliveTime;
    private final boolean useLru;
    private final ReentrantReadWriteLock lock;
    private final ReentrantReadWriteLock.ReadLock readLock;
    private final ReentrantReadWriteLock.WriteLock writeLock;

    public LimitedCacheMap(int capacity, long aliveTime) {
        this(capacity, aliveTime, Boolean.FALSE);
    }

    public LimitedCacheMap(int capacity, long aliveTime, boolean useLru) {
        this.lock = new ReentrantReadWriteLock();
        this.readLock = this.lock.readLock();
        this.writeLock = this.lock.writeLock();
        this.capacity = capacity;
        this.aliveTime = aliveTime;
        this.useLru = useLru;
        this.data = new LinkedHashMap<>(capacity, 1.0F);
    }

    public static void main(String[] args) throws Exception {
        LimitedCacheMap<Integer, Integer> map = new LimitedCacheMap(3, 1500L);
        map.put(1, 1);
        System.out.println("-----");
        Thread.sleep(1200L);
        System.out.println(map.get(1));
    }

    public V put(K key, V value) {
        V preValue = null;
        Element<V> newValue = new Element(value);
        this.readLock.lock();

        V var5;
        try {
            if (this.data.containsKey(key)) {
                preValue = this.data.get(key).value;
            }

            this.data.put(key, newValue);
            var5 = preValue;
        } finally {
            this.readLock.unlock();
        }

        return var5;
    }

    public V get(K key) {
        Lock lock = this.useLru ? this.writeLock : this.readLock;
        ((Lock)lock).lock();
        LimitedCacheMap<K, V>.Element<V> target = null;

        try {
            target = (Element)this.data.get(key);
            if (target == null) {
                V var4 = null;
                return var4;
            }
        } finally {
            ((Lock)lock).unlock();
        }

        long var8 = System.currentTimeMillis() - target.bornTime;
        if (var8 < this.aliveTime) {
            return target.value;
        } else {
            this.remove(key);
            return null;
        }
    }

    public int size() {
        this.readLock.lock();

        int var1;
        try {
            var1 = this.data.size();
        } finally {
            this.readLock.unlock();
        }

        return var1;
    }

    public void remove(K key) {
        this.writeLock.lock();

        try {
            this.data.remove(key);
        } finally {
            this.writeLock.unlock();
        }

    }

    public void clear() {
        this.writeLock.lock();

        try {
            this.data.clear();
        } finally {
            this.writeLock.unlock();
        }

    }

    public String toString() {
        return "LinkedCacheMap [data=" + this.data + ", capacity=" + this.capacity + ", aliveTime=" + this.aliveTime + ", useLru=" + this.useLru + "]";
    }
    class Element<V> {
        V value;
        long bornTime;

        Element(V v) {
            this.value = v;
            this.bornTime = System.currentTimeMillis();
        }

        public String toString() {
            return "Element [value=" + this.value + "]";
        }
    }

}
