/*    */
package com.dnfm.common.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pair<F, S>
/*    */ {
/*    */   private final F first;
/*    */   private final S second;
/*    */   
/*    */   public Pair(F first, S second) {
/* 13 */     this.first = first;
/* 14 */     this.second = second;
/*    */   }
/*    */   
/*    */   public F getFirst() {
/* 18 */     return this.first;
/*    */   }
/*    */   
/*    */   public S getSecond() {
/* 22 */     return this.second;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 27 */     return "Pair [first=" + this.first + ", second=" + this.second + "]";
/*    */   }
/*    */ }


/* Location:              D:\Dnfserver\GameServer\game_server-1.0.jar!\BOOT-INF\classes\com\dnfm\commo\\utils\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */