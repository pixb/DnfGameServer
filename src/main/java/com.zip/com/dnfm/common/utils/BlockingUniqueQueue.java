package com.dnfm.common.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

public class BlockingUniqueQueue<E> extends LinkedBlockingQueue<E> {
    private static final long serialVersionUID = 8351632564634804122L;
    private final Set<E> dataSet = ConcurrentHashMap.newKeySet(1200);

    public BlockingUniqueQueue() {
        super();
    }

    @Override
    public boolean contains(Object o) {
        return dataSet.contains(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return dataSet.containsAll(c);
    }

    @Override
    public E take() throws InterruptedException {
        E head = super.take();
        dataSet.remove(head);
        return head;
    }

    @Override
    public boolean add(E e) {
        if (e == null) {
            throw new NullPointerException();
        }

        synchronized (this) {
            if (contains(e)) {
                return false;
            }
            dataSet.add(e);
            return super.add(e);
        }
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        if (c == null) {
            throw new NullPointerException();
        }

        boolean modified = false;
        synchronized (this) {
            for (E e : c) {
                if (add(e)) {
                    modified = true;
                }
            }
        }
        return modified;
    }

    @Override
    public boolean remove(Object o) {
        synchronized (this) {
            boolean removed = super.remove(o);
            if (removed) {
                dataSet.remove(o);
            }
            return removed;
        }
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        synchronized (this) {
            boolean modified = super.removeAll(c);
            if (modified) {
                dataSet.removeAll(c);
            }
            return modified;
        }
    }

    @Override
    public Iterator<E> iterator() {
        return new Itr(this, super.iterator());
    }

    private class Itr implements Iterator<E> {
        private final Iterator<E> iterator;
        private E currentElement;
        private final BlockingUniqueQueue<E> queue;

        Itr(BlockingUniqueQueue<E> queue, Iterator<E> iterator) {
            this.queue = queue;
            this.iterator = iterator;
        }

        @Override
        public boolean hasNext() {
            return iterator.hasNext();
        }

        @Override
        public E next() {
            currentElement = iterator.next();
            return currentElement;
        }

        @Override
        public void remove() {
            synchronized (queue) {
                iterator.remove();
                dataSet.remove(currentElement);
            }
        }
    }
}